#include "VivifyRuntimeInternal.hpp"
#include "VivifyComponents.hpp"
#include "UnityEngine/ParticleSystem.hpp"
#include "GlobalNamespace/PlayerDataModel.hpp"
#include "GlobalNamespace/PlayerData.hpp"
#include "GlobalNamespace/PlayerSpecificSettings.hpp"
#include "UnityEngine/SceneManagement/Scene.hpp"
#include "UnityEngine/SceneManagement/SceneManager.hpp"
#include "custom-types/shared/delegate.hpp"

namespace Vivify {

namespace {
constexpr int kVideoPrepareWatchdogFrames = 900;
constexpr int kVideoFirstFrameGraceFrames = 180;
constexpr int kVideoRecoveryBackoffFrames = 300;
constexpr int kVideoStallFrames = 450;
constexpr int kVideoDriftCorrectionCooldownFrames = 12;
// Desktop Vivify corrects at 200 ms. Keep the same synchronization contract on
// Quest instead of hiding drift with frame dropping or accelerated decoding.
constexpr float kVideoDriftToleranceSeconds = 0.2f;
constexpr float kVideoSeekSettleToleranceSeconds = 0.2f;
constexpr int kVideoSeekSettleTimeoutFrames = 240;
constexpr int kVideoMaxRecoveryAttempts = 2;
constexpr int kHistoricalVideoProbeMaxSamples = 512;
constexpr float kHistoricalVideoProbeTargetStepSeconds = 1.0f / 15.0f;

bool IsMainMenuSceneActive() {
  auto scene = UnityEngine::SceneManagement::SceneManager::GetActiveScene();
  return scene.get_name() == "MainMenu";
}

UnityEngine::AnimationState* DefaultLegacyAnimationState(
    UnityEngine::Animation* animation) {
  if (!IsManagedAlive(animation)) return nullptr;
  auto clip = animation->get_clip();
  auto* clipPtr = clip.unsafePtr();
  if (!IsManagedAlive(clipPtr)) return nullptr;
  return animation->get_Item(clipPtr->get_name());
}

void SetLegacyAnimationSpeed(UnityEngine::Animation* animation, float speed) {
  auto* state = DefaultLegacyAnimationState(animation);
  if (state != nullptr && UnityEngine::TrackedReference::op_Implicit_bool(state)) {
    state->set_speed(speed);
  }
}

bool HasDecodedVideoOutput(UnityEngine::Video::VideoPlayer* player,
                           std::int64_t& decodedFrame) {
  decodedFrame = -1;
  if (!IsManagedAlive(player) || !player->get_isPrepared()) return false;

  auto texture = player->get_texture();
  if (!IsManagedAlive(texture.unsafePtr())) return false;

  // Quest's Android VideoPlayer can keep reporting frame == -1 while its
  // external texture is already valid and visibly advancing. Treat dimensions
  // plus a live texture as healthy output; frame is an optional stall signal.
  decodedFrame = player->get_frame();
  return player->get_width() > 0 && player->get_height() > 0;
}

float DecodedVideoTime(UnityEngine::Video::VideoPlayer* player,
                       std::int64_t decodedFrame) {
  if (!IsManagedAlive(player) || decodedFrame < 0) {
    return std::numeric_limits<float>::quiet_NaN();
  }
  float const frameRate = player->get_frameRate();
  if (!std::isfinite(frameRate) || frameRate <= 0.001f) {
    return std::numeric_limits<float>::quiet_NaN();
  }
  return static_cast<float>(decodedFrame) / frameRate;
}

bool ShouldVideoAdvance(UnityEngine::Video::VideoPlayer* player,
                        float videoTime, float playbackSpeed) {
  if (!IsManagedAlive(player) || playbackSpeed <= 0.001f) return false;
  if (player->get_isLooping()) return true;

  double const length = player->get_length();
  return !std::isfinite(length) || length <= 0.0 ||
         static_cast<double>(videoTime) + 0.1 < length;
}

bool IsAuthoredVideoGameObjectActive(SyncedVideoPlayer const& video) {
  if (!IsManagedAlive(video.authoredPlayer)) return false;
  auto go = video.authoredPlayer->get_gameObject();
  auto* goPtr = go.unsafePtr();
  return IsManagedAlive(goPtr) && goPtr->get_activeInHierarchy();
}

float NormalizeVideoTime(UnityEngine::Video::VideoPlayer* player,
                         float elapsed) {
  if (!IsManagedAlive(player) || !player->get_isPrepared() ||
      !player->get_isLooping()) {
    return elapsed;
  }

  double const length = player->get_length();
  if (!std::isfinite(length) || length <= 0.0) return elapsed;
  return static_cast<float>(std::fmod(static_cast<double>(elapsed), length));
}

bool EnsureVideoOutputBinding(SyncedVideoPlayer& video) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return false;

  auto const renderMode = player->get_renderMode();
  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    auto* target = video.renderTextureTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetTexture();
      target = targetReference.unsafePtr();
      video.renderTextureTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    if (!target->IsCreated()) target->Create();
    auto currentTarget = player->get_targetTexture();
    if (currentTarget.unsafePtr() != target) {
      player->set_targetTexture(target);
    }
    return target->IsCreated();
  }

  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    auto* target = video.materialTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetMaterialRenderer();
      target = targetReference.unsafePtr();
      if (!IsManagedAlive(target)) {
        target = video.authoredPlayer->GetComponent<UnityEngine::Renderer*>();
        if (!IsManagedAlive(target)) {
          target = video.authoredPlayer->GetComponentInChildren<UnityEngine::Renderer*>(true);
        }
      }
      video.materialTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    auto currentTarget = player->get_targetMaterialRenderer();
    if (currentTarget.unsafePtr() != target) {
      player->set_targetMaterialRenderer(target);
    }
    if (ToStdString(player->get_targetMaterialProperty()).empty()) {
      player->set_targetMaterialProperty(StringW("_MainTex"));
    }
    return true;
  }

  return true;
}

bool IsVideoOutputRenderable(SyncedVideoPlayer& video) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return false;
  auto const renderMode = player->get_renderMode();
  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    return EnsureVideoOutputBinding(video);
  }
  if (renderMode.value__ !=
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    return true;
  }
  if (!EnsureVideoOutputBinding(video) || !IsManagedAlive(video.materialTarget)) {
    return false;
  }
  auto targetObject = video.materialTarget->get_gameObject();
  auto* targetObjectPtr = targetObject.unsafePtr();
  return video.materialTarget->get_enabled() && IsManagedAlive(targetObjectPtr) &&
         targetObjectPtr->get_activeInHierarchy();
}

void BeginVideoSeek(SyncedVideoPlayer& video, float targetTime, int frame,
                    std::int64_t sourceFrame = -1) {
  auto* player = video.player;
  if (!IsManagedAlive(player) || !player->get_isPrepared()) return;

  video.seekSourceFrame = sourceFrame >= 0 ? sourceFrame : player->get_frame();
  video.seekTargetTime = targetTime;
  video.seekIssuedFrame = frame;
  video.seekPending = true;
  video.seekCompletedSignal = false;
  video.seekCompletedSignalFrame = -1;
  player->set_time(static_cast<double>(targetTime));
}

void ReleaseSyncedVideoPlayer(SyncedVideoPlayer& video, bool restoreAuthoredPlayer) {
  // Unsubscribe before destroying the proxy. A late Unity callback must never
  // retain a delegate that can reach a retired Vivify runtime generation.
  if (IsManagedAlive(video.player) && video.seekCompletedEventBound &&
      video.seekCompletedHandler != nullptr) {
    try {
      video.player->remove_seekCompleted(video.seekCompletedHandler);
    } catch (...) {
      // Teardown must be crash-safe even if Unity already retired the native
      // VideoPlayer while the managed wrapper still exists.
    }
  }
  video.seekCompletedHandler = nullptr;
  video.seekCompletedEventBound = false;
  video.seekCompletedSignal = false;
  video.seekCompletedSignalFrame = -1;
  if (restoreAuthoredPlayer && IsManagedAlive(video.authoredPlayer)) {
    video.authoredPlayer->set_enabled(video.authoredPlayerWasEnabled);
  }
  if (IsManagedAlive(video.decoderObject)) {
    UnityEngine::Object::Destroy(video.decoderObject);
  }
  video.player = nullptr;
  video.authoredPlayer = nullptr;
  video.decoderObject = nullptr;
  video.materialTarget = nullptr;
  video.renderTextureTarget = nullptr;
}

void ReleaseSyncedVideos(SyncedObject& synced, bool restoreAuthoredPlayer) {
  for (auto& video : synced.videoPlayers) {
    ReleaseSyncedVideoPlayer(video, restoreAuthoredPlayer);
  }
  synced.videoPlayers.clear();
}

void SetParticleClockSuppressed(SyncedParticleSystem& syncedParticle,
                                bool suppress) {
  auto* particleSystem = syncedParticle.particleSystem;
  if (!IsManagedAlive(particleSystem)) return;

  auto main = particleSystem->get_main();
  if (suppress) {
    if (!syncedParticle.clockSuppressed) {
      // Capture at the transition to a stopped song clock. Animator clips are
      // allowed to key this property every frame, so the current value—not the
      // prefab's original serialized value—is the one that must be restored.
      float const authoredSpeed = main.get_simulationSpeed();
      if (std::isfinite(authoredSpeed)) {
        syncedParticle.authoredSimulationSpeed = authoredSpeed;
      }
      syncedParticle.clockSuppressed = true;
    }
    main.set_simulationSpeed(0.0f);
    return;
  }

  if (syncedParticle.clockSuppressed) {
    main.set_simulationSpeed(syncedParticle.authoredSimulationSpeed);
    syncedParticle.clockSuppressed = false;
  }
}
}

Runtime& Runtime::Instance() {
  static Runtime runtime;
  return runtime;
}

bool Runtime::IsAlive(UnityEngine::Object* object) const {
  return IsManagedAlive(object);
}

bool Runtime::LateLoad() {
  // Vivify calls directly into CustomJSONData and Tracks. Scotland2 can report a
  // dependency as present at the ELF level while its mod init/late_load failed.
  // Continuing in that state turns an install/load-order problem into a native
  // crash during startup or the first gameplay callback. Fail closed instead.
  auto cjdModInfo = CustomJSONData::modInfo.to_c();
  auto tracksModInfo = CModInfo{.id = "Tracks"};
  auto const cjdResult = modloader_require_mod(&cjdModInfo, CMatchType::MatchType_IdOnly);
  auto const tracksResult = modloader_require_mod(&tracksModInfo, CMatchType::MatchType_IdOnly);
  if (cjdResult != CLoadResultEnum::MatchType_Loaded ||
      tracksResult != CLoadResultEnum::MatchType_Loaded) {
    PaperLogger.error(
        "Vivify disabled for this launch because required mods failed to load (CustomJSONData={} Tracks={})",
        static_cast<int>(cjdResult), static_cast<int>(tracksResult));
    return false;
  }

  EnsureBehaviour();
  if (!SongCore::API::Capabilities::IsCapabilityRegistered(kCapability)) {
    SongCore::API::Capabilities::RegisterCapability(kCapability);
  }
  CustomJSONData::CustomEventCallbacks::AddCustomEventCallback(&Runtime::OnCustomEventStatic);
  SongCore::API::LevelSelect::GetLevelWasSelectedEvent() += [](SongCore::API::LevelSelect::LevelWasSelectedEventArgs const& event) {
    try {
      Runtime::Instance().HandleLevelSelected(event);
    } catch (std::exception const& ex) {
      try { PaperLogger.error("Vivify level-selection callback failed safely: {}", ex.what()); } catch (...) {}
    } catch (...) {
      try { PaperLogger.error("Vivify level-selection callback failed safely with a non-std exception"); } catch (...) {}
    }
  };
  return true;
}

void Runtime::EnsureBehaviour() {
  if (_behaviour != nullptr) {
    return;
  }
  auto* gameObject = UnityEngine::GameObject::New_ctor(u"VivifyRuntime");
  UnityEngine::Object::DontDestroyOnLoad(gameObject);
  _behaviour = gameObject->AddComponent<RuntimeBehaviour*>();
  RefreshCameraComponents(false);
}

void Runtime::OnBehaviourDestroyed(RuntimeBehaviour* behaviour) {
  if (_behaviour == behaviour) _behaviour = nullptr;
}

void Runtime::OnCustomEventStatic(GlobalNamespace::BeatmapCallbacksController* callbackController,
                                  CustomJSONData::CustomEventData* customEventData) {
  // Never unwind C++ exceptions through CustomJSONData/IL2CPP callback frames.
  // Event dispatch itself is isolated, but first-event beatmap preparation also
  // performs bundle/prefab/camera work and previously sat outside that guard.
  try {
    Runtime::Instance().HandleCustomEvent(callbackController, customEventData);
  } catch (std::exception const& ex) {
    try { PaperLogger.error("Vivify custom-event callback failed safely: {}", ex.what()); } catch (...) {}
  } catch (...) {
    try { PaperLogger.error("Vivify custom-event callback failed safely with a non-std exception"); } catch (...) {}
  }
}

void Runtime::Update() {
  try {
    if (_isResetting) return;

    // Beatmap callbacks can outlive the gameplay scene by several frames.
    // Leaving authored materials and CameraApplier active during that window
    // attached them to MenuMainCamera and eventually passed a destroyed
    // Material into CommandBuffer.Blit.  The transition reset is deliberately
    // pointer-free, so it is safe even after Unity has begun scene teardown.
    if (_currentBeatmapData != nullptr && IsMainMenuSceneActive()) {
      PaperLogger.info("Vivify detected MainMenu with live beatmap state; applying transition-safe reset");
      ResetRuntime(ResetMode::LateSceneTransition);
      return;
    }

    if (_currentBeatmapData == nullptr) {
      // Bundle video decoding begins in the menu. Keep its readiness gate
      // moving even though no gameplay beatmap is active yet.
      UpdateBundleVideoWarmups();
      // A seek can intentionally tear down live state. Rebuild from the active
      // gameplay callback, but do not probe every menu frame while Unity is
      // still constructing or destroying that callback.
      TryPrepareSelectedBeatmapFromScene();
      if (_currentBeatmapData == nullptr) return;
    }
    if (!_lifecycle.IsActive()) return;

    // Scene transitions can invalidate the cached controller before the
    // beatmap callbacks disappear. Reacquire it instead of permanently
    // disabling Vivify's frame updates for the rest of the level.
    if (!IsAlive(_audioTimeSyncController)) {
      _audioTimeSyncController =
          UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
    }
    if (!IsAlive(_audioTimeSyncController)) return;

    DetectSongRestart();
    // DetectSongRestart can call ResetRuntime(), which clears all beatmap
    // state. Never continue into the update systems after that reset.
    if (_isResetting || _currentBeatmapData == nullptr) return;

    // A malformed map component should not prevent unrelated systems (most
    // importantly Blit expiry) from running. Keep every subsystem isolated
    // and identify the failing one in the log.
    auto runUpdateStep = [this](char const* name, auto&& step) {
      try {
        step();
      } catch (std::exception const& ex) {
        LogThrottledUpdateError(std::string(name) + ": " + ex.what());
      } catch (...) {
        LogThrottledUpdateError(std::string(name) + ": non-std exception");
      }
    };

    runUpdateStep("UpdateStartupPostProcessingEvents",
                  [this]() { UpdateStartupPostProcessingEvents(); });
    runUpdateStep("UpdatePrefabPrewarm", [this]() { UpdatePrefabPrewarm(); });
    runUpdateStep("UpdateMaterialAnimations", [this]() { UpdateMaterialAnimations(); });
    runUpdateStep("UpdateGlobalAnimations", [this]() { UpdateGlobalAnimations(); });
    runUpdateStep("UpdateAnimatorAnimations", [this]() { UpdateAnimatorAnimations(); });
    runUpdateStep("UpdateRenderSettingAnimations",
                  [this]() { UpdateRenderSettingAnimations(); });
    runUpdateStep("UpdateBlitEffects", [this]() { UpdateBlitEffects(); });
    runUpdateStep("UpdateSyncedObjects", [this]() { UpdateSyncedObjects(); });
    runUpdateStep("UpdatePrefabAnimationSpeed",
                  [this]() { UpdatePrefabAnimationSpeed(); });

    runUpdateStep("DeferredSaberVisuals", [this]() {
      int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
      if (_deferredSaberVisualsUntilFrame < 0 ||
          frame < _deferredSaberVisualsUntilFrame) {
        return;
      }
      if (_currentBeatmapData != nullptr && !_isResetting) {
        VIVIFY_DEBUG("Vivify applying deferred/retry saber assignment");
        ApplySaberVisualsToActive();
      }
      _deferredSaberVisualsUntilFrame =
          frame < _saberVisualRetryUntilFrame ? frame + 15 : -1;
    });
    runUpdateStep("UpdateSaberReplacementColors",
                  [this]() { UpdateSaberReplacementColors(); });

    // Refresh last so a Blit dispatched by the startup queue is visible for
    // its intended frame, and so expired effects disable the applier again.
    runUpdateStep("RefreshCameraComponents",
                  [this]() { RefreshCameraComponents(true); });
    runUpdateStep("LogQuestPerformanceHeartbeat",
                  [this]() { LogQuestPerformanceHeartbeat(); });
  } catch (std::exception const& ex) {
    LogThrottledUpdateError(std::string("Runtime::Update: ") + ex.what());
  } catch (...) {
    LogThrottledUpdateError("Runtime::Update: non-std exception");
  }
}

void Runtime::TryPrepareSelectedBeatmapFromScene() {
  if (!_selectedMapHasVivifyRequirement || _selectedLevelPath.empty() ||
      _mainBundle == nullptr || !UnityEngine::Object::op_Implicit_bool(_mainBundle) ||
      _beatmapCallbacksController == nullptr) return;

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame < _nextBeatmapPrepareProbeFrame) return;
  _nextBeatmapPrepareProbeFrame = frame + 15;

  auto* audioController =
      UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
  if (!IsAlive(audioController)) return;

  auto* customBeatmapData = GetCustomBeatmapData(_beatmapCallbacksController);
  if (customBeatmapData == nullptr) return;
  float const triggerTime = std::max(0.0f, audioController->get_songTime());
  VIVIFY_DEBUG("Vivify proactive gameplay prepare: customEvents={} songTime={}",
               customBeatmapData->customEventDatas.size(), triggerTime);
  PrepareBeatmap(customBeatmapData, triggerTime, _beatmapCallbacksController);
}

void Runtime::LogThrottledUpdateError(std::string_view what) {

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame - _lastUpdateErrorFrame < 60) return;
  _lastUpdateErrorFrame = frame;
  PaperLogger.error("Vivify Update threw (frame {}, songTime {}): {} — repeats suppressed ~1s",
                    frame, _songTimeCache, std::string(what));
}

float Runtime::CurrentSongTime() {

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame == _songTimeCacheFrame) return _songTimeCache;
  _songTimeCacheFrame = frame;
  // BeatmapCallbacksController is the authoritative clock used to fire the
  // same callbacks that drive notes and cubes. Prefer it over a globally found
  // AudioTimeSyncController so Vivify cannot bind to a stale controller during
  // practice/catch-up or a gameplay-scene transition.
  if (_beatmapCallbacksController != nullptr) {
    _songTimeCache = _beatmapCallbacksController->get_songTime();
    return _songTimeCache;
  }
  if (!IsAlive(_audioTimeSyncController)) {
    _audioTimeSyncController = UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
  }
  _songTimeCache = IsAlive(_audioTimeSyncController) ? _audioTimeSyncController->get_songTime() : 0.0f;
  return _songTimeCache;
}

void Runtime::DetectSongRestart() {
  if (_currentBeatmapData == nullptr || _isResetting) return;
  float songTime = CurrentSongTime();
  // Only reset if there's a significant backward jump (>0.25 second) to avoid
  // false positives at song start (0:00) or small timing adjustments
  if (_lastSongTime >= 0.0f && songTime + 0.25f < _lastSongTime) {
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    bool const restartingFromPause =
        _pauseMenuActive && songTime <= 0.25f && _lastSongTime > 1.0f;
    if (restartingFromPause) {
      // The RestartButtonPressed hook normally retires the session before the
      // scene is dismissed. This remains as a live-scene fallback for practice
      // controllers that seek without invoking the pause-menu method.
      VIVIFY_DEBUG("Vivify detected pause-menu restart; retiring the active session");
      ResetRuntime(ResetMode::LiveScene);
      _nextBeatmapPrepareProbeFrame = frame + 90;
    } else {
      ResetRuntime();
    }
    return;
  }
  _lastSongTime = songTime;
}

float Runtime::CurrentBpm() const {
  if (TracksStatic::bpmController) {
    return TracksStatic::bpmController->get_currentBpm();
  }
  return 0.0f;
}

float Runtime::DurationBeatsToSeconds(float durationBeats) const {
  float bpm = CurrentBpm();
  if (bpm <= 0.0f) {
    return 0.0f;
  }
  return (60.0f * durationBeats) / bpm;
}

void Runtime::RegisterSyncedObject(UnityEngine::GameObject* root,
                                   float eventStartSongTime) {
  if (!IsAlive(root)) return;

  // Prewarmed prefabs can register their persistent video decoders many seconds
  // before the actual InstantiatePrefab event. Reuse that prepared decoder when
  // the same instance goes live instead of destroying/recreating it at t=0.
  for (auto& existing : _syncedObjects) {
    if (existing.root != root) continue;
    existing.startTime = eventStartSongTime;
    existing.needsInitialTimelineSample = true;
    existing.nextVideoClockPollFrame = 0;
    // A prewarmed object can become live after the global playback rate was
    // already applied. Force this newly-live component set to receive the
    // current clock-gated rate on the next update.
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    for (auto& video : existing.videoPlayers) {
      video.needsStartupKick = true;
      video.nextStartRetryFrame = 0;
      video.hasProducedTexture = false;
      video.lastDecodedFrame = -1;
      // A prewarmed object can become live after practice speed changed.  Rate
      // state is per decoder, so force this video to receive the current rate.
      video.lastAppliedPlaybackSpeed = std::numeric_limits<float>::quiet_NaN();
      video.seekPending = false;
      video.seekCompletedSignal = false;
      video.seekCompletedSignalFrame = -1;
      video.recoveryAttempts = 0;
      video.waitingForClockStart = false;
      video.failed = false;
    }
    VIVIFY_DEBUG("Vivify sync: reusing prewarmed synced object '{}' for eventStart={}",
                 ToStdString(root->get_name()), eventStartSongTime);
    return;
  }

  float const currentSongTime = CurrentSongTime();
  float const initialElapsed =
      PrefabInitialElapsed(currentSongTime, eventStartSongTime);
  SyncedObject synced;
  synced.root = root;
  // Videos remain tied to the absolute event time; only Animator.Update uses
  // the elapsed time inside the prefab.
  synced.startTime = eventStartSongTime;

  auto videoPlayers = root->GetComponentsInChildren<UnityEngine::Video::VideoPlayer*>(true);
  for (int i = 0; i < videoPlayers.size(); i++) {
    auto* authored = videoPlayers[i];
    if (!IsAlive(authored) || !authored->get_playOnAwake()) continue;

    auto const authoredRenderMode = authored->get_renderMode();
    UnityEngine::Renderer* materialTarget = nullptr;
    UnityEngine::RenderTexture* renderTextureTarget = nullptr;
    if (authoredRenderMode.value__ ==
        UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
      auto targetReference = authored->get_targetMaterialRenderer();
      materialTarget = targetReference.unsafePtr();
      if (!IsAlive(materialTarget)) {
        materialTarget = authored->GetComponent<UnityEngine::Renderer*>();
        if (!IsAlive(materialTarget)) {
          materialTarget = authored->GetComponentInChildren<UnityEngine::Renderer*>(true);
        }
        if (IsAlive(materialTarget)) {
          authored->set_targetMaterialRenderer(materialTarget);
          if (ToStdString(authored->get_targetMaterialProperty()).empty()) {
            authored->set_targetMaterialProperty(StringW("_MainTex"));
          }
          PaperLogger.info(
              "Vivify repaired embedded VideoPlayer target: object='{}' renderer='{}' property='{}'",
              ToStdString(authored->get_gameObject()->get_name()),
              ToStdString(materialTarget->get_gameObject()->get_name()),
              ToStdString(authored->get_targetMaterialProperty()));
        } else {
          PaperLogger.warn(
              "Vivify embedded VideoPlayer has no MaterialOverride renderer: object='{}'",
              ToStdString(authored->get_gameObject()->get_name()));
        }
      }
    } else if (authoredRenderMode.value__ ==
               UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
      auto targetReference = authored->get_targetTexture();
      renderTextureTarget = targetReference.unsafePtr();
      if (IsAlive(renderTextureTarget)) {
        if (!renderTextureTarget->IsCreated()) renderTextureTarget->Create();
      } else {
        PaperLogger.warn(
            "Vivify embedded VideoPlayer has no RenderTexture target: object='{}'",
            ToStdString(authored->get_gameObject()->get_name()));
      }
    }

    SyncedVideoPlayer video;
    video.authoredPlayer = authored;
    video.player = authored;
    video.materialTarget = materialTarget;
    video.renderTextureTarget = renderTextureTarget;
    video.authoredPlayerWasEnabled = authored->get_enabled();

    // Unity VideoPlayer preparation does not progress on an inactive prefab.
    // Move both MaterialOverride and RenderTexture playback to an always-active
    // decoder. Embedded clips can adopt the decoder that was already warmed
    // while the song was selected in the menu.
    bool const supportsPersistentOutput =
        (authoredRenderMode.value__ ==
             UnityEngine::Video::VideoRenderMode::MaterialOverride.value__ &&
         IsAlive(materialTarget)) ||
        (authoredRenderMode.value__ ==
             UnityEngine::Video::VideoRenderMode::RenderTexture.value__ &&
         IsAlive(renderTextureTarget));
    if (supportsPersistentOutput && IsManagedAlive(_behaviour)) {
      UnityEngine::GameObject* decoderObject = nullptr;
      UnityEngine::Video::VideoPlayer* decoder = nullptr;
      bool adoptedWarmup = false;
      if (authored->get_source().value__ == 0) {
        auto clipReference = authored->get_clip();
        decoder = ClaimBundleVideoWarmup(clipReference.unsafePtr(), decoderObject);
        adoptedWarmup = IsAlive(decoder) && IsAlive(decoderObject);
      }

      if (!adoptedWarmup) {
        decoderObject = UnityEngine::GameObject::New_ctor(u"VivifyVideoDecoder");
      }
      if (IsAlive(decoderObject)) {
        // Never deactivate an adopted warmup: on Quest that can retire the
        // MediaCodec instance we are deliberately carrying into gameplay.
        if (!adoptedWarmup) decoderObject->SetActive(false);
        auto behaviourObject = _behaviour->get_gameObject();
        auto* behaviourObjectPtr = behaviourObject.unsafePtr();
        if (IsAlive(behaviourObjectPtr)) {
          decoderObject->get_transform()->SetParent(behaviourObjectPtr->get_transform(), false);
        }
        if (!adoptedWarmup) {
          decoder = decoderObject->AddComponent<UnityEngine::Video::VideoPlayer*>();
        }
        if (IsAlive(decoder)) {
          if (decoder->get_isPlaying()) decoder->Pause();
          if (!adoptedWarmup) {
            // Setting clip/url also selects the matching VideoSource in Unity.
            if (authored->get_source().value__ == 0) {
              decoder->set_clip(authored->get_clip());
            } else {
              decoder->set_url(authored->get_url());
            }
          }
          decoder->set_renderMode(authoredRenderMode);
          if (authoredRenderMode.value__ ==
              UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
            decoder->set_targetMaterialRenderer(materialTarget);
            auto property = authored->get_targetMaterialProperty();
            if (ToStdString(property).empty()) property = StringW("_MainTex");
            decoder->set_targetMaterialProperty(property);
          } else {
            if (!renderTextureTarget->IsCreated()) renderTextureTarget->Create();
            decoder->set_targetTexture(renderTextureTarget);
          }
          auto audioOutputMode = decoder->get_audioOutputMode();
          audioOutputMode.value__ = 0;  // VideoAudioOutputMode::None without linking enum statics.
          decoder->set_audioOutputMode(audioOutputMode);
          decoder->set_playOnAwake(false);
          decoder->set_waitForFirstFrame(true);
          decoder->set_isLooping(authored->get_isLooping());
          decoder->set_skipOnDrop(false);
          decoderObject->SetActive(true);

          if (authored->get_isPlaying()) authored->Pause();
          authored->set_playOnAwake(false);
          authored->set_enabled(false);

          video.player = decoder;
          video.decoderObject = decoderObject;
          video.persistentDecoder = true;
          EnsureVideoOutputBinding(video);
          PaperLogger.info(
              "Vivify {} persistent Quest video decoder: object='{}' output='{}' target='{}' prepared={}",
              adoptedWarmup ? "adopted menu-warmed" : "created",
              ToStdString(authored->get_gameObject()->get_name()),
              authoredRenderMode.value__ ==
                      UnityEngine::Video::VideoRenderMode::RenderTexture.value__
                  ? "RenderTexture"
                  : "MaterialOverride",
              IsAlive(renderTextureTarget)
                  ? ToStdString(renderTextureTarget->get_name())
                  : (IsAlive(materialTarget)
                         ? ToStdString(materialTarget->get_gameObject()->get_name())
                         : std::string("<missing>")),
              decoder->get_isPrepared());
        } else {
          UnityEngine::Object::Destroy(decoderObject);
        }
      }
    }

    auto* vp = video.player;
    if (!IsAlive(vp)) continue;
    if (!video.persistentDecoder) {
      if (vp->get_isPlaying()) vp->Pause();
      vp->set_playOnAwake(false);
      vp->set_skipOnDrop(false);
    }

    video.needsStartupKick = true;
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    video.nextStartRetryFrame = frame;
    video.nextOutputRecoveryFrame = frame;
    video.lastDecodedFrameAdvanceFrame = frame;
    if (!vp->get_isPrepared()) {
      vp->Prepare();
      video.preparePending = true;
      // Large embedded clips can need several seconds to reserve MediaCodec
      // resources on Quest. Do not repeatedly restart that asynchronous work.
      video.nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames;
    }

    // PC Vivify uses VideoPlayer.seekCompleted as the authoritative end of a
    // seek. Do the same on Quest so an Android keyframe exposed while the seek
    // is still in flight can never be mistaken for the requested frame.
    try {
      video.seekCompletedHandler =
          custom_types::MakeDelegate<UnityEngine::Video::VideoPlayer_EventHandler*>(
              std::function<void(UnityEngine::Video::VideoPlayer*)>(
                  [this](UnityEngine::Video::VideoPlayer* source) {
                    HandleVideoSeekCompleted(source);
                  }));
      if (video.seekCompletedHandler != nullptr) {
        vp->add_seekCompleted(video.seekCompletedHandler);
        video.seekCompletedEventBound = true;
      }
    } catch (...) {
      video.seekCompletedHandler = nullptr;
      video.seekCompletedEventBound = false;
      PaperLogger.warn(
          "Vivify could not bind VideoPlayer.seekCompleted; exact-state watchdog fallback will be used");
    }
    synced.videoPlayers.emplace_back(video);
  }

  float initialSyncSpeed = 0.0f;
  if (!_pauseMenuActive && _syncClockHasAdvanced && IsManagedAlive(_audioTimeSyncController)) {
    float const authoredSpeed = _audioTimeSyncController->get_timeScale();
    float const clockDerivedSpeed =
        std::isfinite(_lastAppliedSyncSpeed) && _lastAppliedSyncSpeed > 0.0f
            ? _lastAppliedSyncSpeed
            : authoredSpeed;
    if (std::isfinite(clockDerivedSpeed) && clockDerivedSpeed > 0.0f) {
      initialSyncSpeed = clockDerivedSpeed;
    }
  }

  auto animators = root->GetComponentsInChildren<UnityEngine::Animator*>(true);
  for (int i = 0; i < animators.size(); i++) {
    if (!IsAlive(animators[i])) continue;
    animators[i]->set_updateMode(UnityEngine::AnimatorUpdateMode::Normal);
    // Vivify's authored environment animations are song-timed, not visibility-
    // timed. In normal gameplay a large note/custom-model renderer can make a
    // prefab briefly fail Unity's renderer-visibility culling while Zen mode
    // never does. Never let Animator culling stop the authored timeline.
    animators[i]->set_cullingMode(UnityEngine::AnimatorCullingMode::AlwaysAnimate);
  }

  // A random/practice start can instantiate a prefab after its authored
  // VideoPlayer GameObject was enabled earlier in the animation. Prefab event
  // time is therefore not necessarily video time-zero. Probe the animation only
  // when we actually need historical state, keep the sample count bounded, and
  // never drive a live decoder during the probe (playOnAwake is already false).
  bool historicalVideoProbeRan = false;
  if (initialElapsed > 0.05f && !synced.videoPlayers.empty()) {
    historicalVideoProbeRan = true;
    std::vector<float> firstActiveOffsets(synced.videoPlayers.size(), -1.0f);

    if (animators.size() == 0) {
      // With no Animator there is no delayed authored activation to discover.
      for (std::size_t videoIndex = 0; videoIndex < synced.videoPlayers.size(); videoIndex++) {
        if (IsAuthoredVideoGameObjectActive(synced.videoPlayers[videoIndex])) {
          firstActiveOffsets[videoIndex] = 0.0f;
        }
      }
    } else {
      // Rebind once, then advance monotonically to the requested historical
      // pose. Repeated backward/forward Rebind probing corrupted complex
      // Animator state machines on Quest (Teto teleporting on random starts).
      for (int i = 0; i < animators.size(); i++) {
        if (!IsAlive(animators[i])) continue;
        animators[i]->Rebind();
        animators[i]->Update(0.0f);
      }

      for (std::size_t videoIndex = 0; videoIndex < synced.videoPlayers.size(); videoIndex++) {
        if (IsAuthoredVideoGameObjectActive(synced.videoPlayers[videoIndex])) {
          firstActiveOffsets[videoIndex] = 0.0f;
        }
      }

      int const sampleCount = std::max(1, std::min(
          kHistoricalVideoProbeMaxSamples,
          static_cast<int>(std::ceil(initialElapsed / kHistoricalVideoProbeTargetStepSeconds))));
      float previousSample = 0.0f;
      for (int sampleIndex = 1; sampleIndex <= sampleCount; sampleIndex++) {
        float const sampleTime =
            initialElapsed * static_cast<float>(sampleIndex) / static_cast<float>(sampleCount);
        float const delta = std::max(0.0f, sampleTime - previousSample);
        for (int i = 0; i < animators.size(); i++) {
          if (IsAlive(animators[i])) animators[i]->Update(delta);
        }
        for (std::size_t videoIndex = 0; videoIndex < synced.videoPlayers.size(); videoIndex++) {
          if (firstActiveOffsets[videoIndex] < 0.0f &&
              IsAuthoredVideoGameObjectActive(synced.videoPlayers[videoIndex])) {
            firstActiveOffsets[videoIndex] = sampleTime;
          }
        }
        previousSample = sampleTime;
      }
      // The final sample is exactly initialElapsed, so the live Animator graph
      // is already in the requested pose without another destructive Rebind.
    }

    for (std::size_t videoIndex = 0; videoIndex < synced.videoPlayers.size(); videoIndex++) {
      float const activationOffset = firstActiveOffsets[videoIndex];
      if (activationOffset < 0.0f || activationOffset > initialElapsed + 0.001f) continue;
      auto& video = synced.videoPlayers[videoIndex];
      video.playbackStartKnown = true;
      video.playbackStartSongTime = eventStartSongTime + activationOffset;
      video.playbackTimelineStarted = currentSongTime + 0.001f >= video.playbackStartSongTime;
      video.needsStartupKick = true;
      video.seekPending = false;
      video.seekCompletedSignal = false;
      video.seekCompletedSignalFrame = -1;
      video.recoveryAttempts = 0;
      video.waitingForClockStart = false;
      VIVIFY_DEBUG(
          "Vivify sync: historical video activation recovered offset={} eventStart={} videoStart={} currentSongTime={}",
          activationOffset, eventStartSongTime, video.playbackStartSongTime, currentSongTime);
    }
  }

  for (int i = 0; i < animators.size(); i++) {
    if (!IsAlive(animators[i])) continue;
    if (initialElapsed > 0.0f && !historicalVideoProbeRan) {
      animators[i]->Update(initialElapsed);
    }
    // Freeze the exact catch-up pose until the authoritative song clock is seen
    // moving. This removes practice-load drift between Zen and normal gameplay.
    animators[i]->set_speed(initialSyncSpeed);
    synced.animators.emplace_back(animators[i]);
  }
  auto legacyAnimations = root->GetComponentsInChildren<UnityEngine::Animation*>(true);
  for (int i = 0; i < legacyAnimations.size(); i++) {
    auto* animation = legacyAnimations[i];
    if (!IsAlive(animation) || !animation->get_playAutomatically()) continue;
    auto* state = DefaultLegacyAnimationState(animation);
    if (state == nullptr || !UnityEngine::TrackedReference::op_Implicit_bool(state)) continue;

    // Unity's legacy Animation clock is independent from AudioTimeSyncController.
    // Dynasty's lyrics and environment prefabs use this component rather than
    // Animator, so sample the authored clip at the actual practice/song time.
    if (initialElapsed > 0.0f) {
      state->set_time(initialElapsed);
      animation->Sample();
    }
    state->set_speed(initialSyncSpeed);
    synced.legacyAnimations.emplace_back(animation);
  }
  auto particleSystems = root->GetComponentsInChildren<UnityEngine::ParticleSystem*>(true);
  for (int i = 0; i < particleSystems.size(); i++) {
    if (!IsAlive(particleSystems[i])) continue;
    auto main = particleSystems[i]->get_main();
    SyncedParticleSystem syncedParticle{
        .particleSystem = particleSystems[i],
        .authoredSimulationSpeed = main.get_simulationSpeed(),
        .clockSuppressed = false,
    };
    SetParticleClockSuppressed(syncedParticle, initialSyncSpeed <= 0.0f);
    synced.particleSystems.emplace_back(syncedParticle);
  }

  if (!synced.videoPlayers.empty() || !synced.animators.empty() ||
      !synced.legacyAnimations.empty() || !synced.particleSystems.empty()) {
    VIVIFY_DEBUG("Vivify sync: registered '{}' with {} video / {} animator / {} legacy animation / {} particle component(s), eventStart={} songTime={} initialElapsed={}",
                 IsAlive(root) ? ToStdString(root->get_name()) : std::string("?"),
                 synced.videoPlayers.size(), synced.animators.size(),
                 synced.legacyAnimations.size(), synced.particleSystems.size(),
                 eventStartSongTime, currentSongTime, initialElapsed);
    _syncedObjects.emplace_back(std::move(synced));
    // A newly registered animator/particle system must receive the current
    // practice speed even if that speed did not change this frame.
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
  }
}

void Runtime::UpdatePrefabAnimationSpeed() {
  if (_syncedObjects.empty()) {
    bool const controllerUnavailable = !IsManagedAlive(_audioTimeSyncController);
    float const songTime = controllerUnavailable ? -1.0f : CurrentSongTime();
    float const timeScale = controllerUnavailable ? 0.0f : _audioTimeSyncController->get_timeScale();
    // Observe the callback clock even before the first synchronized prefab is
    // spawned. A mid-song prefab can then start immediately, while a practice
    // catch-up prefab created during a frozen pre-roll remains pinned.
    (void) ClockGatedSyncRate(_pauseMenuActive || controllerUnavailable,
                              _lastSyncSongTime, songTime, timeScale,
                              _syncClockStallFrames, _syncClockHasAdvanced);
    if (!controllerUnavailable) _lastSyncSongTime = songTime;
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    return;
  }

  bool const controllerUnavailable = !IsManagedAlive(_audioTimeSyncController);
  float const songTime = controllerUnavailable ? -1.0f : CurrentSongTime();
  float const timeScale = controllerUnavailable ? 0.0f : _audioTimeSyncController->get_timeScale();
  float const gatedRate = ClockGatedSyncRate(_pauseMenuActive || controllerUnavailable,
                                              _lastSyncSongTime, songTime, timeScale,
                                              _syncClockStallFrames,
                                              _syncClockHasAdvanced);
  float const speed = SongDeltaSyncRate(
      gatedRate, _lastSyncSongTime, songTime,
      UnityEngine::Time::get_deltaTime(), _lastAppliedSyncSpeed);
  if (!controllerUnavailable) _lastSyncSongTime = songTime;

  if (!MeaningfulRateChange(_lastAppliedSyncSpeed, speed)) return;
  _lastAppliedSyncSpeed = speed;

  auto drive = [speed](std::vector<UnityEngine::Animator*> const& animators,
                       std::vector<UnityEngine::Animation*> const& legacyAnimations,
                       std::vector<SyncedParticleSystem>& particleSystems) {
    for (auto* animator : animators) {
      if (IsManagedAlive(animator)) animator->set_speed(speed);
    }
    for (auto* animation : legacyAnimations) {
      SetLegacyAnimationSpeed(animation, speed);
    }
    for (auto& particleSystem : particleSystems) {
      // Animator-authored ParticleSystem speed curves own the running value.
      // Vivify only suppresses/restores them at song-clock stop transitions.
      SetParticleClockSuppressed(particleSystem, speed <= 0.0f);
    }
  };
  for (auto& synced : _syncedObjects) {
    drive(synced.animators, synced.legacyAnimations, synced.particleSystems);
  }
}

void Runtime::LogQuestPerformanceHeartbeat() {
  if (!GetVivifyDebugLogging()) return;
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame - _lastQuestPerformanceFrame < 900) return;
  _lastQuestPerformanceFrame = frame;
  PaperLogger.info(
      "Vivify Quest perf window: frame={} midCacheHits={} midRebuilds={} imageBlits={} imageCommandBufferCreates={} noteRefreshEvents={} noteRefreshCandidates={} prefabLookupRebuilds={} synced={} livePrefabs={} replacements[note={} saber={} debris={}] declaredTextures={} secondaryCameras={}",
      frame, _midCommandBufferCacheHits, _midCommandBufferRebuilds,
      _imageBlitExecutions, _imageCommandBufferCreates, _noteRefreshEvents,
      _noteRefreshCandidates, _assignedPrefabLookupRebuilds, _syncedObjects.size(),
      _livePrefabs.size(), _noteReplacements.size(), _saberReplacements.size(),
      _debrisReplacements.size(), _declaredTextures.size(), _secondaryCameras.size());
  _midCommandBufferCacheHits = 0;
  _midCommandBufferRebuilds = 0;
  _imageBlitExecutions = 0;
  _imageCommandBufferCreates = 0;
  _noteRefreshEvents = 0;
  _noteRefreshCandidates = 0;
  _assignedPrefabLookupRebuilds = 0;
}

void Runtime::UnregisterSyncedObject(UnityEngine::GameObject* root) {
  for (auto& synced : _syncedObjects) {
    if (synced.root == root) ReleaseSyncedVideos(synced, false);
  }
  _syncedObjects.erase(std::remove_if(_syncedObjects.begin(), _syncedObjects.end(),
                                      [root](SyncedObject const& synced) { return synced.root == root; }),
                       _syncedObjects.end());
}

void Runtime::HandleVideoSeekCompleted(UnityEngine::Video::VideoPlayer* player) {
  if (!IsManagedAlive(player)) return;
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  for (auto& synced : _syncedObjects) {
    for (auto& video : synced.videoPlayers) {
      if (video.player != player || !video.seekPending) continue;
      video.seekCompletedSignal = true;
      video.seekCompletedSignalFrame = frame;
      return;
    }
  }
}

void Runtime::UpdateSyncedObjects() {
  if (_syncedObjects.empty()) return;
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  // Explicit DestroyObject paths unregister immediately. This cadence is only
  // a safety net for prefabs destroyed by their own animation/scripts, so a
  // full managed-object validity pass is unnecessary on every render frame.
  if (frame >= _nextSyncedObjectPurgeFrame) {
    _nextSyncedObjectPurgeFrame = frame + 30;
    for (auto& synced : _syncedObjects) {
      if (!IsManagedAlive(synced.root)) ReleaseSyncedVideos(synced, false);
    }
    _syncedObjects.erase(std::remove_if(_syncedObjects.begin(), _syncedObjects.end(),
                                        [](SyncedObject const& synced) { return !IsManagedAlive(synced.root); }),
                         _syncedObjects.end());
  }
  if (_syncedObjects.empty()) return;

  bool const paused = _pauseMenuActive || !IsManagedAlive(_audioTimeSyncController);
  float const songTime = IsManagedAlive(_audioTimeSyncController) ? CurrentSongTime() : 0.0f;
  float const playbackSpeed = IsManagedAlive(_audioTimeSyncController)
                                  ? _audioTimeSyncController->get_timeScale()
                                  : 0.0f;
  // VideoPlayer exposes a seekable time directly, but Unity's legacy
  // AnimationState does not.  Re-sample captions/environment clips on the
  // first live frame and after a real timeline jump (practice start, seek or
  // restart) so they follow the same absolute song clock as video and notes.
  float const unscaledDelta = std::max(1.0f / 240.0f, UnityEngine::Time::get_unscaledDeltaTime());
  float const expectedForwardAdvance = std::max(0.0f, playbackSpeed) * unscaledDelta;
  float const forwardJumpTolerance =
      std::max(0.5f, expectedForwardAdvance * 4.0f + 0.25f);
  bool const timelineJumped =
      _lastSyncSongTime >= 0.0f &&
      (songTime + 0.25f < _lastSyncSongTime ||
       songTime > _lastSyncSongTime + forwardJumpTolerance);

  bool const heartbeat = [&]() {
    if (!GetVivifyDebugLogging()) return false;
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    if (frame - _lastSyncHeartbeatFrame < 120) return false;
    _lastSyncHeartbeatFrame = frame;
    return true;
  }();

  for (auto& synced : _syncedObjects) {
    float const animationTime = std::max(0.0f, songTime - synced.startTime);
    if (synced.needsInitialTimelineSample || timelineJumped) {
      for (auto* animation : synced.legacyAnimations) {
        auto* state = DefaultLegacyAnimationState(animation);
        if (state == nullptr || !UnityEngine::TrackedReference::op_Implicit_bool(state)) continue;
        state->set_time(animationTime);
        animation->Sample();
      }
      synced.needsInitialTimelineSample = false;
      if (timelineJumped) {
        VIVIFY_DEBUG("Vivify sync: sampled legacy animation timeline at songTime={} startTime={} elapsed={}",
                     songTime, synced.startTime, animationTime);
      }
    }
    bool const pollVideoClock = timelineJumped || heartbeat ||
                                frame >= synced.nextVideoClockPollFrame;
    if (pollVideoClock) synced.nextVideoClockPollFrame = frame + 6;
    for (auto& video : synced.videoPlayers) {
      auto* vp = video.player;
      if (!IsManagedAlive(vp) || video.failed) continue;

      bool const authoredActive = IsAuthoredVideoGameObjectActive(video);

      // The real video origin is the first stable authored GameObject activation,
      // not the parent InstantiatePrefab event. Require two consecutive active
      // frames so an Animator transition cannot latch a one-frame transient.
      if (!video.playbackStartKnown && songTime + 0.001f >= synced.startTime) {
        if (authoredActive) {
          if (video.firstActiveObservedFrame < 0) {
            video.firstActiveObservedFrame = frame;
            video.firstActiveObservedSongTime = songTime;
          } else if (frame > video.firstActiveObservedFrame) {
            video.playbackStartKnown = true;
            video.playbackStartSongTime = video.firstActiveObservedSongTime;
            video.playbackTimelineStarted = true;
            video.needsStartupKick = true;
            video.nextStartRetryFrame = frame;
            video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
            VIVIFY_DEBUG(
                "Vivify sync: latched authored video start at songTime={} prefabStart={}",
                video.playbackStartSongTime, synced.startTime);
          }
        } else if (video.firstActiveObservedFrame >= 0) {
          video.firstActiveObservedFrame = -1;
          video.firstActiveObservedSongTime = 0.0f;
        }
      }

      if (video.playbackStartKnown) {
        bool const shouldTimelineRun =
            songTime + 0.001f >= video.playbackStartSongTime;
        if (shouldTimelineRun != video.playbackTimelineStarted) {
          video.playbackTimelineStarted = shouldTimelineRun;
          video.needsStartupKick = true;
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.nextStartRetryFrame = frame;
          video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
          video.seekPending = false;
          video.seekCompletedSignal = false;
          video.seekCompletedSignalFrame = -1;
          video.recoveryAttempts = 0;
          video.waitingForClockStart = false;
          if (!shouldTimelineRun) {
            if (vp->get_isPlaying()) vp->Pause();
            if (vp->get_isPrepared()) vp->set_time(0.0);
            video.requestedPrewarmFrame = false;
            video.decoderDormant = false;
          }
        }
      }

      float const rawVideoTime =
          video.playbackStartKnown
              ? std::max(0.0f, songTime - video.playbackStartSongTime)
              : 0.0f;
      float const videoTime = NormalizeVideoTime(vp, rawVideoTime);

      if (paused) {
        if (vp->get_isPlaying()) {
          VIVIFY_DEBUG("Vivify sync: pausing video (songTime={})", songTime);
          vp->Pause();
        }
        video.needsStartupKick = video.playbackTimelineStarted;
        video.waitingForClockStart = video.playbackTimelineStarted;
        video.seekPending = false;
        video.seekCompletedSignal = false;
        video.seekCompletedSignalFrame = -1;
        video.wasRenderable = false;
        video.outputGraceUntilFrame = 0;
        video.nextOutputRecoveryFrame = 0;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.nextDriftCorrectionFrame = 0;
        continue;
      }

      // Preparation is asynchronous on Android. Never restart it on a short
      // watchdog and never touch playbackSpeed before it completes.
      if (!vp->get_isPrepared()) {
        if (!video.preparePending || frame >= video.nextPrepareRetryFrame) {
          if (video.prepareRetryCount >= 3) {
            video.failed = true;
            PaperLogger.error(
                "Vivify video disabled after repeated Prepare failures: object='{}' songTime={}",
                IsManagedAlive(video.authoredPlayer)
                    ? ToStdString(video.authoredPlayer->get_gameObject()->get_name())
                    : std::string("<unknown>"),
                songTime);
            continue;
          }
          VIVIFY_DEBUG(
              "Vivify sync: starting/retrying video Prepare after watchdog (songTime={} videoTime={} attempt={})",
              songTime, videoTime, video.prepareRetryCount + 1);
          vp->Prepare();
          video.preparePending = true;
          video.prepareRetryCount++;
          video.nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames;
        }
        video.needsStartupKick = true;
        continue;
      }
      video.preparePending = false;
      video.prepareRetryCount = 0;
      video.nextPrepareRetryFrame = 0;

      // Match desktop Vivify: the decoder always runs at the authored practice
      // rate. Quest never receives a faster hidden catch-up rate.
      if (playbackSpeed > 0.001f &&
          MeaningfulRateChange(video.lastAppliedPlaybackSpeed, playbackSpeed)) {
        try {
          vp->set_playbackSpeed(playbackSpeed);
          video.lastAppliedPlaybackSpeed = playbackSpeed;
        } catch (...) {
          // Keep the cached rate dirty so a later prepared frame retries once.
          video.lastAppliedPlaybackSpeed = std::numeric_limits<float>::quiet_NaN();
        }
      }

      if (video.persistentDecoder && !video.playbackTimelineStarted) {
        // Reserve MediaCodec and one real frame before the authored video begins,
        // then pause. This preserves instant startup without spending decoder
        // cycles for the entire pre-video section.
        if (!video.requestedPrewarmFrame) {
          vp->set_time(0.0);
          vp->Play();
          video.requestedPrewarmFrame = true;
          video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;
          video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          VIVIFY_DEBUG("Vivify sync: primed persistent video decoder before event start={}",
                       synced.startTime);
        }
        if (video.hasProducedTexture) {
          if (vp->get_isPlaying()) vp->Pause();
          continue;
        }
        std::int64_t decodedFrame = -1;
        if (HasDecodedVideoOutput(vp, decodedFrame)) {
          EnsureVideoOutputBinding(video);
          video.hasProducedTexture = true;
          video.lastDecodedFrame = decodedFrame;
          video.lastDecodedFrameAdvanceFrame = frame;
          if (vp->get_isPlaying()) vp->Pause();
          continue;
        }
        if (frame >= video.outputGraceUntilFrame &&
            frame >= video.nextOutputRecoveryFrame) {
          if (video.recoveryAttempts >= kVideoMaxRecoveryAttempts) {
            video.failed = true;
            if (vp->get_isPlaying()) vp->Pause();
            PaperLogger.error("Vivify prewarmed video produced no frame; disabling decoder");
            continue;
          }
          video.recoveryAttempts++;
          vp->set_time(0.0);
          if (!vp->get_isPlaying()) vp->Play();
          video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;
          video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
        }
        continue;
      }

      // Desktop's sync component lives on the authored VideoPlayer GameObject.
      // When that GameObject is inactive its Update does not run, so Quest must
      // not burn MediaCodec cycles behind the scenes either. Keep the proxy
      // prepared, but pause decoding until the authored object is active again.
      if (video.persistentDecoder && video.playbackTimelineStarted && !authoredActive) {
        if (vp->get_isPlaying()) vp->Pause();
        video.decoderDormant = true;
        video.lastAuthoredActive = false;
        video.wasRenderable = false;
        video.waitingForClockStart = false;
        video.seekPending = false;
        video.seekCompletedSignal = false;
        video.seekCompletedSignalFrame = -1;
        continue;
      }

      if (video.playbackTimelineStarted && authoredActive &&
          (video.decoderDormant || !video.lastAuthoredActive)) {
        video.decoderDormant = false;
        video.needsStartupKick = true;
        video.nextStartRetryFrame = frame;
        video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
      }
      video.lastAuthoredActive = authoredActive;

      if (!video.playbackTimelineStarted) {
        if (vp->get_isPlaying()) vp->Pause();
        continue;
      }

      if (timelineJumped) {
        video.needsStartupKick = true;
        video.seekPending = false;
        video.seekCompletedSignal = false;
        video.seekCompletedSignalFrame = -1;
        video.recoveryAttempts = 0;
        video.nextStartRetryFrame = frame;
        video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
      }

      bool const songClockRunning =
          playbackSpeed > 0.001f &&
          (_syncClockHasAdvanced ||
           (_lastSyncSongTime >= 0.0f && songTime > _lastSyncSongTime + 0.0001f));

      if (video.waitingForClockStart && songClockRunning) {
        // The historical frame was already positioned while the Beat Saber song
        // clock was frozen. Start from the authoritative current time without a
        // decoder-speed burst.
        video.needsStartupKick = true;
        video.waitingForClockStart = false;
      }

      if (video.needsStartupKick) {
        EnsureVideoOutputBinding(video);
        BeginVideoSeek(video, videoTime, frame, vp->get_frame());
        video.needsStartupKick = false;
        video.recoveryAttempts = 0;
        video.hasProducedTexture = false;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;
        video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
        video.nextStartRetryFrame = frame + 30;
        video.nextDriftCorrectionFrame = frame + kVideoDriftCorrectionCooldownFrames;
        if (!vp->get_isPlaying()) vp->Play();
        synced.nextVideoClockPollFrame = frame + 1;
        VIVIFY_DEBUG(
            "Vivify sync: positioned video at songTime={} videoTime={} clockRunning={}",
            songTime, videoTime, BoolText(songClockRunning));
      }

      // Rebind only on output-visibility transitions. Decoder lifetime follows
      // the authored VideoPlayer object, not the renderer, matching desktop
      // semantics while still repairing Quest's MaterialOverride detach bug.
      bool const targetRenderable = IsVideoOutputRenderable(video);
      if (targetRenderable != video.wasRenderable) {
        if (targetRenderable) EnsureVideoOutputBinding(video);
        video.wasRenderable = targetRenderable;
      }

      // Healthy videos need only low-frequency native clock polling. A pending
      // seek/startup is sampled every frame until it has produced the requested
      // frame; no hidden fast-forward is used.
      if (video.hasProducedTexture && !video.seekPending && !pollVideoClock) continue;

      std::int64_t decodedFrame = -1;
      bool const hasOutputTexture = HasDecodedVideoOutput(vp, decodedFrame);
      if (hasOutputTexture) {
        if (!video.hasProducedTexture) EnsureVideoOutputBinding(video);
        video.hasProducedTexture = true;
        if (decodedFrame >= 0 && decodedFrame != video.lastDecodedFrame) {
          video.lastDecodedFrame = decodedFrame;
          video.lastDecodedFrameAdvanceFrame = frame;
        }
      }

      if (video.seekPending) {
        float const logicalTime = static_cast<float>(vp->get_time());
        float const decodedTime = DecodedVideoTime(vp, decodedFrame);
        bool const logicalSettled =
            std::isfinite(logicalTime) &&
            std::abs(logicalTime - video.seekTargetTime) <=
                kVideoSeekSettleToleranceSeconds;
        bool const decodedSettled =
            !std::isfinite(decodedTime) ||
            std::abs(decodedTime - video.seekTargetTime) <=
                kVideoSeekSettleToleranceSeconds;
        bool const newDecodedFrame =
            decodedFrame < 0 || video.seekSourceFrame < 0 ||
            decodedFrame != video.seekSourceFrame;

        // Normal path: exactly like desktop Vivify, Unity's seekCompleted event
        // is authoritative. Wait one rendered frame after the callback (desktop
        // uses WaitForEndOfFrame), then validate that Quest exposes the requested
        // decoded output before releasing the seek lock.
        bool const eventCompleted =
            video.seekCompletedEventBound && video.seekCompletedSignal;
        bool const eventFramePassed =
            eventCompleted && video.seekCompletedSignalFrame >= 0 &&
            frame > video.seekCompletedSignalFrame;

        // Compatibility fallback is only used when the delegate could not be
        // bound at all. It still requires exact clock/output validation and does
        // not issue extra seeks or change decoder speed.
        bool const unboundExactFallback =
            !video.seekCompletedEventBound && frame >= video.seekIssuedFrame + 2;
        bool const completionReady = eventFramePassed || unboundExactFallback;

        if (completionReady && hasOutputTexture && logicalSettled &&
            decodedSettled && newDecodedFrame) {
          video.seekPending = false;
          video.seekCompletedSignal = false;
          video.seekCompletedSignalFrame = -1;
          video.recoveryAttempts = 0;
          if (!songClockRunning && vp->get_isPlaying()) {
            // Practice/random starts can be reconstructed while Beat Saber's
            // clock is frozen. Hold the completed seek frame until audio moves.
            vp->Pause();
            video.waitingForClockStart = true;
          }
        } else if (frame - video.seekIssuedFrame >= kVideoSeekSettleTimeoutFrames) {
          // A platform/event failure must not deadlock a public build. If Unity
          // failed to raise seekCompleted but every independently observable
          // value is already exact, accept that state as a watchdog escape hatch.
          // This path never accelerates, drops frames or changes the target.
          bool const exactWatchdogState =
              video.seekCompletedEventBound && !video.seekCompletedSignal &&
              hasOutputTexture && logicalSettled && decodedSettled &&
              newDecodedFrame;
          if (exactWatchdogState) {
            PaperLogger.warn(
                "Vivify VideoPlayer.seekCompleted watchdog accepted an already exact decoder state (target={} logical={} decoded={})",
                video.seekTargetTime, logicalTime, decodedTime);
            video.seekPending = false;
            video.seekCompletedSignal = false;
            video.seekCompletedSignalFrame = -1;
            video.recoveryAttempts = 0;
            if (!songClockRunning && vp->get_isPlaying()) {
              vp->Pause();
              video.waitingForClockStart = true;
            }
          } else {
            if (video.recoveryAttempts >= kVideoMaxRecoveryAttempts) {
              video.failed = true;
              if (vp->get_isPlaying()) vp->Pause();
              PaperLogger.error(
                  "Vivify video seek failed safely after bounded retries; decoder quarantined (eventBound={} eventSeen={} target={} logical={} decoded={} songTime={})",
                  video.seekCompletedEventBound, video.seekCompletedSignal,
                  video.seekTargetTime, logicalTime, decodedTime, songTime);
              continue;
            }

            // Bounded same-rate retry only. This is a watchdog recovery for a
            // broken seek, not normal synchronization and never becomes a seek
            // loop: at most kVideoMaxRecoveryAttempts retries are possible.
            video.recoveryAttempts++;
            BeginVideoSeek(video, videoTime, frame, decodedFrame);
            if (!vp->get_isPlaying()) vp->Play();
            video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;
            video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
            VIVIFY_DEBUG(
                "Vivify sync: bounded seek watchdog retry {} target={} logical={} decoded={}",
                video.recoveryAttempts, videoTime, logicalTime, decodedTime);
          }
        }
        continue;
      }

      bool const shouldAdvance = ShouldVideoAdvance(vp, videoTime, playbackSpeed);
      bool const frameIndexAvailable = decodedFrame >= 0 && video.lastDecodedFrame >= 0;
      bool const decoderStalled =
          frameIndexAvailable && hasOutputTexture && video.hasProducedTexture &&
          shouldAdvance && vp->get_isPlaying() &&
          frame - video.lastDecodedFrameAdvanceFrame >= kVideoStallFrames;
      bool const missingDecodedFrame = !hasOutputTexture;

      if ((missingDecodedFrame || decoderStalled) &&
          frame >= video.outputGraceUntilFrame &&
          frame >= video.nextOutputRecoveryFrame) {
        if (video.recoveryAttempts >= kVideoMaxRecoveryAttempts) {
          video.failed = true;
          if (vp->get_isPlaying()) vp->Pause();
          PaperLogger.error(
              "Vivify video decoder failed health checks; disabled instead of entering a recovery loop (songTime={} videoTime={})",
              songTime, videoTime);
          continue;
        }
        video.recoveryAttempts++;
        EnsureVideoOutputBinding(video);
        BeginVideoSeek(video, videoTime, frame, decodedFrame);
        if (!vp->get_isPlaying()) vp->Play();
        video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;
        video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
        video.nextDriftCorrectionFrame = frame + kVideoDriftCorrectionCooldownFrames;
        VIVIFY_DEBUG(
            "Vivify sync: bounded {} recovery attempt {} at songTime={} videoTime={}",
            decoderStalled ? "stall" : "output", video.recoveryAttempts,
            songTime, videoTime);
        continue;
      }

      if (!pollVideoClock) continue;

      if (!vp->get_isPlaying()) {
        if (shouldAdvance && songClockRunning && frame >= video.nextStartRetryFrame) {
          // Resume the already-positioned decoder. Do not reseek unless the
          // desktop-equivalent drift check below says it is actually wrong.
          vp->Play();
          video.nextStartRetryFrame = frame + 30;
        }
        continue;
      }

      float const drift = static_cast<float>(vp->get_time()) - videoTime;
      if (std::abs(drift) > kVideoDriftToleranceSeconds &&
          frame >= video.nextDriftCorrectionFrame) {
        // This is the same 200 ms contract as PC Vivify's ResyncTime. The seek
        // runs at the authored playback rate and must settle before another can
        // be issued.
        BeginVideoSeek(video, videoTime, frame, decodedFrame);
        video.nextDriftCorrectionFrame = frame + kVideoDriftCorrectionCooldownFrames;
      }

      if (heartbeat) {
        PaperLogger.info(
            "Vivify sync heartbeat: videoTime={} target={} drift={} speed={} prepared={} playing={} texture={} authoredActive={} dormant={} seeking={}",
            static_cast<float>(vp->get_time()), videoTime, drift, playbackSpeed,
            vp->get_isPrepared(), vp->get_isPlaying(), hasOutputTexture,
            authoredActive, video.decoderDormant, video.seekPending);
      }
    }
  }
}

bool Runtime::IsReduceDebrisEnabled() {

  if (!_reduceDebrisCached) {
    _reduceDebrisCached = true;
    _reduceDebris = false;
    auto* playerDataModel = UnityEngine::Object::FindObjectOfType<GlobalNamespace::PlayerDataModel*>();
    if (IsManagedAlive(playerDataModel)) {
      auto* playerData = playerDataModel->get_playerData();
      if (playerData != nullptr) {
        auto* settings = playerData->get_playerSpecificSettings();
        if (settings != nullptr) {
          _reduceDebris = settings->get_reduceDebris();
        }
      }
    }
    VIVIFY_DEBUG("Vivify: Reduce Debris player option = {} (custom debris {})", _reduceDebris,
                 _reduceDebris ? "disabled" : "enabled");
  }
  return _reduceDebris;
}

bool Runtime::IsLeftHanded() {
  if (_leftHandedCached) return _leftHanded;

  _leftHandedCached = true;
  _leftHanded = false;
  auto* playerDataModel = UnityEngine::Object::FindObjectOfType<GlobalNamespace::PlayerDataModel*>();
  if (IsAlive(playerDataModel)) {
    auto* playerData = playerDataModel->get_playerData();
    if (playerData != nullptr) {
      auto* settings = playerData->get_playerSpecificSettings();
      if (settings != nullptr) _leftHanded = settings->get_leftHanded();
    }
  }
  VIVIFY_DEBUG("Vivify prefab mirroring: left-handed mode={}", BoolText(_leftHanded));
  return _leftHanded;
}

UnityEngine::Transform* Runtime::EnsureMirroredPrefabParent() {
  if (!IsLeftHanded()) return nullptr;
  if (!IsAlive(_mirroredPrefabParent)) {
    _mirroredPrefabParent = UnityEngine::GameObject::New_ctor(u"VivifyLeftHandPrefabParent");
    if (!IsAlive(_mirroredPrefabParent)) return nullptr;
    _mirroredPrefabParent->get_transform()->set_localScale(UnityEngine::Vector3(-1.0f, 1.0f, 1.0f));
  }
  return _mirroredPrefabParent->get_transform().unsafePtr();
}

void Runtime::SetPauseMenuActive(bool active) {
  _pauseMenuRequested = active;
  ApplyPauseState();
}

void Runtime::SetApplicationPaused(bool paused) {
  _applicationPaused = paused;
  ApplyPauseState();
}

void Runtime::SetApplicationFocused(bool focused) {
  _applicationFocused = focused;
  ApplyPauseState();
}

void Runtime::ApplyPauseState() {
  bool const active = _pauseMenuRequested || _applicationPaused || !_applicationFocused;
  if (_currentBeatmapData == nullptr) {
    _pauseMenuActive = false;
    return;
  }
  if (_pauseMenuActive == active) return;
  _pauseMenuActive = active;
  VIVIFY_DEBUG("Vivify suspension {}: menu={} applicationPaused={} applicationFocused={} syncedObjects={} secondaryCameras={}",
               active ? "entered" : "left", _pauseMenuRequested, _applicationPaused,
               _applicationFocused, _syncedObjects.size(), _secondaryCameras.size());
  if (active) {
    // Suspend Unity-driven prefab time immediately. Runtime::Update stops as
    // soon as the lifecycle is suspended, so deferring this to
    // UpdatePrefabAnimationSpeed lets Animator and ParticleSystem components
    // keep advancing behind the pause or Quest system menu.
    for (auto& synced : _syncedObjects) {
      for (auto* animator : synced.animators) {
        if (IsManagedAlive(animator)) animator->set_speed(0.0f);
      }
      for (auto* animation : synced.legacyAnimations) {
        SetLegacyAnimationSpeed(animation, 0.0f);
      }
      for (auto& particleSystem : synced.particleSystems) {
        SetParticleClockSuppressed(particleSystem, true);
      }
      for (auto& video : synced.videoPlayers) {
        auto* vp = video.player;
        if (IsManagedAlive(vp) && vp->get_isPlaying()) vp->Pause();
        video.needsStartupKick = true;
      }
    }
    _lastAppliedSyncSpeed = 0.0f;

    _lifecycle.Suspend();

    if (_cameraApplier != nullptr && UnityEngine::Object::op_Implicit_bool(_cameraApplier)) {
      _cameraApplier->set_enabled(false);
    }
    // A secondary camera can be disabled intentionally (for example when it
    // has no color/depth target). Remember that state exactly; blindly enabling
    // every camera on resume can render an un-targeted helper into the headset.
    RestoreSecondaryCullingLayers();
    RemoveMidRenderCommandBuffers();
    for (auto& [name, cam] : _secondaryCameras) {
      cam.enabledBeforePause = IsAlive(cam.camera) && cam.camera->get_enabled();
      if (IsAlive(cam.camera)) cam.camera->set_enabled(false);
    }

    RestoreGlobalProperties();

    // Keep authored render and QualitySettings values alive through the pause
    // menu. Restoring antiAliasing here and reapplying it immediately after an
    // Android XR resume can recreate the eye render targets while OpenXR is
    // reattaching its swapchain. The captured XR-resume freeze stopped on exactly
    // that resume path. Desktop Vivify also keeps these values until runtime
    // disposal, so teardown/restart remains the only place that restores them.
    VIVIFY_DEBUG("Vivify pause: preserving {} authored render setting(s) across XR suspend",
                 _currentRenderSettings.size());

    _pausedMaterialAnimations = std::move(_materialAnimations);
    _pausedGlobalAnimations = std::move(_globalAnimations);
    _pausedAnimatorAnimations = std::move(_animatorAnimations);
    _pausedRenderSettingAnimations = std::move(_renderSettingAnimations);
    _materialAnimations.clear();
    _globalAnimations.clear();
    _animatorAnimations.clear();
    _renderSettingAnimations.clear();
  } else {
    for (auto& [name, cam] : _secondaryCameras) {
      if (IsAlive(cam.camera)) cam.camera->set_enabled(cam.enabledBeforePause);
      cam.enabledBeforePause = false;
    }
    VIVIFY_DEBUG("Vivify resume checkpoint: secondary cameras restored");

    ReapplyCurrentGlobalProperties();
    VIVIFY_DEBUG("Vivify resume checkpoint: global shader state restored; authored render settings preserved");
    _materialAnimations = std::move(_pausedMaterialAnimations);
    _globalAnimations = std::move(_pausedGlobalAnimations);
    _animatorAnimations = std::move(_pausedAnimatorAnimations);
    _renderSettingAnimations = std::move(_pausedRenderSettingAnimations);
    _pausedMaterialAnimations.clear();
    _pausedGlobalAnimations.clear();
    _pausedAnimatorAnimations.clear();
    _pausedRenderSettingAnimations.clear();
    VIVIFY_DEBUG("Vivify resume checkpoint: authored animations restored");

    float resumeSpeed = 0.0f;
    if (IsManagedAlive(_audioTimeSyncController)) {
      float const authoredSpeed = _audioTimeSyncController->get_timeScale();
      if (std::isfinite(authoredSpeed) && authoredSpeed > 0.0f) resumeSpeed = authoredSpeed;
    }
    for (auto& synced : _syncedObjects) {
      for (auto* animator : synced.animators) {
        if (IsManagedAlive(animator)) animator->set_speed(resumeSpeed);
      }
      for (auto* animation : synced.legacyAnimations) {
        SetLegacyAnimationSpeed(animation, resumeSpeed);
      }
      for (auto& particleSystem : synced.particleSystems) {
        SetParticleClockSuppressed(particleSystem, resumeSpeed <= 0.0f);
      }
      for (auto& video : synced.videoPlayers) {
        video.needsStartupKick = true;
        video.nextStartRetryFrame = 0;
        video.wasRenderable = false;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.nextOutputRecoveryFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = 0;
        video.nextDriftCorrectionFrame = 0;
      }
      synced.nextVideoClockPollFrame = 0;
    }

    _lifecycle.Resume();
    // Force a fresh callback-clock sample and reapply the practice speed on
    // the first resumed frame. Otherwise a long Android sleep can leave
    // Animator/ParticleSystem components at the pause speed of zero.
    _songTimeCacheFrame = -1;
    _lastSyncSongTime = -1.0f;
    _syncClockStallFrames = 0;
    _syncClockHasAdvanced = false;
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    VIVIFY_DEBUG("Vivify resume checkpoint: lifecycle active; refreshing camera components");
    if (!_isResetting) RefreshCameraComponents(true);
    VIVIFY_DEBUG("Vivify resume complete: songTime={} syncedObjects={} secondaryCameras={} renderSettingsPreserved={}",
                 CurrentSongTime(), _syncedObjects.size(), _secondaryCameras.size(),
                 _currentRenderSettings.size());
  }
}

void Runtime::HandleScenesWillDismiss() {
  if (_currentBeatmapData == nullptr && _lifecycle.Phase() == RuntimePhase::Dormant &&
      _activeSabers.empty() && _cameraApplier == nullptr &&
      _secondaryCameras.empty() && _livePrefabs.empty()) {
    return;
  }
  VIVIFY_DEBUG("Vivify retiring gameplay session before scene dismissal");
  ResetRuntime(ResetMode::EarlySceneTransition);
}

void Runtime::HandleGameplayRestart() {
  if (_currentBeatmapData == nullptr || _isResetting) return;
  VIVIFY_DEBUG("Vivify retiring gameplay session before restart");
  ResetRuntime(ResetMode::LiveScene);
}

bool Runtime::IsCameraApplierCurrent(CameraApplier* applier) const {
  if (!IsAlive(applier) || applier != _cameraApplier ||
      !_lifecycle.CanRender(applier->sessionGeneration)) {
    return false;
  }
  auto gameObject = applier->get_gameObject();
  return IsAlive(gameObject.unsafePtr()) && gameObject.unsafePtr() == _cameraApplierGO;
}

bool Runtime::BeginCameraRender(CameraApplier* applier) {
  return IsCameraApplierCurrent(applier) &&
         _lifecycle.TryEnterRender(applier->sessionGeneration);
}

void Runtime::EndCameraRender(CameraApplier* applier) {
  (void)applier;
  _lifecycle.LeaveRender();
  FinishPendingReset();
}

bool Runtime::ShouldSuppressOriginalImageEffect(
    GlobalNamespace::ImageEffectController* controller) const {
  return IsAlive(controller) && IsCameraApplierCurrent(_cameraApplier) &&
         _cameraApplier->get_enabled() && _cameraApplier->hasMainEffect &&
         _cameraApplier->imageEffectController == controller;
}

void Runtime::OnCameraApplierDestroyed(CameraApplier* applier) {
  RemoveMidRenderCommandBuffers(applier);
  if (_cameraApplier != applier) return;
  _cameraApplier = nullptr;
  _cameraApplierGO = nullptr;
}

void Runtime::RefreshMultipassRendering() {
  auto mainCam = UnityEngine::Camera::get_main();
  auto mainCamGO = IsAlive(mainCam.unsafePtr()) ? mainCam->get_gameObject().unsafePtr() : nullptr;
  RefreshMultipassRendering(mainCamGO);
  RefreshLoadedMaterialStereoKeywords();
}

void Runtime::RefreshIsolationSettings() {
  if (GetDisableAllBlits()) {
    if ((!_preEffects.empty() || !_postEffects.empty() || HasMidRenderEffects()) && GetVivifyDebugLogging()) {
      PaperLogger.info("Vivify isolation: clearing active blits (Blit effects disabled) pre={} post={}",
                       _preEffects.size(), _postEffects.size());
    }
    _preEffects.clear();
    _postEffects.clear();
    for (auto& bucket : _midEffects) bucket.clear();
    DestroyCameraApplier();
    ReleaseMidRenderTextures();
    ReleaseCachedBlitTextures();
  } else if (GetDisableBeat0FilmgrainBlit()) {
    UpdateBlitEffects();
  }

  if (GetDisableCreateCameraDepth()) {
    if (!_secondaryCameras.empty() && GetVivifyDebugLogging()) {
      PaperLogger.info("Vivify isolation: releasing secondary cameras count={}", _secondaryCameras.size());
    }
    for (auto& [name, camera] : _secondaryCameras) {
      ReleaseSecondaryCameraData(camera);
    }
    _secondaryCameras.clear();
    for (auto it = _cameraProperties.begin(); it != _cameraProperties.end();) {
      if (it->first != kMainCameraId) {
        it = _cameraProperties.erase(it);
      } else {
        it++;
      }
    }
  } else {
    // Re-apply stored secondary-camera properties after an isolation setting
    // changes. The culling controller owns temporary layer restoration.
    for (auto& [name, camera] : _secondaryCameras) {
      if (!IsAlive(camera.camera)) continue;
      ApplySecondaryCameraProperties(camera);
      ApplyCameraGameObjectProperties(camera.camera, camera.properties);
    }
  }

  RefreshCameraComponents(_currentBeatmapData != nullptr && !_isResetting && !_pauseMenuActive);
}

void Runtime::ResetRuntime(ResetMode mode) {
  auto const resetRank = [](ResetMode candidate) {
    switch (candidate) {
      case ResetMode::GameplayPreparation: return 0;
      case ResetMode::LiveScene: return 1;
      case ResetMode::EarlySceneTransition: return 2;
      case ResetMode::LateSceneTransition: return 3;
    }
    return 3;
  };
  auto const resetName = [](ResetMode candidate) -> char const* {
    switch (candidate) {
      case ResetMode::GameplayPreparation: return "gameplay-preparation";
      case ResetMode::LiveScene: return "live-scene";
      case ResetMode::EarlySceneTransition: return "early-transition";
      case ResetMode::LateSceneTransition: return "late-transition";
    }
    return "unknown";
  };

  [[maybe_unused]] auto const retiredGeneration = _lifecycle.BeginRetirement();
  if (_lifecycle.RenderDepth() != 0) {
    // A scene transition may advance while an image-effect callback is still
    // unwinding. By the time the deferred reset executes, old scene wrappers
    // can already be native-dead. Escalate transition cleanup to the pointer-
    // free late mode rather than replaying scene-touching teardown later.
    ResetMode const deferredMode =
        (mode == ResetMode::EarlySceneTransition || mode == ResetMode::LateSceneTransition)
            ? ResetMode::LateSceneTransition
            : mode;
    if (!_pendingResetMode.has_value() ||
        resetRank(deferredMode) > resetRank(_pendingResetMode.value())) {
      _pendingResetMode = deferredMode;
    }
    _isResetting = true;
    VIVIFY_DEBUG("Vivify deferred {} reset as {} until {} active render scope(s) leave",
                 resetName(mode), resetName(deferredMode), _lifecycle.RenderDepth());
    return;
  }

  VIVIFY_DEBUG("Vivify ResetRuntime: mode={} livePrefabs={} preloaded={} synced={} secondaryCameras={} declaredTextures={} assets={}",
               resetName(mode), _livePrefabs.size(), _instantiatePrefabs.size(), _syncedObjects.size(),
               _secondaryCameras.size(), _declaredTextures.size(), _assets.size());
  _isResetting = true;
  bool const canTouchSceneObjects = mode != ResetMode::LateSceneTransition;
  bool const preserveGameplayScene =
      mode == ResetMode::GameplayPreparation || mode == ResetMode::LiveScene;
  bool const preserveBundleVideoWarmups =
      mode == ResetMode::GameplayPreparation;

  if (canTouchSceneObjects) {
    // This path is used while the gameplay scene is still alive (for example a
    // practice-mode backward seek), so authored state can be restored normally.
    DestroyCameraApplier();
    RestoreGlobalProperties();
    RestoreAllVisualReplacements();
    RestoreMainCameraOriginals();

    std::unordered_set<UnityEngine::GameObject*> destroyed;
    for (auto& [id, prefab] : _livePrefabs) {
      if (prefab.gameObject == nullptr) continue;
      for (auto const& track : prefab.tracks) track.UnregisterGameObject(prefab.gameObject);
      if (destroyed.emplace(prefab.gameObject).second && IsAlive(prefab.gameObject)) {
        UnityEngine::Object::Destroy(prefab.gameObject);
      }
    }
    for (auto& [eventData, instantiate] : _instantiatePrefabs) {
      if (instantiate.instance != nullptr && destroyed.emplace(instantiate.instance).second &&
          IsAlive(instantiate.instance)) {
        UnityEngine::Object::Destroy(instantiate.instance);
      }
      instantiate.instance = nullptr;
    }
    if (IsAlive(_mirroredPrefabParent)) {
      UnityEngine::Object::Destroy(_mirroredPrefabParent);
    }

    for (auto& [name, dt] : _declaredTextures) ReleaseDeclaredTextureData(dt);
    for (auto& [name, cam] : _secondaryCameras) ReleaseSecondaryCameraData(cam);
    RemoveMidRenderCommandBuffers();
    ReleaseMidRenderTextures();
    ReleaseCachedBlitTextures();
    RestoreRenderSettings();

    if (IsAlive(_multipassController)) {
      _multipassController->set_enabled(false);
      UnityEngine::Object::Destroy(_multipassController);
    }
  } else {
    // Scene transitions are deliberately pointer-free. Crash tombstones showed
    // stale wrappers reaching RenderTexture::Release, Object::Destroy,
    // Renderer.enabled, and Behaviour.enabled after leaving a song. Only static
    // shader bindings are cleared here; Unity owns destruction of the old scene.
    for (auto const& [name, data] : _declaredTextures) {
      UnityEngine::Shader::SetGlobalTexture(data.propertyId, static_cast<UnityEngine::Texture*>(nullptr));
    }
    for (auto const& [name, data] : _secondaryCameras) {
      if (data.texturePropertyId.has_value()) {
        UnityEngine::Shader::SetGlobalTexture(data.texturePropertyId.value(), static_cast<UnityEngine::Texture*>(nullptr));
      }
      if (data.depthTexturePropertyId.has_value()) {
        UnityEngine::Shader::SetGlobalTexture(data.depthTexturePropertyId.value(), static_cast<UnityEngine::Texture*>(nullptr));
      }
    }
    for (auto const& [propertyId, value] : _currentGlobalProperties) {
      if (std::holds_alternative<UnityEngine::Texture*>(value)) {
        UnityEngine::Shader::SetGlobalTexture(propertyId, static_cast<UnityEngine::Texture*>(nullptr));
      }
    }
    for (auto const& [keyword, enabled] : _savedGlobalKeywords) {
      if (enabled) UnityEngine::Shader::EnableKeyword(StringW(keyword));
      else UnityEngine::Shader::DisableKeyword(StringW(keyword));
    }

    // Do not Dispose/Destroy transition-owned native objects. Clear every raw
    // pointer so the persistent VivifyRuntime behaviour cannot touch them on a
    // later menu frame or when another song is selected.
    _cameraApplier = nullptr;
    _cameraApplierGO = nullptr;
    _multipassController = nullptr;
    _lastMainCameraGO = nullptr;
    _midCommandBufferCamera = nullptr;
    _midCommandBufferOwner = nullptr;
    _activeMidCommandBuffers.clear();
    _midSelfBlitTemps.clear();
    _midRenderCommandCache.Invalidate();
    _midMainRT = nullptr;
    _midScratchRT = nullptr;
    _mainBlitTexture = nullptr;
    _scratchBlitTexture = nullptr;
    ReleaseImageBlitCommandBuffer(false);
    SetMultipassShaderState(false);
    _beatmapCallbacksController = nullptr;
  }

  _livePrefabs.clear();
  _instantiatePrefabs.clear();
  _deferredPrefabPrewarms.clear();
  if (!preserveBundleVideoWarmups) ReleaseBundleVideoWarmups();
  // Persistent video decoder proxies live under VivifyRuntime (DontDestroyOnLoad),
  // not under the gameplay prefab. They must be explicitly retired on every
  // reset or they would survive into the next song with stale renderer targets.
  for (auto& synced : _syncedObjects) ReleaseSyncedVideos(synced, false);
  _syncedObjects.clear();
  _blitMaterialValidCache.clear();
  _warnedInvalidBlitPasses.clear();
  _loggedBlitStereoMaterials.clear();
  _materialAnimations.clear();
  _globalAnimations.clear();
  _animatorAnimations.clear();
  _renderSettingAnimations.clear();
  _pausedMaterialAnimations.clear();
  _pausedGlobalAnimations.clear();
  _pausedAnimatorAnimations.clear();
  _pausedRenderSettingAnimations.clear();
  _savedGlobalProperties.clear();
  _savedGlobalKeywords.clear();
  _currentGlobalProperties.clear();
  _currentGlobalKeywords.clear();
  _repairedMaterials.clear();
  _genericFallbackMaterials.clear();
  _assets.clear();
  _assetsByName.clear();
  _ambiguousAssetAliases.clear();
  _missingAssetKeys.clear();
  _missingInstantiatePrefabAssets.clear();
  _supportedShadersByName.clear();
  _catchUpAppliedCustomEvents.clear();
  _deferredStartupPostProcessingEvents.clear();
  _deferredSaberVisualsUntilFrame = -1;
  _saberVisualRetryUntilFrame = -1;
  _lastSaberIntegrityFrame = -1000;
  _warnedInvalidBeatmapData = false;
  _warnedStartupDescriptorWait = false;
  _postProcessingReadyFrame = -1;
  _nextBeatmapPrepareProbeFrame = 0;
  _nextSyncedObjectPurgeFrame = 0;
  _declaredTextures.clear();
  _secondaryCameras.clear();
  _preEffects.clear();
  _postEffects.clear();
  for (auto& bucket : _midEffects) bucket.clear();
  _midRenderCommandCache.Invalidate();
  _hasMainDescriptor = false;
  _cachedMainVrUsage = -1;
  _savedRenderSettings.clear();
  _currentRenderSettings.clear();
  _assignedPrefabs.clear();
  InvalidateAssignedPrefabLookup();
  _activeDebrisPrefabStack.clear();
  _lastCutDebrisPrefabs.clear();
  if (!preserveGameplayScene) {
    _activeSabers.clear();
    _activeNoteControllers.clear();
  } else {
    // PrepareBeatmap and practice/restart resets run while the same gameplay
    // scene (and SaberModelController objects) are still alive. Erasing this
    // list made AssignObjectPrefab at beat 0 a no-op until pausing/restarting
    // happened to reconstruct the saber hierarchy.
    PurgeInvalidActiveSabers();
    for (auto it = _activeNoteControllers.begin(); it != _activeNoteControllers.end();) {
      if (!IsAlive(*it)) {
        it = _activeNoteControllers.erase(it);
      } else {
        ++it;
      }
    }
  }
  _noteReplacements.clear();
  _saberReplacements.clear();
  _debrisReplacements.clear();
  _cameraProperties.clear();
  _mainCameraPropsDirty = false;
  _mainCamOriginalDepthMode.reset();
  _mainCamOriginalClearFlags.reset();
  _mainCamOriginalBackgroundColor.reset();
  _mirroredPrefabParent = nullptr;

  if (preserveGameplayScene && _mainBundle != nullptr && !UnityEngine::Object::op_Implicit_bool(_mainBundle)) {
    _mainBundle = nullptr;
    _preloadedBundlePath.clear();
  }
  if (!preserveGameplayScene) _beatmapCallbacksController = nullptr;
  _currentBeatmapData = nullptr;
  _beatmapAD = nullptr;
  _audioTimeSyncController = nullptr;
  _lastSongTime = -1.0f;
  _lastSyncSongTime = -1.0f;
  _syncClockStallFrames = 0;
  _syncClockHasAdvanced = false;
  _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
  _lastQuestPerformanceFrame = -1000;
  _midCommandBufferCacheHits = 0;
  _midCommandBufferRebuilds = 0;
  _imageBlitExecutions = 0;
  _imageCommandBufferCreates = 0;
  _noteRefreshEvents = 0;
  _noteRefreshCandidates = 0;
  _assignedPrefabLookupRebuilds = 0;
  _songTimeCacheFrame = -1;
  _songTimeCache = 0.0f;
  _pauseMenuRequested = false;
  _applicationPaused = false;
  _applicationFocused = true;
  _pauseMenuActive = false;
  _reduceDebrisCached = false;
  _reduceDebris = false;
  _leftHandedCached = false;
  _leftHanded = false;
  _preparingGeneration = 0;
  _pendingResetMode.reset();
  [[maybe_unused]] bool const retired = _lifecycle.CompleteRetirement();
  _isResetting = false;
}

void Runtime::FinishPendingReset() {
  if (_lifecycle.RenderDepth() != 0 || !_pendingResetMode.has_value()) return;
  auto const mode = _pendingResetMode.value();
  _pendingResetMode.reset();
  _isResetting = false;
  ResetRuntime(mode);
}

}
