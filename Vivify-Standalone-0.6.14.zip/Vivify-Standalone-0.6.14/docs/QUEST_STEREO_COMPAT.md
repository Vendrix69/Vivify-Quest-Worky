# Quest geometry stereo compatibility

Vivify does **not** use a global per-eye Blit toggle as a geometry-shader fix.
Fullscreen Blit effects and mesh/geometry shaders are different rendering paths.

For geometry shaders, the right eye depends on the shader's compiled stereo
variant and on the geometry stage preserving the eye / render-target-array layer.
The supplied `TriangleExplosion` reference demonstrates the fully authored
Multiview solution: stereo data is carried through the vertex and geometry
structures and the geometry stage emits eye 0 and eye 1 with the correct
`SV_RenderTargetArrayIndex`.

At runtime Vivify therefore uses targeted shader recipes rather than globally
forcing every material. The known Aether shader
`Mawntee/Beat Saber Wireframe 3D-Noise` selects its stereo-instancing variant on
Quest, because its geometry source already transfers Unity stereo data but its
Multiview variant does not explicitly emit the array layer. Other recognized
geometry shaders keep their authored/native XR keywords untouched so patched
TriangleExplosion-style shaders are not broken by Vivify.

Vivify cannot synthesize a missing Android geometry-shader variant from arbitrary
compiled AssetBundle bytecode. If a shader has no stereo-capable Quest variant at
all, it still needs a source/bundle shader patch.


## Legacy fullscreen sampler2D compatibility

Quest still renders the headset through Multiview texture arrays. Older Vivify fullscreen shaders may nevertheless have been authored with `sampler2D` inputs. Vivify now detects a legacy non-stereo blit chain and presents that chain with a real 2D view of each eye: array slice -> Tex2D staging -> authored blits/globals -> array slice. This is intentionally separate from geometry-shader handling.

## Flux Vilar geometry shaders

The Android 42-flux bundle contains both Multiview and stereo-instancing variants for `Vilar/GeometryDissolve` and `Vilar/GeometryDissolveOutline`. Their Multiview geometry path loses the right-eye layer, so Vivify applies the same narrow runtime recipe used by the known Wireframe 3D-Noise compatibility case: Multiview keyword off, stereo-instancing variant on.
