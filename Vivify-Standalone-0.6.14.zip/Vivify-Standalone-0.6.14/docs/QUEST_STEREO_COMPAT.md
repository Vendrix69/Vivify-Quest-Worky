# Quest stereo compatibility

Vivify exposes **Force per-eye blits (experimental)** in its mod settings.
The toggle executes compatible fullscreen material blits once for eye 0 and once
for eye 1 into the two slices of Quest's stereo texture array while setting
`_StereoActiveEye` for each draw. It is intentionally off by default because
native Multiview shaders should remain on Unity's normal single-pass path.

This runtime mode cannot synthesize missing shader bytecode. In particular, a
custom geometry stage must itself preserve stereo routing. The supplied
TriangleExplosion reference demonstrates the required source-level pattern for
Quest Multiview: compile instancing/stereo variants, carry stereo state across
vertex/geometry structures, and for a geometry shader explicitly emit primitives
for both eyes with the appropriate stereo view/projection and render-target array
layer (`SV_RenderTargetArrayIndex`).

So the compatibility toggle targets legacy fullscreen/blit effects. Geometry
shaders that were built without a Quest-capable stereo variant still need to be
rebuilt or patched at shader source / compiled shader level.
