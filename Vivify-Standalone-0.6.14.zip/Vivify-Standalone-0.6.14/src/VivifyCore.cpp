#include "VivifyRuntimeInternal.hpp"
#include "VivifyComponents.hpp"
#include "UnityEngine/ParticleSystem.hpp"
#include "GlobalNamespace/PlayerDataModel.hpp"
#include "GlobalNamespace/PlayerData.hpp"
#include "GlobalNamespace/PlayerSpecificSettings.hpp"
#include "UnityEngine/SceneManagement/Scene.hpp"
#include "UnityEngine/SceneManagement/SceneManager.hpp"

namespace Vivify {

namespace {
constexpr int kVideoPrepareWatchdogFrames = 900;
constexpr int kVideoFirstFrameGraceFrames = 120;
constexpr int kVideoRecoveryBackoffFrames = 180;
constexpr int kVideoStallFrames = 300;
constexpr int kVideoDriftCorrectionCooldownFrames = 60;
constexpr float kVideoDriftToleranceSeconds = 0.5f;
constexpr float kVideoAggressiveRecoveryMaxRate = 3.0f;
constexpr float kHistoricalAnimatorStepSeconds = 0.05f;
constexpr int kHistoricalAnimatorMaxSteps = 4096;
constexpr int kHistoricalPrepareStaggerFrames = 12;

bool IsMainMenuSceneActive() {
  auto scene = UnityEngine::SceneManagement::SceneManager::GetActiveScene();
  return scene.get_name() == "MainMenu";
}

UnityEngine::AnimationState* DefaultLegacyAnimationState(
    UnityEngine::Animation* animation) {
  if (!IsManagedAlive(animation)) return nullptr;
  auto clip = animation->get_clip();
  auto* clipPtr = clip.unsafePtr();
  if (!IsManagedAlive(clipPtr)) return nullptr;
  return animation->get_Item(clipPtr->get_name());
}

void SetLegacyAnimationSpeed(UnityEngine::Animation* animation, float speed) {
  auto* state = DefaultLegacyAnimationState(animation);
  if (state != nullptr && UnityEngine::TrackedReference::op_Implicit_bool(state)) {
    state->set_speed(speed);
  }
}

bool HasDecodedVideoOutput(UnityEngine::Video::VideoPlayer* player,
                           std::int64_t& decodedFrame) {
  decodedFrame = -1;
  if (!IsManagedAlive(player) || !player->get_isPrepared()) return false;

  auto texture = player->get_texture();
  if (!IsManagedAlive(texture.unsafePtr())) return false;

  // Quest's Android VideoPlayer can keep reporting frame == -1 while its
  // external texture is already valid and visibly advancing. Treat dimensions
  // plus a live texture as healthy output; frame is an optional stall signal.
  decodedFrame = player->get_frame();
  return player->get_width() > 0 && player->get_height() > 0;
}

bool ShouldVideoAdvance(UnityEngine::Video::VideoPlayer* player,
                        float videoTime, float playbackSpeed) {
  if (!IsManagedAlive(player) || playbackSpeed <= 0.001f) return false;
  if (player->get_isLooping()) return true;

  double const length = player->get_length();
  return !std::isfinite(length) || length <= 0.0 ||
         static_cast<double>(videoTime) + 0.1 < length;
}

bool IsAuthoredVideoGameObjectActive(SyncedVideoPlayer const& video) {
  if (!IsManagedAlive(video.authoredPlayer)) return false;
  auto go = video.authoredPlayer->get_gameObject();
  auto* goPtr = go.unsafePtr();
  return IsManagedAlive(goPtr) && goPtr->get_activeInHierarchy();
}

// Desktop Vivify enables the prefab root and then uses the default
// GetComponentsInChildren<VideoPlayer>(), which only visits active GameObjects.
// Prewarming on Quest deliberately keeps the root inactive, so reproduce the
// hierarchy test without depending on the root's temporary prewarm state. A
// player is song-synchronized only when every child GameObject between it and
// the prefab root is activeSelf. Components under an initially-inactive child
// are intentionally left on a local enable/play timeline.
bool WouldVideoBeSongSynchronized(UnityEngine::GameObject* root,
                                  UnityEngine::Video::VideoPlayer* player) {
  if (!IsManagedAlive(root) || !IsManagedAlive(player)) return false;
  auto rootTransform = root->get_transform();
  auto playerObject = player->get_gameObject();
  auto* rootTransformPtr = rootTransform.unsafePtr();
  auto* playerObjectPtr = playerObject.unsafePtr();
  if (!IsManagedAlive(rootTransformPtr) || !IsManagedAlive(playerObjectPtr)) return false;

  auto playerTransform = playerObjectPtr->get_transform();
  auto* current = playerTransform.unsafePtr();
  while (IsManagedAlive(current) && current != rootTransformPtr) {
    auto currentObject = current->get_gameObject();
    auto* currentObjectPtr = currentObject.unsafePtr();
    if (!IsManagedAlive(currentObjectPtr) || !currentObjectPtr->get_activeSelf()) return false;
    current = current->get_parent().unsafePtr();
  }
  return current == rootTransformPtr;
}

void AdvanceAnimatorChronologically(UnityEngine::Animator* animator, float elapsed) {
  if (!IsManagedAlive(animator) || elapsed <= 0.0f) return;
  int const steps = std::max(1, std::min(
      kHistoricalAnimatorMaxSteps,
      static_cast<int>(std::ceil(elapsed / kHistoricalAnimatorStepSeconds))));
  float const step = elapsed / static_cast<float>(steps);
  for (int i = 0; i < steps; i++) animator->Update(step);
}

float NormalizeVideoTime(UnityEngine::Video::VideoPlayer* player,
                         float elapsed) {
  if (!IsManagedAlive(player) || !player->get_isPrepared() ||
      !player->get_isLooping()) {
    return elapsed;
  }

  double const length = player->get_length();
  if (!std::isfinite(length) || length <= 0.0) return elapsed;
  return static_cast<float>(std::fmod(static_cast<double>(elapsed), length));
}

bool EnsureVideoOutputBinding(SyncedVideoPlayer& video) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return false;

  auto const renderMode = player->get_renderMode();
  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    auto* target = video.renderTextureTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetTexture();
      target = targetReference.unsafePtr();
      video.renderTextureTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    if (!target->IsCreated()) target->Create();
    player->set_targetTexture(target);
    return target->IsCreated();
  }

  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    auto* target = video.materialTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetMaterialRenderer();
      target = targetReference.unsafePtr();
      if (!IsManagedAlive(target)) {
        target = video.authoredPlayer->GetComponent<UnityEngine::Renderer*>();
        if (!IsManagedAlive(target)) {
          target = video.authoredPlayer->GetComponentInChildren<UnityEngine::Renderer*>(true);
        }
      }
      video.materialTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    player->set_targetMaterialRenderer(target);
    if (ToStdString(player->get_targetMaterialProperty()).empty()) {
      player->set_targetMaterialProperty(StringW("_MainTex"));
    }
    return true;
  }

  return true;
}

// Reassigning the same target can be a no-op in Unity's Android VideoPlayer
// backend after a renderer/GameObject was disabled. Detach once, then attach the
// authored target again. This changes only the output surface binding; it does
// not pause, seek, or restart MediaCodec.
bool ForceVideoOutputRebind(SyncedVideoPlayer& video) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return false;

  auto const renderMode = player->get_renderMode();
  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    auto* target = video.renderTextureTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetTexture();
      target = targetReference.unsafePtr();
      video.renderTextureTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    if (!target->IsCreated()) target->Create();
    player->set_targetTexture(static_cast<UnityEngine::RenderTexture*>(nullptr));
    player->set_targetTexture(target);
    return target->IsCreated();
  }

  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    auto* target = video.materialTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetMaterialRenderer();
      target = targetReference.unsafePtr();
      if (!IsManagedAlive(target)) {
        target = video.authoredPlayer->GetComponent<UnityEngine::Renderer*>();
        if (!IsManagedAlive(target)) {
          target = video.authoredPlayer->GetComponentInChildren<UnityEngine::Renderer*>(true);
        }
      }
      video.materialTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    auto property = player->get_targetMaterialProperty();
    if (ToStdString(property).empty()) property = StringW("_MainTex");
    player->set_targetMaterialRenderer(static_cast<UnityEngine::Renderer*>(nullptr));
    player->set_targetMaterialRenderer(target);
    player->set_targetMaterialProperty(property);
    return true;
  }

  return true;
}

// A prepared decoder that is already at the requested clock position should
// resume directly. In particular, a prewarmed frame-0 decoder must not perform
// a second asynchronous seek at normal song start; that extra seek was the new
// visible startup delay in the previous build.
bool ResumeVideoWithoutSeekIfNearTarget(SyncedVideoPlayer& video,
                                        double requestedTime,
                                        int frame) {
  auto* player = video.player;
  if (!IsManagedAlive(player) || !player->get_isPrepared() || video.seekPhase != VideoSeekPhase::Idle) return false;
  double const target = std::max(0.0, requestedTime);
  double const current = player->get_time();
  if (!std::isfinite(current) || std::abs(current - target) > 0.20) return false;

  EnsureVideoOutputBinding(video);
  player->Play();
  video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;
  video.nextStartRetryFrame = frame + 30;
  return true;
}

bool IsVideoOutputRenderable(SyncedVideoPlayer& video) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return false;
  auto const renderMode = player->get_renderMode();
  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    return EnsureVideoOutputBinding(video);
  }
  if (renderMode.value__ !=
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    return true;
  }
  if (!EnsureVideoOutputBinding(video) || !IsManagedAlive(video.materialTarget)) {
    return false;
  }
  auto targetObject = video.materialTarget->get_gameObject();
  auto* targetObjectPtr = targetObject.unsafePtr();
  return video.materialTarget->get_enabled() && IsManagedAlive(targetObjectPtr) &&
         targetObjectPtr->get_activeInHierarchy();
}


bool VideoSeekBusy(SyncedVideoPlayer const& video) {
  return video.seekPhase != VideoSeekPhase::Idle;
}

bool BeginVideoSeek(SyncedVideoPlayer& video, double requestedTime,
                    bool playAfterFrame, int frame) {
  auto* player = video.player;
  if (!IsManagedAlive(player) || !player->get_isPrepared()) return false;

  double const target = std::max(0.0, requestedTime);
  EnsureVideoOutputBinding(video);
  if (player->get_isPlaying()) player->Pause();

  // frameReady is normally disabled because a callback every decoded frame is
  // unnecessary overhead. Enable it only for the seek handshake.
  player->set_sendFrameReadyEvents(true);
  video.queuedSeek = false;
  video.seekPhase = VideoSeekPhase::Seeking;
  video.seekCompletedReceived = false;
  video.frameReadyReceived = false;
  video.activeSeekTime = target;
  video.activeSeekPlayAfterFrame = playAfterFrame;
  video.seekStartedFrame = frame;
  video.seekFallbackLogged = false;
  video.hasProducedTexture = false;
  video.lastDecodedFrame = -1;
  video.lastDecodedFrameAdvanceFrame = frame;
  video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;

  // IMPORTANT: this is the single VideoPlayer::set_time call site for synced
  // playback. Unity queues each assignment as a separate asynchronous seek.
  player->set_time(target);
  // Unity documents Play immediately after assigning time. Keep the seek marked
  // busy until frameReady so no second set_time can queue, but do not make
  // playback itself wait for frameReady: that added visible Android latency.
  if (playAfterFrame) player->Play();
  return true;
}

void RequestVideoSeek(SyncedVideoPlayer& video, double requestedTime,
                      bool playAfterFrame, int frame) {
  double const target = std::max(0.0, requestedTime);
  if (VideoSeekBusy(video)) {
    // Repeated requests for the active target are not useful and must not turn
    // into a second seek after the current one finishes.
    if (std::abs(target - video.activeSeekTime) <= 0.01) {
      // Same outstanding seek, only the desired post-seek play state changed.
      // Update that state in place instead of scheduling an identical second seek.
      video.activeSeekPlayAfterFrame = playAfterFrame;
      video.queuedSeek = false;
      return;
    }
    video.queuedSeek = true;
    video.queuedSeekTime = target;
    video.queuedSeekPlayAfterFrame = playAfterFrame;
    return;
  }

  if (!BeginVideoSeek(video, target, playAfterFrame, frame)) {
    // Prepare is still in flight. Keep only the newest desired target; Update
    // will issue it after the player is prepared.
    video.queuedSeek = true;
    video.queuedSeekTime = target;
    video.queuedSeekPlayAfterFrame = playAfterFrame;
  }
}

void SuppressVideoSeekPlayback(SyncedVideoPlayer& video) {
  video.activeSeekPlayAfterFrame = false;
  if (video.queuedSeek) video.queuedSeekPlayAfterFrame = false;
}

void AdvanceVideoSeekLifecycle(SyncedVideoPlayer& video, int frame) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return;

  // The callbacks are authoritative. As a platform-safety fallback, infer the
  // handshake only when Unity's public time has settled on the requested frame
  // and a real output texture exists; Unity documents that time settles only
  // once the seek frame is displayable.
  if (VideoSeekBusy(video) && frame - video.seekStartedFrame >= 120) {
    std::int64_t decodedFrame = -1;
    bool const hasFrame = HasDecodedVideoOutput(player, decodedFrame);
    double const settledTime = player->get_time();
    bool const targetSettled = std::isfinite(settledTime) &&
                               std::abs(settledTime - video.activeSeekTime) <= 0.10;
    if (hasFrame && targetSettled) {
      video.seekCompletedReceived = true;
      video.frameReadyReceived = true;
      if (decodedFrame >= 0) {
        video.lastDecodedFrame = decodedFrame;
        video.lastDecodedFrameAdvanceFrame = frame;
      }
      if (!video.seekFallbackLogged) {
        video.seekFallbackLogged = true;
        VIVIFY_DEBUG("Vivify sync: inferred completed video seek from settled frame at {}s",
                     settledTime);
      }
    }
  }

  if (video.seekPhase == VideoSeekPhase::Seeking &&
      video.seekCompletedReceived) {
    video.seekPhase = VideoSeekPhase::WaitingForFrame;
  }

  if (video.seekPhase != VideoSeekPhase::WaitingForFrame ||
      !video.frameReadyReceived) {
    // A queued request can exist before Prepare completed, with no active seek.
    if (!VideoSeekBusy(video) && video.queuedSeek && player->get_isPrepared()) {
      double const target = video.queuedSeekTime;
      bool const playAfter = video.queuedSeekPlayAfterFrame;
      video.queuedSeek = false;
      BeginVideoSeek(video, target, playAfter, frame);
    }
    return;
  }

  EnsureVideoOutputBinding(video);
  video.hasProducedTexture = true;
  video.seekPhase = VideoSeekPhase::Idle;
  video.seekCompletedReceived = false;
  video.frameReadyReceived = false;
  player->set_sendFrameReadyEvents(video.frameReadyEventsBaseline);

  // If the song clock moved while this asynchronous seek was pending, service
  // exactly one coalesced follow-up seek before letting MediaCodec free-run.
  if (video.queuedSeek) {
    double const target = video.queuedSeekTime;
    bool const playAfter = video.queuedSeekPlayAfterFrame;
    video.queuedSeek = false;
    BeginVideoSeek(video, target, playAfter, frame);
    return;
  }

  if (video.activeSeekPlayAfterFrame) {
    player->Play();
  } else if (player->get_isPlaying()) {
    player->Pause();
  }
}

void ReleaseSyncedVideoPlayer(SyncedVideoPlayer& video, bool restoreAuthoredPlayer) {
  if (IsManagedAlive(video.player)) {
    // Stop Vivify-owned proxy callbacks before teardown, but restore an authored
    // player's pre-existing frameReady setting when no proxy was created.
    video.player->set_sendFrameReadyEvents(
        video.persistentDecoder ? false : video.frameReadyEventsBaseline);
  }
  if (restoreAuthoredPlayer && IsManagedAlive(video.authoredPlayer)) {
    video.authoredPlayer->set_enabled(video.authoredPlayerWasEnabled);
  }
  if (IsManagedAlive(video.decoderObject)) {
    UnityEngine::Object::Destroy(video.decoderObject);
  }
  video.player = nullptr;
  video.authoredPlayer = nullptr;
  video.decoderObject = nullptr;
  video.materialTarget = nullptr;
  video.renderTextureTarget = nullptr;
}

void ReleaseSyncedVideos(SyncedObject& synced, bool restoreAuthoredPlayer) {
  for (auto& video : synced.videoPlayers) {
    ReleaseSyncedVideoPlayer(video, restoreAuthoredPlayer);
  }
  synced.videoPlayers.clear();
}

void SetParticleClockSuppressed(SyncedParticleSystem& syncedParticle,
                                bool suppress) {
  auto* particleSystem = syncedParticle.particleSystem;
  if (!IsManagedAlive(particleSystem)) return;

  auto main = particleSystem->get_main();
  if (suppress) {
    if (!syncedParticle.clockSuppressed) {
      // Capture at the transition to a stopped song clock. Animator clips are
      // allowed to key this property every frame, so the current value—not the
      // prefab's original serialized value—is the one that must be restored.
      float const authoredSpeed = main.get_simulationSpeed();
      if (std::isfinite(authoredSpeed)) {
        syncedParticle.authoredSimulationSpeed = authoredSpeed;
      }
      syncedParticle.clockSuppressed = true;
    }
    main.set_simulationSpeed(0.0f);
    return;
  }

  if (syncedParticle.clockSuppressed) {
    main.set_simulationSpeed(syncedParticle.authoredSimulationSpeed);
    syncedParticle.clockSuppressed = false;
  }
}

bool RecoverHistoricalVideoStartsForReuse(UnityEngine::GameObject* root,
                                          SyncedObject& synced,
                                          float eventStartSongTime,
                                          float currentSongTime) {
  if (!IsManagedAlive(root) || synced.videoPlayers.empty()) return false;
  float const initialElapsed = std::max(0.0f, currentSongTime - eventStartSongTime);
  if (initialElapsed <= 0.05f) return false;

  UnityEngine::GameObject* probeRoot = nullptr;
  try {
    probeRoot = UnityEngine::Object::Instantiate(root);
  } catch (...) {
    probeRoot = nullptr;
  }
  if (!IsManagedAlive(probeRoot)) return false;

  auto probeRenderers = probeRoot->GetComponentsInChildren<UnityEngine::Renderer*>(true);
  for (int i = 0; i < probeRenderers.size(); i++) {
    if (IsManagedAlive(probeRenderers[i])) probeRenderers[i]->set_enabled(false);
  }
  auto probePlayers = probeRoot->GetComponentsInChildren<UnityEngine::Video::VideoPlayer*>(true);
  for (int i = 0; i < probePlayers.size(); i++) {
    auto* player = probePlayers[i];
    if (!IsManagedAlive(player)) continue;
    if (player->get_isPlaying()) player->Pause();
    player->set_playOnAwake(false);
    player->set_enabled(false);
  }
  auto probeAnimators = probeRoot->GetComponentsInChildren<UnityEngine::Animator*>(true);
  for (int i = 0; i < probeAnimators.size(); i++) {
    if (!IsManagedAlive(probeAnimators[i])) continue;
    probeAnimators[i]->set_cullingMode(UnityEngine::AnimatorCullingMode::AlwaysAnimate);
    // One reset at true timeline zero. From here on the probe only walks forward;
    // never Rebind/jump/Rebind, because that skips Animator transitions and gave
    // Teto a state that cannot occur during normal playback.
    probeAnimators[i]->Rebind();
    probeAnimators[i]->Update(0.0f);
  }

  auto probeActive = [&](std::size_t videoIndex) {
    if (videoIndex >= synced.videoPlayers.size()) return false;
    int const componentIndex = synced.videoPlayers[videoIndex].authoredComponentIndex;
    if (componentIndex < 0 || componentIndex >= probePlayers.size()) return false;
    auto* player = probePlayers[componentIndex];
    if (!IsManagedAlive(player)) return false;
    auto go = player->get_gameObject();
    auto* goPtr = go.unsafePtr();
    return IsManagedAlive(goPtr) && goPtr->get_activeInHierarchy();
  };

  // Only locally-timed players need activation-history reconstruction. Desktop
  // Vivify gives active-at-instantiation players one absolute prefab clock; a
  // later hide/show does not change their SongTime origin. Initially-inactive
  // child players are not attached to that synchronizer, so practice starts
  // must recover the most recent local enable edge for those players.
  std::vector<float> latestActiveOffsets(synced.videoPlayers.size(), -1.0f);
  std::vector<bool> previousActive(synced.videoPlayers.size(), false);
  std::vector<bool> targetActive(synced.videoPlayers.size(), false);
  for (std::size_t i = 0; i < synced.videoPlayers.size(); i++) {
    previousActive[i] = probeActive(i);
    if (previousActive[i]) latestActiveOffsets[i] = 0.0f;
  }

  int const steps = std::max(1, std::min(
      kHistoricalAnimatorMaxSteps,
      static_cast<int>(std::ceil(initialElapsed / kHistoricalAnimatorStepSeconds))));
  float const step = initialElapsed / static_cast<float>(steps);
  float elapsed = 0.0f;
  for (int sample = 0; sample < steps; sample++) {
    for (int i = 0; i < probeAnimators.size(); i++) {
      if (IsManagedAlive(probeAnimators[i])) probeAnimators[i]->Update(step);
    }
    elapsed = std::min(initialElapsed, elapsed + step);
    for (std::size_t i = 0; i < synced.videoPlayers.size(); i++) {
      bool const active = probeActive(i);
      if (active && !previousActive[i]) latestActiveOffsets[i] = elapsed;
      previousActive[i] = active;
    }
  }
  for (std::size_t i = 0; i < synced.videoPlayers.size(); i++) {
    targetActive[i] = probeActive(i);
  }
  UnityEngine::Object::Destroy(probeRoot);

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  int hiddenHistoricalRank = 0;
  bool recoveredAny = false;
  for (std::size_t i = 0; i < synced.videoPlayers.size(); i++) {
    auto& video = synced.videoPlayers[i];
    float const offset = latestActiveOffsets[i];
    bool const activeAtTarget = static_cast<bool>(targetActive[i]);
    video.authoredActiveStateKnown = true;
    video.authoredWasActive = activeAtTarget;
    video.requestedPrewarmFrame = false;
    video.hasProducedTexture = false;
    video.lastDecodedFrame = -1;
    video.nextStartRetryFrame = frame;

    if (video.songSynchronized) {
      // PC Vivify's VideoPlayerSyncController uses
      // songTime - InstantiatePrefabEventTime for the whole prefab lifetime.
      // Keep the Quest proxy on that absolute timeline even when the authored
      // screen is temporarily hidden; this lets a reveal bind an already-current
      // decoder instead of starting a late seek at the reveal frame.
      video.playbackStartKnown = true;
      video.playbackStartSongTime = eventStartSongTime;
      video.playbackTimelineStarted = currentSongTime + 0.001f >= eventStartSongTime;
      video.needsStartupKick = video.playbackTimelineStarted;
      if (video.playbackTimelineStarted) recoveredAny = true;
      if (IsManagedAlive(video.player) && video.player->get_isPrepared()) {
        video.prepareNotBeforeFrame = frame;
      } else if (activeAtTarget) {
        video.prepareNotBeforeFrame = frame;
      } else {
        video.prepareNotBeforeFrame =
            frame + kHistoricalPrepareStaggerFrames * (++hiddenHistoricalRank);
      }
      VIVIFY_DEBUG(
          "Vivify sync: recovered song-synchronized video timeline eventStart={} targetSongTime={} active={}",
          eventStartSongTime, currentSongTime, activeAtTarget);
    } else if (activeAtTarget && offset >= 0.0f &&
               offset <= initialElapsed + 0.001f) {
      // This player lived below an inactive child when the prefab spawned, so
      // desktop Vivify never attached its song synchronizer. Recover the local
      // playOnAwake epoch that is active at the practice target instead.
      recoveredAny = true;
      video.playbackStartKnown = true;
      video.playbackStartSongTime = eventStartSongTime + offset;
      video.playbackTimelineStarted = true;
      video.needsStartupKick = true;
      video.prepareNotBeforeFrame = frame;
      VIVIFY_DEBUG(
          "Vivify sync: recovered local video enable offset={} eventStart={} videoStart={}",
          offset, eventStartSongTime, video.playbackStartSongTime);
    } else {
      // An initially-inactive/local player is hidden at the practice target.
      // Keep MediaCodec warm at the beginning and let its next authored enable
      // edge start the local t=0 clock.
      video.playbackStartKnown = false;
      video.playbackTimelineStarted = false;
      video.needsStartupKick = false;
      if (IsManagedAlive(video.player) && video.player->get_isPlaying()) video.player->Pause();
      SuppressVideoSeekPlayback(video);
      if (!IsManagedAlive(video.player) || video.player->get_isPrepared()) {
        video.prepareNotBeforeFrame = frame;
      } else {
        video.prepareNotBeforeFrame =
            frame + kHistoricalPrepareStaggerFrames * (++hiddenHistoricalRank);
      }
    }
    video.preparePending = false;
    video.nextPrepareRetryFrame = video.prepareNotBeforeFrame;
  }
  return recoveredAny;
}

}

Runtime& Runtime::Instance() {
  static Runtime runtime;
  return runtime;
}

bool Runtime::IsAlive(UnityEngine::Object* object) const {
  return IsManagedAlive(object);
}

void Runtime::LateLoad() {
  auto cjdModInfo = CustomJSONData::modInfo.to_c();
  auto tracksModInfo = CModInfo{.id = "Tracks"};
  modloader_require_mod(&cjdModInfo, CMatchType::MatchType_IdOnly);
  modloader_require_mod(&tracksModInfo, CMatchType::MatchType_IdOnly);
  EnsureBehaviour();
  if (!SongCore::API::Capabilities::IsCapabilityRegistered(kCapability)) {
    SongCore::API::Capabilities::RegisterCapability(kCapability);
  }
  CustomJSONData::CustomEventCallbacks::AddCustomEventCallback(&Runtime::OnCustomEventStatic);
  SongCore::API::LevelSelect::GetLevelWasSelectedEvent() += [](SongCore::API::LevelSelect::LevelWasSelectedEventArgs const& event) {
    Runtime::Instance().HandleLevelSelected(event);
  };
}

void Runtime::EnsureBehaviour() {
  if (_behaviour != nullptr) {
    return;
  }
  auto* gameObject = UnityEngine::GameObject::New_ctor(u"VivifyRuntime");
  UnityEngine::Object::DontDestroyOnLoad(gameObject);
  _behaviour = gameObject->AddComponent<RuntimeBehaviour*>();
  RefreshCameraComponents(false);
}

void Runtime::OnBehaviourDestroyed(RuntimeBehaviour* behaviour) {
  if (_behaviour == behaviour) _behaviour = nullptr;
}

void Runtime::OnCustomEventStatic(GlobalNamespace::BeatmapCallbacksController* callbackController,
                                  CustomJSONData::CustomEventData* customEventData) {
  Runtime::Instance().HandleCustomEvent(callbackController, customEventData);
}

void Runtime::Update() {
  try {
    if (_isResetting) return;

    // Beatmap callbacks can outlive the gameplay scene by several frames.
    // Leaving authored materials and CameraApplier active during that window
    // attached them to MenuMainCamera and eventually passed a destroyed
    // Material into CommandBuffer.Blit.  The transition reset is deliberately
    // pointer-free, so it is safe even after Unity has begun scene teardown.
    if (_currentBeatmapData != nullptr && IsMainMenuSceneActive()) {
      PaperLogger.info("Vivify detected MainMenu with live beatmap state; applying transition-safe reset");
      ResetRuntime(ResetMode::LateSceneTransition);
      return;
    }

    if (_currentBeatmapData == nullptr) {
      // Bundle video decoding begins in the menu. Keep its readiness gate
      // moving even though no gameplay beatmap is active yet.
      UpdateBundleVideoWarmups();
      // A seek can intentionally tear down live state. Rebuild from the active
      // gameplay callback, but do not probe every menu frame while Unity is
      // still constructing or destroying that callback.
      TryPrepareSelectedBeatmapFromScene();
      if (_currentBeatmapData == nullptr) return;
    }
    if (!_lifecycle.IsActive()) return;

    // Scene transitions can invalidate the cached controller before the
    // beatmap callbacks disappear. Reacquire it instead of permanently
    // disabling Vivify's frame updates for the rest of the level.
    if (!IsAlive(_audioTimeSyncController)) {
      _audioTimeSyncController =
          UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
    }
    if (!IsAlive(_audioTimeSyncController)) return;

    DetectSongRestart();
    // DetectSongRestart can call ResetRuntime(), which clears all beatmap
    // state. Never continue into the update systems after that reset.
    if (_isResetting || _currentBeatmapData == nullptr) return;

    // A malformed map component should not prevent unrelated systems (most
    // importantly Blit expiry) from running. Keep every subsystem isolated
    // and identify the failing one in the log.
    auto runUpdateStep = [this](char const* name, auto&& step) {
      try {
        step();
      } catch (std::exception const& ex) {
        LogThrottledUpdateError(std::string(name) + ": " + ex.what());
      } catch (...) {
        LogThrottledUpdateError(std::string(name) + ": non-std exception");
      }
    };

    runUpdateStep("UpdateStartupPostProcessingEvents",
                  [this]() { UpdateStartupPostProcessingEvents(); });
    runUpdateStep("UpdatePrefabPrewarm", [this]() { UpdatePrefabPrewarm(); });
    runUpdateStep("UpdateMaterialAnimations", [this]() { UpdateMaterialAnimations(); });
    runUpdateStep("UpdateGlobalAnimations", [this]() { UpdateGlobalAnimations(); });
    runUpdateStep("UpdateAnimatorAnimations", [this]() { UpdateAnimatorAnimations(); });
    runUpdateStep("UpdateRenderSettingAnimations",
                  [this]() { UpdateRenderSettingAnimations(); });
    runUpdateStep("UpdateBlitEffects", [this]() { UpdateBlitEffects(); });
    runUpdateStep("UpdateSyncedObjects", [this]() { UpdateSyncedObjects(); });
    runUpdateStep("UpdatePrefabAnimationSpeed",
                  [this]() { UpdatePrefabAnimationSpeed(); });

    runUpdateStep("DeferredSaberVisuals", [this]() {
      int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
      if (_deferredSaberVisualsUntilFrame < 0 ||
          frame < _deferredSaberVisualsUntilFrame) {
        return;
      }
      if (_currentBeatmapData != nullptr && !_isResetting) {
        VIVIFY_DEBUG("Vivify applying deferred/retry saber assignment");
        ApplySaberVisualsToActive();
      }
      _deferredSaberVisualsUntilFrame =
          frame < _saberVisualRetryUntilFrame ? frame + 15 : -1;
    });
    runUpdateStep("UpdateSaberReplacementColors",
                  [this]() { UpdateSaberReplacementColors(); });

    // Refresh last so a Blit dispatched by the startup queue is visible for
    // its intended frame, and so expired effects disable the applier again.
    runUpdateStep("RefreshCameraComponents",
                  [this]() { RefreshCameraComponents(true); });
    runUpdateStep("LogQuestPerformanceHeartbeat",
                  [this]() { LogQuestPerformanceHeartbeat(); });
  } catch (std::exception const& ex) {
    LogThrottledUpdateError(std::string("Runtime::Update: ") + ex.what());
  } catch (...) {
    LogThrottledUpdateError("Runtime::Update: non-std exception");
  }
}

void Runtime::TryPrepareSelectedBeatmapFromScene() {
  if (!_selectedMapHasVivifyRequirement || _selectedLevelPath.empty() ||
      _mainBundle == nullptr || !UnityEngine::Object::op_Implicit_bool(_mainBundle) ||
      _beatmapCallbacksController == nullptr) return;

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame < _nextBeatmapPrepareProbeFrame) return;
  _nextBeatmapPrepareProbeFrame = frame + 15;

  auto* audioController =
      UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
  if (!IsAlive(audioController)) return;

  auto* customBeatmapData = GetCustomBeatmapData(_beatmapCallbacksController);
  if (customBeatmapData == nullptr) return;
  float const triggerTime = std::max(0.0f, audioController->get_songTime());
  VIVIFY_DEBUG("Vivify proactive gameplay prepare: customEvents={} songTime={}",
               customBeatmapData->customEventDatas.size(), triggerTime);
  PrepareBeatmap(customBeatmapData, triggerTime, _beatmapCallbacksController);
}

void Runtime::LogThrottledUpdateError(std::string_view what) {

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame - _lastUpdateErrorFrame < 60) return;
  _lastUpdateErrorFrame = frame;
  PaperLogger.error("Vivify Update threw (frame {}, songTime {}): {} — repeats suppressed ~1s",
                    frame, _songTimeCache, std::string(what));
}

float Runtime::CurrentSongTime() {

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame == _songTimeCacheFrame) return _songTimeCache;
  _songTimeCacheFrame = frame;
  // BeatmapCallbacksController is the authoritative clock used to fire the
  // same callbacks that drive notes and cubes. Prefer it over a globally found
  // AudioTimeSyncController so Vivify cannot bind to a stale controller during
  // practice/catch-up or a gameplay-scene transition.
  if (_beatmapCallbacksController != nullptr) {
    _songTimeCache = _beatmapCallbacksController->get_songTime();
    return _songTimeCache;
  }
  if (!IsAlive(_audioTimeSyncController)) {
    _audioTimeSyncController = UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
  }
  _songTimeCache = IsAlive(_audioTimeSyncController) ? _audioTimeSyncController->get_songTime() : 0.0f;
  return _songTimeCache;
}

void Runtime::DetectSongRestart() {
  if (_currentBeatmapData == nullptr || _isResetting) return;
  float songTime = CurrentSongTime();
  // Only reset if there's a significant backward jump (>0.25 second) to avoid
  // false positives at song start (0:00) or small timing adjustments
  if (_lastSongTime >= 0.0f && songTime + 0.25f < _lastSongTime) {
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    bool const restartingFromPause =
        _pauseMenuActive && songTime <= 0.25f && _lastSongTime > 1.0f;
    if (restartingFromPause) {
      // The RestartButtonPressed hook normally retires the session before the
      // scene is dismissed. This remains as a live-scene fallback for practice
      // controllers that seek without invoking the pause-menu method.
      VIVIFY_DEBUG("Vivify detected pause-menu restart; retiring the active session");
      ResetRuntime(ResetMode::LiveScene);
      _nextBeatmapPrepareProbeFrame = frame + 90;
    } else {
      ResetRuntime();
    }
    return;
  }
  _lastSongTime = songTime;
}

float Runtime::CurrentBpm() const {
  if (TracksStatic::bpmController) {
    return TracksStatic::bpmController->get_currentBpm();
  }
  return 0.0f;
}

float Runtime::DurationBeatsToSeconds(float durationBeats) const {
  float bpm = CurrentBpm();
  if (bpm <= 0.0f) {
    return 0.0f;
  }
  return (60.0f * durationBeats) / bpm;
}

void Runtime::RegisterSyncedObject(UnityEngine::GameObject* root,
                                   float eventStartSongTime) {
  if (!IsAlive(root)) return;

  // Prewarmed prefabs can register their persistent video decoders many seconds
  // before the actual InstantiatePrefab event. Reuse that prepared decoder when
  // the same instance goes live instead of destroying/recreating it at t=0.
  for (auto& existing : _syncedObjects) {
    if (existing.root != root) continue;
    float const reuseSongTime = CurrentSongTime();
    existing.startTime = eventStartSongTime;
    existing.needsInitialTimelineSample = true;
    existing.nextVideoClockPollFrame = 0;
    // A prewarmed object can become live after the global playback rate was
    // already applied. Force this newly-live component set to receive the
    // current clock-gated rate on the next update.
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    for (auto& video : existing.videoPlayers) {
      if (video.songSynchronized) {
        video.playbackStartKnown = true;
        video.playbackStartSongTime = eventStartSongTime;
        video.playbackTimelineStarted =
            reuseSongTime + 0.001f >= eventStartSongTime;
      }
      video.needsStartupKick = video.playbackTimelineStarted;
      video.nextStartRetryFrame = 0;
      video.hasProducedTexture = false;
      video.lastDecodedFrame = -1;
      // A prewarmed object can become live after practice speed changed.  Rate
      // state is per decoder, so force this video to receive the current rate.
      video.lastAppliedPlaybackSpeed = std::numeric_limits<float>::quiet_NaN();
      video.prepareNotBeforeFrame = 0;
    }
    bool const recoveredHistoricalVideo =
        RecoverHistoricalVideoStartsForReuse(root, existing, eventStartSongTime, reuseSongTime);
    VIVIFY_DEBUG("Vivify sync: reusing prewarmed synced object '{}' for eventStart={} historicalRecovered={}",
                 ToStdString(root->get_name()), eventStartSongTime, recoveredHistoricalVideo);
    return;
  }

  float const currentSongTime = CurrentSongTime();
  float const initialElapsed =
      PrefabInitialElapsed(currentSongTime, eventStartSongTime);
  SyncedObject synced;
  synced.root = root;
  // Videos remain tied to the absolute event time; only Animator.Update uses
  // the elapsed time inside the prefab.
  synced.startTime = eventStartSongTime;

  auto videoPlayers = root->GetComponentsInChildren<UnityEngine::Video::VideoPlayer*>(true);
  for (int i = 0; i < videoPlayers.size(); i++) {
    auto* authored = videoPlayers[i];
    if (!IsAlive(authored) || !authored->get_playOnAwake()) continue;

    auto const authoredRenderMode = authored->get_renderMode();
    UnityEngine::Renderer* materialTarget = nullptr;
    UnityEngine::RenderTexture* renderTextureTarget = nullptr;
    if (authoredRenderMode.value__ ==
        UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
      auto targetReference = authored->get_targetMaterialRenderer();
      materialTarget = targetReference.unsafePtr();
      if (!IsAlive(materialTarget)) {
        materialTarget = authored->GetComponent<UnityEngine::Renderer*>();
        if (!IsAlive(materialTarget)) {
          materialTarget = authored->GetComponentInChildren<UnityEngine::Renderer*>(true);
        }
        if (IsAlive(materialTarget)) {
          authored->set_targetMaterialRenderer(materialTarget);
          if (ToStdString(authored->get_targetMaterialProperty()).empty()) {
            authored->set_targetMaterialProperty(StringW("_MainTex"));
          }
          PaperLogger.info(
              "Vivify repaired embedded VideoPlayer target: object='{}' renderer='{}' property='{}'",
              ToStdString(authored->get_gameObject()->get_name()),
              ToStdString(materialTarget->get_gameObject()->get_name()),
              ToStdString(authored->get_targetMaterialProperty()));
        } else {
          PaperLogger.warn(
              "Vivify embedded VideoPlayer has no MaterialOverride renderer: object='{}'",
              ToStdString(authored->get_gameObject()->get_name()));
        }
      }
    } else if (authoredRenderMode.value__ ==
               UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
      auto targetReference = authored->get_targetTexture();
      renderTextureTarget = targetReference.unsafePtr();
      if (IsAlive(renderTextureTarget)) {
        if (!renderTextureTarget->IsCreated()) renderTextureTarget->Create();
      } else {
        PaperLogger.warn(
            "Vivify embedded VideoPlayer has no RenderTexture target: object='{}'",
            ToStdString(authored->get_gameObject()->get_name()));
      }
    }

    SyncedVideoPlayer video;
    video.authoredPlayer = authored;
    video.player = authored;
    video.authoredComponentIndex = i;
    video.materialTarget = materialTarget;
    video.renderTextureTarget = renderTextureTarget;
    video.authoredPlayerWasEnabled = authored->get_enabled();
    video.songSynchronized = WouldVideoBeSongSynchronized(root, authored);
    video.authoredActiveStateKnown = true;
    video.authoredWasActive = IsAuthoredVideoGameObjectActive(video);
    if (video.songSynchronized) {
      video.playbackStartKnown = true;
      video.playbackStartSongTime = eventStartSongTime;
      video.playbackTimelineStarted =
          currentSongTime + 0.001f >= eventStartSongTime;
    }

    // Unity VideoPlayer preparation does not progress on an inactive prefab.
    // Move both MaterialOverride and RenderTexture playback to an always-active
    // decoder. Embedded clips can adopt the decoder that was already warmed
    // while the song was selected in the menu.
    bool const supportsPersistentOutput =
        (authoredRenderMode.value__ ==
             UnityEngine::Video::VideoRenderMode::MaterialOverride.value__ &&
         IsAlive(materialTarget)) ||
        (authoredRenderMode.value__ ==
             UnityEngine::Video::VideoRenderMode::RenderTexture.value__ &&
         IsAlive(renderTextureTarget));
    if (supportsPersistentOutput && IsManagedAlive(_behaviour)) {
      UnityEngine::GameObject* decoderObject = nullptr;
      UnityEngine::Video::VideoPlayer* decoder = nullptr;
      bool adoptedWarmup = false;
      if (authored->get_source().value__ == 0) {
        auto clipReference = authored->get_clip();
        decoder = ClaimBundleVideoWarmup(clipReference.unsafePtr(), decoderObject);
        adoptedWarmup = IsAlive(decoder) && IsAlive(decoderObject);
      }

      if (!adoptedWarmup) {
        decoderObject = UnityEngine::GameObject::New_ctor(u"VivifyVideoDecoder");
      }
      if (IsAlive(decoderObject)) {
        // Never deactivate an adopted warmup: on Quest that can retire the
        // MediaCodec instance we are deliberately carrying into gameplay.
        if (!adoptedWarmup) decoderObject->SetActive(false);
        auto behaviourObject = _behaviour->get_gameObject();
        auto* behaviourObjectPtr = behaviourObject.unsafePtr();
        if (IsAlive(behaviourObjectPtr)) {
          decoderObject->get_transform()->SetParent(behaviourObjectPtr->get_transform(), false);
        }
        if (!adoptedWarmup) {
          decoder = decoderObject->AddComponent<UnityEngine::Video::VideoPlayer*>();
        }
        if (IsAlive(decoder)) {
          if (decoder->get_isPlaying()) decoder->Pause();
          if (!adoptedWarmup) {
            // Setting clip/url also selects the matching VideoSource in Unity.
            if (authored->get_source().value__ == 0) {
              decoder->set_clip(authored->get_clip());
            } else {
              decoder->set_url(authored->get_url());
            }
          }
          decoder->set_renderMode(authoredRenderMode);
          if (authoredRenderMode.value__ ==
              UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
            decoder->set_targetMaterialRenderer(materialTarget);
            auto property = authored->get_targetMaterialProperty();
            if (ToStdString(property).empty()) property = StringW("_MainTex");
            decoder->set_targetMaterialProperty(property);
          } else {
            if (!renderTextureTarget->IsCreated()) renderTextureTarget->Create();
            decoder->set_targetTexture(renderTextureTarget);
          }
          auto audioOutputMode = decoder->get_audioOutputMode();
          audioOutputMode.value__ = 0;  // VideoAudioOutputMode::None without linking enum statics.
          decoder->set_audioOutputMode(audioOutputMode);
          decoder->set_playOnAwake(false);
          decoder->set_waitForFirstFrame(true);
          decoder->set_isLooping(authored->get_isLooping());
          decoder->set_skipOnDrop(true);
          decoderObject->SetActive(true);

          if (authored->get_isPlaying()) authored->Pause();
          authored->set_playOnAwake(false);
          authored->set_enabled(false);

          video.player = decoder;
          video.decoderObject = decoderObject;
          video.persistentDecoder = true;
          EnsureVideoOutputBinding(video);
          PaperLogger.info(
              "Vivify {} persistent Quest video decoder: object='{}' output='{}' target='{}' prepared={}",
              adoptedWarmup ? "adopted menu-warmed" : "created",
              ToStdString(authored->get_gameObject()->get_name()),
              authoredRenderMode.value__ ==
                      UnityEngine::Video::VideoRenderMode::RenderTexture.value__
                  ? "RenderTexture"
                  : "MaterialOverride",
              IsAlive(renderTextureTarget)
                  ? ToStdString(renderTextureTarget->get_name())
                  : (IsAlive(materialTarget)
                         ? ToStdString(materialTarget->get_gameObject()->get_name())
                         : std::string("<missing>")),
              decoder->get_isPrepared());
        } else {
          UnityEngine::Object::Destroy(decoderObject);
        }
      }
    }

    auto* vp = video.player;
    if (!IsAlive(vp)) continue;
    video.frameReadyEventsBaseline = vp->get_sendFrameReadyEvents();
    if (!video.persistentDecoder) {
      if (vp->get_isPlaying()) vp->Pause();
      vp->set_playOnAwake(false);
      vp->set_skipOnDrop(true);
    }

    video.needsStartupKick = video.playbackTimelineStarted;
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    video.nextStartRetryFrame = frame;
    video.nextOutputRecoveryFrame = frame;
    video.lastDecodedFrameAdvanceFrame = frame;
    if (!vp->get_isPrepared()) {
      if (initialElapsed <= 0.05f) {
        vp->Prepare();
        video.preparePending = true;
        // Large embedded clips can need several seconds to reserve MediaCodec
        // resources on Quest. Do not repeatedly restart that asynchronous work.
        video.nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames;
      } else {
        // Practice/random starts resolve the authored activation first. Starting
        // every decoder here caused Heartbeat to reserve many MediaCodec slots at
        // once and stall gameplay for seconds before the first visible frame.
        video.preparePending = false;
        video.prepareNotBeforeFrame = std::numeric_limits<int>::max();
      }
    }
    synced.videoPlayers.emplace_back(video);
  }

  float initialSyncSpeed = 0.0f;
  if (!_pauseMenuActive && _syncClockHasAdvanced && IsManagedAlive(_audioTimeSyncController)) {
    float const authoredSpeed = _audioTimeSyncController->get_timeScale();
    if (std::isfinite(authoredSpeed) && authoredSpeed > 0.0f) initialSyncSpeed = authoredSpeed;
  }

  auto animators = root->GetComponentsInChildren<UnityEngine::Animator*>(true);
  for (int i = 0; i < animators.size(); i++) {
    if (!IsAlive(animators[i])) continue;
    animators[i]->set_updateMode(UnityEngine::AnimatorUpdateMode::Normal);
    // Vivify's authored environment animations are song-timed, not visibility-
    // timed. In normal gameplay a large note/custom-model renderer can make a
    // prefab briefly fail Unity's renderer-visibility culling while Zen mode
    // never does. Never let Animator culling stop the authored timeline.
    animators[i]->set_cullingMode(UnityEngine::AnimatorCullingMode::AlwaysAnimate);
  }

  // Reconstruct historical VideoPlayer enable cycles with the same helper used
  // when a prewarmed instance is reused. Keeping one implementation prevents
  // practice/random starts from using a different video lifetime than normal
  // chronological playback.
  if (initialElapsed > 0.05f && !synced.videoPlayers.empty()) {
    RecoverHistoricalVideoStartsForReuse(root, synced, eventStartSongTime, currentSongTime);
  }

  for (int i = 0; i < animators.size(); i++) {
    if (!IsAlive(animators[i])) continue;
    if (initialElapsed > 0.0f) {
      // Do not jump a live state machine by the whole practice offset in one
      // Update. Walk forward chronologically so transition conditions, exit
      // times and GameObject activation happen in the same order as playback.
      AdvanceAnimatorChronologically(animators[i], initialElapsed);
    }
    // Freeze the exact catch-up pose until the authoritative song clock is seen
    // moving. This removes practice-load drift between Zen and normal gameplay.
    animators[i]->set_speed(initialSyncSpeed);
    synced.animators.emplace_back(animators[i]);
  }
  auto legacyAnimations = root->GetComponentsInChildren<UnityEngine::Animation*>(true);
  for (int i = 0; i < legacyAnimations.size(); i++) {
    auto* animation = legacyAnimations[i];
    if (!IsAlive(animation) || !animation->get_playAutomatically()) continue;
    auto* state = DefaultLegacyAnimationState(animation);
    if (state == nullptr || !UnityEngine::TrackedReference::op_Implicit_bool(state)) continue;

    // Unity's legacy Animation clock is independent from AudioTimeSyncController.
    // Dynasty's lyrics and environment prefabs use this component rather than
    // Animator, so sample the authored clip at the actual practice/song time.
    if (initialElapsed > 0.0f) {
      state->set_time(initialElapsed);
      animation->Sample();
    }
    state->set_speed(initialSyncSpeed);
    synced.legacyAnimations.emplace_back(animation);
  }
  auto particleSystems = root->GetComponentsInChildren<UnityEngine::ParticleSystem*>(true);
  for (int i = 0; i < particleSystems.size(); i++) {
    if (!IsAlive(particleSystems[i])) continue;
    auto main = particleSystems[i]->get_main();
    SyncedParticleSystem syncedParticle{
        .particleSystem = particleSystems[i],
        .authoredSimulationSpeed = main.get_simulationSpeed(),
        .clockSuppressed = false,
    };
    SetParticleClockSuppressed(syncedParticle, initialSyncSpeed <= 0.0f);
    synced.particleSystems.emplace_back(syncedParticle);
  }

  if (!synced.videoPlayers.empty() || !synced.animators.empty() ||
      !synced.legacyAnimations.empty() || !synced.particleSystems.empty()) {
    VIVIFY_DEBUG("Vivify sync: registered '{}' with {} video / {} animator / {} legacy animation / {} particle component(s), eventStart={} songTime={} initialElapsed={}",
                 IsAlive(root) ? ToStdString(root->get_name()) : std::string("?"),
                 synced.videoPlayers.size(), synced.animators.size(),
                 synced.legacyAnimations.size(), synced.particleSystems.size(),
                 eventStartSongTime, currentSongTime, initialElapsed);
    _syncedObjects.emplace_back(std::move(synced));
    // A newly registered animator/particle system must receive the current
    // practice speed even if that speed did not change this frame.
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
  }
}

void Runtime::UpdatePrefabAnimationSpeed() {
  if (_syncedObjects.empty()) {
    bool const controllerUnavailable = !IsManagedAlive(_audioTimeSyncController);
    float const songTime = controllerUnavailable ? -1.0f : CurrentSongTime();
    float const timeScale = controllerUnavailable ? 0.0f : _audioTimeSyncController->get_timeScale();
    // Observe the callback clock even before the first synchronized prefab is
    // spawned. A mid-song prefab can then start immediately, while a practice
    // catch-up prefab created during a frozen pre-roll remains pinned.
    (void) ClockGatedSyncRate(_pauseMenuActive || controllerUnavailable,
                              _lastSyncSongTime, songTime, timeScale,
                              _syncClockStallFrames, _syncClockHasAdvanced);
    if (!controllerUnavailable) _lastSyncSongTime = songTime;
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    return;
  }

  bool const controllerUnavailable = !IsManagedAlive(_audioTimeSyncController);
  float const songTime = controllerUnavailable ? -1.0f : CurrentSongTime();
  float const timeScale = controllerUnavailable ? 0.0f : _audioTimeSyncController->get_timeScale();
  float const speed = ClockGatedSyncRate(_pauseMenuActive || controllerUnavailable,
                                          _lastSyncSongTime, songTime, timeScale,
                                          _syncClockStallFrames,
                                          _syncClockHasAdvanced);
  if (!controllerUnavailable) _lastSyncSongTime = songTime;

  if (!MeaningfulRateChange(_lastAppliedSyncSpeed, speed)) return;
  _lastAppliedSyncSpeed = speed;

  auto drive = [speed](std::vector<UnityEngine::Animator*> const& animators,
                       std::vector<UnityEngine::Animation*> const& legacyAnimations,
                       std::vector<SyncedParticleSystem>& particleSystems) {
    for (auto* animator : animators) {
      if (IsManagedAlive(animator)) animator->set_speed(speed);
    }
    for (auto* animation : legacyAnimations) {
      SetLegacyAnimationSpeed(animation, speed);
    }
    for (auto& particleSystem : particleSystems) {
      // Animator-authored ParticleSystem speed curves own the running value.
      // Vivify only suppresses/restores them at song-clock stop transitions.
      SetParticleClockSuppressed(particleSystem, speed <= 0.0f);
    }
  };
  for (auto& synced : _syncedObjects) {
    drive(synced.animators, synced.legacyAnimations, synced.particleSystems);
  }
}

void Runtime::LogQuestPerformanceHeartbeat() {
  if (!GetVivifyDebugLogging()) return;
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame - _lastQuestPerformanceFrame < 900) return;
  _lastQuestPerformanceFrame = frame;
  PaperLogger.info(
      "Vivify Quest perf window: frame={} midCacheHits={} midRebuilds={} imageBlits={} imageCommandBufferCreates={} noteRefreshEvents={} noteRefreshCandidates={} prefabLookupRebuilds={} synced={} livePrefabs={} replacements[note={} saber={} debris={}] declaredTextures={} secondaryCameras={}",
      frame, _midCommandBufferCacheHits, _midCommandBufferRebuilds,
      _imageBlitExecutions, _imageCommandBufferCreates, _noteRefreshEvents,
      _noteRefreshCandidates, _assignedPrefabLookupRebuilds, _syncedObjects.size(),
      _livePrefabs.size(), _noteReplacements.size(), _saberReplacements.size(),
      _debrisReplacements.size(), _declaredTextures.size(), _secondaryCameras.size());
  _midCommandBufferCacheHits = 0;
  _midCommandBufferRebuilds = 0;
  _imageBlitExecutions = 0;
  _imageCommandBufferCreates = 0;
  _noteRefreshEvents = 0;
  _noteRefreshCandidates = 0;
  _assignedPrefabLookupRebuilds = 0;
}

void Runtime::UnregisterSyncedObject(UnityEngine::GameObject* root) {
  for (auto& synced : _syncedObjects) {
    if (synced.root == root) ReleaseSyncedVideos(synced, false);
  }
  _syncedObjects.erase(std::remove_if(_syncedObjects.begin(), _syncedObjects.end(),
                                      [root](SyncedObject const& synced) { return synced.root == root; }),
                       _syncedObjects.end());
}

void Runtime::OnVideoPrepareCompleted(UnityEngine::Video::VideoPlayer* player) {
  if (!IsManagedAlive(player)) return;
  for (auto& synced : _syncedObjects) {
    for (auto& video : synced.videoPlayers) {
      if (video.player != player) continue;
      video.preparePending = false;
      video.nextPrepareRetryFrame = 0;
      return;
    }
  }
}

void Runtime::OnVideoSeekCompleted(UnityEngine::Video::VideoPlayer* player) {
  if (!IsManagedAlive(player)) return;
  for (auto& synced : _syncedObjects) {
    for (auto& video : synced.videoPlayers) {
      if (video.player != player) continue;
      if (video.seekPhase == VideoSeekPhase::Seeking) {
        video.seekCompletedReceived = true;
        // Some Android backends defer/ignore Play while the seek is physically
        // in flight. Retry at seekCompleted, before frameReady, so the decoder
        // can begin advancing as soon as the requested position is reached.
        if (video.activeSeekPlayAfterFrame && !player->get_isPlaying()) {
          player->Play();
        }
      }
      return;
    }
  }
}

void Runtime::OnVideoFrameReady(UnityEngine::Video::VideoPlayer* player,
                                std::int64_t frameIndex) {
  if (!IsManagedAlive(player)) return;
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  for (auto& synced : _syncedObjects) {
    for (auto& video : synced.videoPlayers) {
      if (video.player != player) continue;
      if (VideoSeekBusy(video)) video.frameReadyReceived = true;
      if (frameIndex >= 0) {
        video.lastDecodedFrame = frameIndex;
        video.lastDecodedFrameAdvanceFrame = frame;
      }
      return;
    }
  }
}

void Runtime::UpdateSyncedObjects() {
  if (_syncedObjects.empty()) return;
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  // Explicit DestroyObject paths unregister immediately. This cadence is only
  // a safety net for prefabs destroyed by their own animation/scripts, so a
  // full managed-object validity pass is unnecessary on every render frame.
  if (frame >= _nextSyncedObjectPurgeFrame) {
    _nextSyncedObjectPurgeFrame = frame + 30;
    for (auto& synced : _syncedObjects) {
      if (!IsManagedAlive(synced.root)) ReleaseSyncedVideos(synced, false);
    }
    _syncedObjects.erase(std::remove_if(_syncedObjects.begin(), _syncedObjects.end(),
                                        [](SyncedObject const& synced) { return !IsManagedAlive(synced.root); }),
                         _syncedObjects.end());
  }
  if (_syncedObjects.empty()) return;

  bool const paused = _pauseMenuActive || !IsManagedAlive(_audioTimeSyncController);
  float const songTime = IsManagedAlive(_audioTimeSyncController) ? CurrentSongTime() : 0.0f;
  float const playbackSpeed = IsManagedAlive(_audioTimeSyncController)
                                  ? _audioTimeSyncController->get_timeScale()
                                  : 0.0f;
  // VideoPlayer exposes a seekable time directly, but Unity's legacy
  // AnimationState does not.  Re-sample captions/environment clips on the
  // first live frame and after a real timeline jump (practice start, seek or
  // restart) so they follow the same absolute song clock as video and notes.
  float const unscaledDelta = std::max(1.0f / 240.0f, UnityEngine::Time::get_unscaledDeltaTime());
  float const expectedForwardAdvance = std::max(0.0f, playbackSpeed) * unscaledDelta;
  float const forwardJumpTolerance =
      std::max(0.5f, expectedForwardAdvance * 4.0f + 0.25f);
  bool const timelineJumped =
      _lastSyncSongTime >= 0.0f &&
      (songTime + 0.25f < _lastSyncSongTime ||
       songTime > _lastSyncSongTime + forwardJumpTolerance);

  bool const heartbeat = [&]() {
    if (!GetVivifyDebugLogging()) return false;
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    if (frame - _lastSyncHeartbeatFrame < 120) return false;
    _lastSyncHeartbeatFrame = frame;
    return true;
  }();

  for (auto& synced : _syncedObjects) {
    float const animationTime = std::max(0.0f, songTime - synced.startTime);
    if (synced.needsInitialTimelineSample || timelineJumped) {
      for (auto* animation : synced.legacyAnimations) {
        auto* state = DefaultLegacyAnimationState(animation);
        if (state == nullptr || !UnityEngine::TrackedReference::op_Implicit_bool(state)) continue;
        state->set_time(animationTime);
        animation->Sample();
      }
      synced.needsInitialTimelineSample = false;
      if (timelineJumped) {
        VIVIFY_DEBUG("Vivify sync: sampled legacy animation timeline at songTime={} startTime={} elapsed={}",
                     songTime, synced.startTime, animationTime);
      }
    }
    bool const pollVideoClock = timelineJumped || heartbeat ||
                                frame >= synced.nextVideoClockPollFrame;
    if (pollVideoClock) synced.nextVideoClockPollFrame = frame + 6;
    for (auto& video : synced.videoPlayers) {
      auto* vp = video.player;
      if (!IsManagedAlive(vp)) continue;

      // Preserve the two timing contracts used by desktop Vivify. A
      // playOnAwake player that was active when the prefab root spawned follows
      // the absolute prefab/song clock. A player below an initially-inactive
      // child was never attached to that synchronizer, so its authored enable
      // edges define a local playback epoch instead.
      bool const authoredActive = IsAuthoredVideoGameObjectActive(video);
      if (!video.authoredActiveStateKnown) {
        video.authoredActiveStateKnown = true;
        video.authoredWasActive = authoredActive;
      }
      bool const becameActive = authoredActive && !video.authoredWasActive;
      bool const becameInactive = !authoredActive && video.authoredWasActive;

      if (video.songSynchronized) {
        video.playbackStartKnown = true;
        video.playbackStartSongTime = synced.startTime;
        bool const shouldRunTimeline = songTime + 0.001f >= synced.startTime;
        if (shouldRunTimeline && !video.playbackTimelineStarted) {
          video.playbackTimelineStarted = true;
          video.needsStartupKick = true;
          video.prepareNotBeforeFrame = frame;
          video.preparePending = false;
          video.nextPrepareRetryFrame = frame;
          video.nextStartRetryFrame = frame;
          video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          VIVIFY_DEBUG(
              "Vivify sync: song-synchronized video timeline started at prefabStart={} songTime={}",
              synced.startTime, songTime);
        } else if (!shouldRunTimeline) {
          video.playbackTimelineStarted = false;
        }

        // Hiding a song-synchronized screen must not redefine its clock. A
        // persistent Quest decoder keeps advancing off-screen so the next reveal
        // only rebinds output instead of paying a seek/start latency penalty.
        if (becameInactive) {
          video.wasRenderable = false;
          if (!video.persistentDecoder) {
            if (vp->get_isPlaying()) vp->Pause();
            SuppressVideoSeekPlayback(video);
            video.needsStartupKick = true;
          }
        }
      } else {
        // This player lived below an inactive child at prefab spawn. Recreate
        // local playOnAwake semantics on the persistent decoder: a real authored
        // enable starts at t=0; disable pauses and rewinds while hidden so the
        // next enable can display immediately instead of seeking on-screen.
        if (becameActive && songTime + 0.001f >= synced.startTime) {
          video.playbackStartKnown = true;
          video.playbackStartSongTime = songTime;
          video.playbackTimelineStarted = true;
          video.needsStartupKick = true;
          video.prepareNotBeforeFrame = frame;
          video.preparePending = false;
          video.nextPrepareRetryFrame = frame;
          video.nextStartRetryFrame = frame;
          video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
          video.requestedPrewarmFrame = false;
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          VIVIFY_DEBUG(
              "Vivify sync: local video enable started at songTime={} prefabStart={}",
              video.playbackStartSongTime, synced.startTime);
        } else if (becameInactive) {
          video.playbackStartKnown = false;
          video.playbackTimelineStarted = false;
          video.needsStartupKick = false;
          video.requestedPrewarmFrame = false;
          if (vp->get_isPlaying()) vp->Pause();
          video.hasProducedTexture = false;
          video.wasRenderable = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          // Rewind while hidden. RequestVideoSeek serializes with any seek already
          // in flight, so this cannot recreate the old Android seek storm.
          RequestVideoSeek(video, 0.0, false, frame);
          VIVIFY_DEBUG("Vivify sync: local video disabled; rewinding hidden decoder");
        }
      }
      video.authoredWasActive = authoredActive;

      float const rawVideoTime =
          video.playbackStartKnown
              ? std::max(0.0f, songTime - video.playbackStartSongTime)
              : 0.0f;
      float const videoTime = NormalizeVideoTime(vp, rawVideoTime);
      if (paused) {
        if (vp->get_isPlaying()) {
          VIVIFY_DEBUG("Vivify sync: pausing video (songTime={})", songTime);
          vp->Pause();
        }
        SuppressVideoSeekPlayback(video);
        video.needsStartupKick = true;
        video.wasRenderable = false;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.nextOutputRecoveryFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.nextDriftCorrectionFrame = 0;
        continue;
      }
      if (MeaningfulRateChange(video.lastAppliedPlaybackSpeed, playbackSpeed)) {
        // Always try Unity's native rate control per VideoPlayer. Some Quest
        // backends under-report capability, while the setter still works.
        try {
          vp->set_playbackSpeed(playbackSpeed);
        } catch (...) {
          // Rate fallback below is intentionally conservative; never convert a
          // high-speed practice session into a pause/seek/play storm.
        }
        video.lastAppliedPlaybackSpeed = playbackSpeed;
      }

      // Keep preparation warm even while an authored animation has the video
      // screen hidden. That way a later section does not pay decoder startup
      // latency on the first visible frame.
      if (!vp->get_isPrepared()) {
        if (frame < video.prepareNotBeforeFrame) {
          video.needsStartupKick = true;
          continue;
        }
        if (!video.preparePending || frame >= video.nextPrepareRetryFrame) {
          VIVIFY_DEBUG("Vivify sync: starting/retrying video Prepare after watchdog (songTime={} videoTime={})",
                       songTime, videoTime);
          vp->Prepare();
          video.preparePending = true;
          video.nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames;
        }
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        continue;
      }
      video.preparePending = false;
      video.nextPrepareRetryFrame = 0;
      AdvanceVideoSeekLifecycle(video, frame);

      if (video.persistentDecoder) {
        if (timelineJumped && video.playbackTimelineStarted) {
          video.needsStartupKick = true;
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.nextStartRetryFrame = frame;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
        }

        // Keep an inactive playOnAwake decoder prepared at its beginning without
        // performing a t=0 seek. Prepare + a short Play is enough to obtain the
        // first Android external-texture frame; as soon as one exists, freeze it.
        // This avoids paying an asynchronous seek again on the real enable edge.
        bool const beforeVideoStart = !video.playbackTimelineStarted;
        if (beforeVideoStart) {
          if (VideoSeekBusy(video)) {
            SuppressVideoSeekPlayback(video);
            continue;
          }
          std::int64_t decodedFrame = -1;
          if (HasDecodedVideoOutput(vp, decodedFrame)) {
            EnsureVideoOutputBinding(video);
            video.requestedPrewarmFrame = true;
            video.hasProducedTexture = true;
            video.lastDecodedFrame = decodedFrame;
            video.lastDecodedFrameAdvanceFrame = frame;
            if (vp->get_isPlaying()) vp->Pause();
            continue;
          }
          EnsureVideoOutputBinding(video);
          if (!vp->get_isPlaying()) vp->Play();
          video.requestedPrewarmFrame = true;
          video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;
          video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
          continue;
        }

        // Start the decoder for the current authored enable epoch. Renderer
        // visibility may change inside that epoch, but GameObject disable pauses
        // the clock above and the next enable starts again at t=0.
        if (video.needsStartupKick) {
          // Normal chronological start should already be sitting on the prewarmed
          // first frame. Resume it directly; reserve an asynchronous seek for a
          // real practice/timeline jump or an actually drifted decoder.
          ForceVideoOutputRebind(video);
          bool const resumedWithoutSeek =
              ResumeVideoWithoutSeekIfNearTarget(video, static_cast<double>(videoTime), frame);
          if (!resumedWithoutSeek) {
            RequestVideoSeek(video, static_cast<double>(videoTime), true, frame);
          }
          video.needsStartupKick = false;
          video.requestedPrewarmFrame = true;
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.outputGraceUntilFrame =
              frame + kVideoFirstFrameGraceFrames;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
          video.nextStartRetryFrame = frame + 30;
          video.nextDriftCorrectionFrame =
              frame + kVideoDriftCorrectionCooldownFrames;
          synced.nextVideoClockPollFrame = frame + 2;
          VIVIFY_DEBUG("Vivify sync: started persistent decoder (songTime={} videoTime={})",
                       songTime, videoTime);
          continue;
        }

        if (VideoSeekBusy(video)) continue;
        bool const targetRenderable = IsVideoOutputRenderable(video);
        if (targetRenderable && !video.wasRenderable) {
          // Renderer visibility can toggle while the authored VideoPlayer GameObject
          // remains active. In that case playback lifetime is unchanged; only
          // refresh the Android output-surface binding.
          ForceVideoOutputRebind(video);
          video.wasRenderable = true;
          VIVIFY_DEBUG("Vivify sync: rebound persistent decoder output");
        } else if (!targetRenderable) {
          video.wasRenderable = false;
        }

        // Poll healthy decoders on the shared six-frame cadence. New/recovering
        // decoders still get checked every frame so their first frame is bound
        // as soon as Android produces it.
        if (video.hasProducedTexture && !pollVideoClock) continue;

        std::int64_t decodedFrame = -1;
        bool const hasOutputTexture = HasDecodedVideoOutput(vp, decodedFrame);
        if (hasOutputTexture) {
          if (!video.hasProducedTexture) {
            // Android can create the external texture after the original
            // output assignment. Rebind exactly when the first real
            // decoded frame appears so the screen cannot retain the black shell.
            EnsureVideoOutputBinding(video);
          }
          video.hasProducedTexture = true;
          if (decodedFrame >= 0 && decodedFrame != video.lastDecodedFrame) {
            video.lastDecodedFrame = decodedFrame;
            video.lastDecodedFrameAdvanceFrame = frame;
          }
        }

        bool const shouldAdvance =
            ShouldVideoAdvance(vp, videoTime, playbackSpeed);
        bool const frameIndexAvailable = decodedFrame >= 0 && video.lastDecodedFrame >= 0;
        bool const decoderStalled =
            playbackSpeed <= kVideoAggressiveRecoveryMaxRate && frameIndexAvailable &&
            hasOutputTexture && video.hasProducedTexture && shouldAdvance &&
            vp->get_isPlaying() &&
            frame - video.lastDecodedFrameAdvanceFrame >= kVideoStallFrames;
        bool const missingDecodedFrame = !hasOutputTexture;

        // Recover the individual decoder only after MediaCodec has had a full
        // startup window. The previous 8-12 frame loop could repeatedly seek a
        // slow clip before it ever emitted frame 0, while a pause/resume worked
        // simply because it provided a later clean startup attempt.
        if ((missingDecodedFrame || decoderStalled) &&
            frame >= video.outputGraceUntilFrame &&
            frame >= video.nextOutputRecoveryFrame) {
          RequestVideoSeek(video, static_cast<double>(videoTime), true, frame);
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.outputGraceUntilFrame =
              frame + kVideoFirstFrameGraceFrames;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
          video.nextStartRetryFrame = frame + 30;
          video.nextDriftCorrectionFrame =
              frame + kVideoDriftCorrectionCooldownFrames;
          VIVIFY_DEBUG("Vivify sync: persistent decoder {} at songTime={}; queued one asynchronous seek recovery",
                       decoderStalled ? "stalled" : "has no decoded frame",
                       songTime);
          continue;
        }

        if (!pollVideoClock) continue;
        if (!vp->get_isPlaying()) {
          if (shouldAdvance && frame >= video.nextStartRetryFrame) {
            vp->Play();
            video.nextStartRetryFrame = frame + 30;
          }
          continue;
        }
        float const drift = static_cast<float>(vp->get_time()) - videoTime;
        // Healthy persistent Quest decoders free-run. Repeated set_time() calls
        // on MediaCodec/external textures are exactly what produced the old
        // Teto clipping/twitching. Real startup/seek/recovery paths above are
        // already the only places that are allowed to reposition this decoder.
        if (heartbeat) {
          PaperLogger.info("Vivify sync heartbeat: persistent videoTime={} target={} drift={} prepared={} playing={} texture={} targetVisible={}",
                           static_cast<float>(vp->get_time()), videoTime, drift,
                           vp->get_isPrepared(), vp->get_isPlaying(), hasOutputTexture,
                           targetRenderable);
        }
        continue;
      }

      if (!video.playbackTimelineStarted) {
        if (vp->get_isPlaying()) vp->Pause();
        video.wasRenderable = false;
        video.needsStartupKick = true;
        continue;
      }

      // MaterialOverride output can be detached when either the VideoPlayer's
      // GameObject or its target renderer is disabled and later re-enabled by
      // an Animator. That is the section-to-section failure seen on Quest: the
      // decoder remains prepared but the screen is black until a pause/resume.
      bool componentActive = false;
      auto videoObject = vp->get_gameObject();
      auto* videoObjectPtr = videoObject.unsafePtr();
      if (IsAlive(videoObjectPtr)) componentActive = videoObjectPtr->get_activeInHierarchy();

      bool const targetRenderable = IsVideoOutputRenderable(video);

      bool const renderable = componentActive && targetRenderable;
      if (!renderable) {
        if (video.wasRenderable) {
          VIVIFY_DEBUG("Vivify sync: video target became inactive; arming reactivation kick");
        }
        video.wasRenderable = false;
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        continue;
      }

      if (!video.wasRenderable) {
        // Rebind on the exact transition back to a visible/active screen. This
        // replaces the manual pause/resume users previously needed between
        // authored video sections without restarting already healthy videos.
        video.wasRenderable = true;
        ForceVideoOutputRebind(video);
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.nextStartRetryFrame = frame;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
      }

      if (timelineJumped && video.playbackTimelineStarted) {
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.nextStartRetryFrame = frame;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
      }

      if (video.needsStartupKick) {
        // Rebind the Android output surface, but do not automatically seek. If
        // the decoder kept the right clock position while its renderer was
        // hidden, a direct resume avoids the Heartbeat-style late/black section
        // transition. Only a genuine clock mismatch gets one serialized seek.
        ForceVideoOutputRebind(video);
        bool const resumedWithoutSeek =
            ResumeVideoWithoutSeekIfNearTarget(video, static_cast<double>(videoTime), frame);
        if (!resumedWithoutSeek) {
          RequestVideoSeek(video, static_cast<double>(videoTime), true, frame);
        }
        video.needsStartupKick = false;
        video.hasProducedTexture = false;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame =
            frame + kVideoFirstFrameGraceFrames;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
        video.nextStartRetryFrame = frame + 30;
        video.nextDriftCorrectionFrame =
            frame + kVideoDriftCorrectionCooldownFrames;
        synced.nextVideoClockPollFrame = frame + 2;
        VIVIFY_DEBUG("Vivify sync: video activation/start kick (songTime={} videoTime={})",
                     songTime, videoTime);
        continue;
      }

      if (VideoSeekBusy(video)) continue;

      // As above, keep native decoder-health polling cheap once output is
      // established, while sampling startup/recovery on every frame.
      if (video.hasProducedTexture && !pollVideoClock) continue;

      // VideoPlayer.isPlaying and a non-null external-texture shell are not
      // output-health signals on Quest. Require an actual decoded frame and
      // also watch that its frame index continues to advance.
      std::int64_t decodedFrame = -1;
      bool const hasOutputTexture = HasDecodedVideoOutput(vp, decodedFrame);
      if (hasOutputTexture && !video.hasProducedTexture) {
        // First decoded frame is now real. Re-assert the output once at this
        // transition so its target receives the newly-created external
        // texture even on drivers that ignored the pre-frame binding.
        ForceVideoOutputRebind(video);
        video.hasProducedTexture = true;
      }
      if (hasOutputTexture && decodedFrame >= 0 &&
          decodedFrame != video.lastDecodedFrame) {
        video.lastDecodedFrame = decodedFrame;
        video.lastDecodedFrameAdvanceFrame = frame;
      }

      bool const shouldAdvance =
          ShouldVideoAdvance(vp, videoTime, playbackSpeed);
      bool const frameIndexAvailable = decodedFrame >= 0 && video.lastDecodedFrame >= 0;
      bool const decoderStalled =
          playbackSpeed <= kVideoAggressiveRecoveryMaxRate && frameIndexAvailable &&
          hasOutputTexture && video.hasProducedTexture && shouldAdvance &&
          vp->get_isPlaying() &&
          frame - video.lastDecodedFrameAdvanceFrame >= kVideoStallFrames;

      if ((!hasOutputTexture || decoderStalled) &&
          frame >= video.outputGraceUntilFrame &&
          frame >= video.nextOutputRecoveryFrame) {
        EnsureVideoOutputBinding(video);
        RequestVideoSeek(video, static_cast<double>(videoTime), true, frame);
        video.hasProducedTexture = false;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame =
            frame + kVideoFirstFrameGraceFrames;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
        video.nextStartRetryFrame = frame + 30;
        video.nextDriftCorrectionFrame =
            frame + kVideoDriftCorrectionCooldownFrames;
        synced.nextVideoClockPollFrame = frame + 2;
        VIVIFY_DEBUG("Vivify sync: recovering {} video output (songTime={} videoTime={})",
                     decoderStalled ? "stalled" : "black", songTime,
                     videoTime);
        continue;
      }

      if (!pollVideoClock) continue;
      if (!vp->get_isPlaying()) {
        if (shouldAdvance && frame >= video.nextStartRetryFrame) {
          vp->Play();
          video.nextStartRetryFrame = frame + 30;
          VIVIFY_DEBUG("Vivify sync: retrying prepared video Play (songTime={} videoTime={})",
                       songTime, videoTime);
        }
        continue;
      }

      float const drift = static_cast<float>(vp->get_time()) - videoTime;
      if (playbackSpeed <= kVideoAggressiveRecoveryMaxRate &&
          std::abs(drift) > kVideoDriftToleranceSeconds &&
          frame >= video.nextDriftCorrectionFrame) {
        RequestVideoSeek(video, static_cast<double>(videoTime), true, frame);
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame =
            frame + kVideoFirstFrameGraceFrames;
        video.nextDriftCorrectionFrame =
            frame + kVideoDriftCorrectionCooldownFrames;
      }
      if (heartbeat) {
        PaperLogger.info("Vivify sync heartbeat: videoTime={} target={} songTime={} startTime={} drift={} speed={} prepared={} playing={} renderable={} texture={}",
                         static_cast<float>(vp->get_time()), videoTime, songTime, synced.startTime,
                         drift, playbackSpeed, vp->get_isPrepared(), vp->get_isPlaying(),
                         renderable, hasOutputTexture);
      }
    }
  }
}

bool Runtime::IsReduceDebrisEnabled() {

  if (!_reduceDebrisCached) {
    _reduceDebrisCached = true;
    _reduceDebris = false;
    auto* playerDataModel = UnityEngine::Object::FindObjectOfType<GlobalNamespace::PlayerDataModel*>();
    if (IsManagedAlive(playerDataModel)) {
      auto* playerData = playerDataModel->get_playerData();
      if (playerData != nullptr) {
        auto* settings = playerData->get_playerSpecificSettings();
        if (settings != nullptr) {
          _reduceDebris = settings->get_reduceDebris();
        }
      }
    }
    VIVIFY_DEBUG("Vivify: Reduce Debris player option = {} (custom debris {})", _reduceDebris,
                 _reduceDebris ? "disabled" : "enabled");
  }
  return _reduceDebris;
}

bool Runtime::IsLeftHanded() {
  if (_leftHandedCached) return _leftHanded;

  _leftHandedCached = true;
  _leftHanded = false;
  auto* playerDataModel = UnityEngine::Object::FindObjectOfType<GlobalNamespace::PlayerDataModel*>();
  if (IsAlive(playerDataModel)) {
    auto* playerData = playerDataModel->get_playerData();
    if (playerData != nullptr) {
      auto* settings = playerData->get_playerSpecificSettings();
      if (settings != nullptr) _leftHanded = settings->get_leftHanded();
    }
  }
  VIVIFY_DEBUG("Vivify prefab mirroring: left-handed mode={}", BoolText(_leftHanded));
  return _leftHanded;
}

UnityEngine::Transform* Runtime::EnsureMirroredPrefabParent() {
  if (!IsLeftHanded()) return nullptr;
  if (!IsAlive(_mirroredPrefabParent)) {
    _mirroredPrefabParent = UnityEngine::GameObject::New_ctor(u"VivifyLeftHandPrefabParent");
    if (!IsAlive(_mirroredPrefabParent)) return nullptr;
    _mirroredPrefabParent->get_transform()->set_localScale(UnityEngine::Vector3(-1.0f, 1.0f, 1.0f));
  }
  return _mirroredPrefabParent->get_transform().unsafePtr();
}

void Runtime::SetPauseMenuActive(bool active) {
  _pauseMenuRequested = active;
  ApplyPauseState();
}

void Runtime::SetApplicationPaused(bool paused) {
  _applicationPaused = paused;
  ApplyPauseState();
}

void Runtime::SetApplicationFocused(bool focused) {
  _applicationFocused = focused;
  ApplyPauseState();
}

void Runtime::ApplyPauseState() {
  bool const active = _pauseMenuRequested || _applicationPaused || !_applicationFocused;
  if (_currentBeatmapData == nullptr) {
    _pauseMenuActive = false;
    return;
  }
  if (_pauseMenuActive == active) return;
  _pauseMenuActive = active;
  VIVIFY_DEBUG("Vivify suspension {}: menu={} applicationPaused={} applicationFocused={} syncedObjects={} secondaryCameras={}",
               active ? "entered" : "left", _pauseMenuRequested, _applicationPaused,
               _applicationFocused, _syncedObjects.size(), _secondaryCameras.size());
  if (active) {
    // Suspend Unity-driven prefab time immediately. Runtime::Update stops as
    // soon as the lifecycle is suspended, so deferring this to
    // UpdatePrefabAnimationSpeed lets Animator and ParticleSystem components
    // keep advancing behind the pause or Quest system menu.
    for (auto& synced : _syncedObjects) {
      for (auto* animator : synced.animators) {
        if (IsManagedAlive(animator)) animator->set_speed(0.0f);
      }
      for (auto* animation : synced.legacyAnimations) {
        SetLegacyAnimationSpeed(animation, 0.0f);
      }
      for (auto& particleSystem : synced.particleSystems) {
        SetParticleClockSuppressed(particleSystem, true);
      }
      for (auto& video : synced.videoPlayers) {
        auto* vp = video.player;
        if (IsManagedAlive(vp) && vp->get_isPlaying()) vp->Pause();
        video.needsStartupKick = true;
      }
    }
    _lastAppliedSyncSpeed = 0.0f;

    _lifecycle.Suspend();

    if (_cameraApplier != nullptr && UnityEngine::Object::op_Implicit_bool(_cameraApplier)) {
      _cameraApplier->set_enabled(false);
    }
    // A secondary camera can be disabled intentionally (for example when it
    // has no color/depth target). Remember that state exactly; blindly enabling
    // every camera on resume can render an un-targeted helper into the headset.
    RestoreSecondaryCullingLayers();
    RemoveMidRenderCommandBuffers();
    for (auto& [name, cam] : _secondaryCameras) {
      cam.enabledBeforePause = IsAlive(cam.camera) && cam.camera->get_enabled();
      if (IsAlive(cam.camera)) cam.camera->set_enabled(false);
    }

    RestoreGlobalProperties();

    // Keep authored render and QualitySettings values alive through the pause
    // menu. Restoring antiAliasing here and reapplying it immediately after an
    // Android XR resume can recreate the eye render targets while OpenXR is
    // reattaching its swapchain. The captured XR-resume freeze stopped on exactly
    // that resume path. Desktop Vivify also keeps these values until runtime
    // disposal, so teardown/restart remains the only place that restores them.
    VIVIFY_DEBUG("Vivify pause: preserving {} authored render setting(s) across XR suspend",
                 _currentRenderSettings.size());

    _pausedMaterialAnimations = std::move(_materialAnimations);
    _pausedGlobalAnimations = std::move(_globalAnimations);
    _pausedAnimatorAnimations = std::move(_animatorAnimations);
    _pausedRenderSettingAnimations = std::move(_renderSettingAnimations);
    _materialAnimations.clear();
    _globalAnimations.clear();
    _animatorAnimations.clear();
    _renderSettingAnimations.clear();
  } else {
    for (auto& [name, cam] : _secondaryCameras) {
      if (IsAlive(cam.camera)) cam.camera->set_enabled(cam.enabledBeforePause);
      cam.enabledBeforePause = false;
    }
    VIVIFY_DEBUG("Vivify resume checkpoint: secondary cameras restored");

    ReapplyCurrentGlobalProperties();
    VIVIFY_DEBUG("Vivify resume checkpoint: global shader state restored; authored render settings preserved");
    _materialAnimations = std::move(_pausedMaterialAnimations);
    _globalAnimations = std::move(_pausedGlobalAnimations);
    _animatorAnimations = std::move(_pausedAnimatorAnimations);
    _renderSettingAnimations = std::move(_pausedRenderSettingAnimations);
    _pausedMaterialAnimations.clear();
    _pausedGlobalAnimations.clear();
    _pausedAnimatorAnimations.clear();
    _pausedRenderSettingAnimations.clear();
    VIVIFY_DEBUG("Vivify resume checkpoint: authored animations restored");

    float resumeSpeed = 0.0f;
    if (IsManagedAlive(_audioTimeSyncController)) {
      float const authoredSpeed = _audioTimeSyncController->get_timeScale();
      if (std::isfinite(authoredSpeed) && authoredSpeed > 0.0f) resumeSpeed = authoredSpeed;
    }
    for (auto& synced : _syncedObjects) {
      for (auto* animator : synced.animators) {
        if (IsManagedAlive(animator)) animator->set_speed(resumeSpeed);
      }
      for (auto* animation : synced.legacyAnimations) {
        SetLegacyAnimationSpeed(animation, resumeSpeed);
      }
      for (auto& particleSystem : synced.particleSystems) {
        SetParticleClockSuppressed(particleSystem, resumeSpeed <= 0.0f);
      }
      for (auto& video : synced.videoPlayers) {
        video.needsStartupKick = true;
        video.nextStartRetryFrame = 0;
        video.wasRenderable = false;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.nextOutputRecoveryFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = 0;
        video.nextDriftCorrectionFrame = 0;
      }
      synced.nextVideoClockPollFrame = 0;
    }

    _lifecycle.Resume();
    // Force a fresh callback-clock sample and reapply the practice speed on
    // the first resumed frame. Otherwise a long Android sleep can leave
    // Animator/ParticleSystem components at the pause speed of zero.
    _songTimeCacheFrame = -1;
    _lastSyncSongTime = -1.0f;
    _syncClockStallFrames = 0;
    _syncClockHasAdvanced = false;
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    VIVIFY_DEBUG("Vivify resume checkpoint: lifecycle active; refreshing camera components");
    if (!_isResetting) RefreshCameraComponents(true);
    VIVIFY_DEBUG("Vivify resume complete: songTime={} syncedObjects={} secondaryCameras={} renderSettingsPreserved={}",
                 CurrentSongTime(), _syncedObjects.size(), _secondaryCameras.size(),
                 _currentRenderSettings.size());
  }
}

void Runtime::HandleScenesWillDismiss() {
  if (_currentBeatmapData == nullptr && _lifecycle.Phase() == RuntimePhase::Dormant &&
      _activeSabers.empty() && _cameraApplier == nullptr &&
      _secondaryCameras.empty() && _livePrefabs.empty()) {
    return;
  }
  VIVIFY_DEBUG("Vivify retiring gameplay session before scene dismissal");
  ResetRuntime(ResetMode::EarlySceneTransition);
}

void Runtime::HandleGameplayRestart() {
  if (_currentBeatmapData == nullptr || _isResetting) return;
  VIVIFY_DEBUG("Vivify retiring gameplay session before restart");
  ResetRuntime(ResetMode::LiveScene);
}

bool Runtime::IsCameraApplierCurrent(CameraApplier* applier) const {
  if (!IsAlive(applier) || applier != _cameraApplier ||
      !_lifecycle.CanRender(applier->sessionGeneration)) {
    return false;
  }
  auto gameObject = applier->get_gameObject();
  return IsAlive(gameObject.unsafePtr()) && gameObject.unsafePtr() == _cameraApplierGO;
}

bool Runtime::BeginCameraRender(CameraApplier* applier) {
  return IsCameraApplierCurrent(applier) &&
         _lifecycle.TryEnterRender(applier->sessionGeneration);
}

void Runtime::EndCameraRender(CameraApplier* applier) {
  (void)applier;
  _lifecycle.LeaveRender();
  FinishPendingReset();
}

bool Runtime::ShouldSuppressOriginalImageEffect(
    GlobalNamespace::ImageEffectController* controller) const {
  return IsAlive(controller) && IsCameraApplierCurrent(_cameraApplier) &&
         _cameraApplier->get_enabled() && _cameraApplier->hasMainEffect &&
         _cameraApplier->imageEffectController == controller;
}

void Runtime::OnCameraApplierDestroyed(CameraApplier* applier) {
  RemoveMidRenderCommandBuffers(applier);
  if (_cameraApplier != applier) return;
  _cameraApplier = nullptr;
  _cameraApplierGO = nullptr;
}

void Runtime::RefreshMultipassRendering() {
  auto mainCam = UnityEngine::Camera::get_main();
  auto mainCamGO = IsAlive(mainCam.unsafePtr()) ? mainCam->get_gameObject().unsafePtr() : nullptr;
  RefreshMultipassRendering(mainCamGO);
  RefreshLoadedMaterialStereoKeywords();
}

void Runtime::RefreshIsolationSettings() {
  if (GetDisableAllBlits()) {
    if ((!_preEffects.empty() || !_postEffects.empty() || HasMidRenderEffects()) && GetVivifyDebugLogging()) {
      PaperLogger.info("Vivify isolation: clearing active blits (Blit effects disabled) pre={} post={}",
                       _preEffects.size(), _postEffects.size());
    }
    _preEffects.clear();
    _postEffects.clear();
    for (auto& bucket : _midEffects) bucket.clear();
    DestroyCameraApplier();
    ReleaseMidRenderTextures();
    ReleaseCachedBlitTextures();
  } else if (GetDisableBeat0FilmgrainBlit()) {
    UpdateBlitEffects();
  }

  if (GetDisableCreateCameraDepth()) {
    if (!_secondaryCameras.empty() && GetVivifyDebugLogging()) {
      PaperLogger.info("Vivify isolation: releasing secondary cameras count={}", _secondaryCameras.size());
    }
    for (auto& [name, camera] : _secondaryCameras) {
      ReleaseSecondaryCameraData(camera);
    }
    _secondaryCameras.clear();
    for (auto it = _cameraProperties.begin(); it != _cameraProperties.end();) {
      if (it->first != kMainCameraId) {
        it = _cameraProperties.erase(it);
      } else {
        it++;
      }
    }
  } else {
    // Re-apply stored secondary-camera properties after an isolation setting
    // changes. The culling controller owns temporary layer restoration.
    for (auto& [name, camera] : _secondaryCameras) {
      if (!IsAlive(camera.camera)) continue;
      ApplySecondaryCameraProperties(camera);
      ApplyCameraGameObjectProperties(camera.camera, camera.properties);
    }
  }

  RefreshCameraComponents(_currentBeatmapData != nullptr && !_isResetting && !_pauseMenuActive);
}

void Runtime::ResetRuntime(ResetMode mode) {
  auto const resetRank = [](ResetMode candidate) {
    switch (candidate) {
      case ResetMode::GameplayPreparation: return 0;
      case ResetMode::LiveScene: return 1;
      case ResetMode::EarlySceneTransition: return 2;
      case ResetMode::LateSceneTransition: return 3;
    }
    return 3;
  };
  auto const resetName = [](ResetMode candidate) -> char const* {
    switch (candidate) {
      case ResetMode::GameplayPreparation: return "gameplay-preparation";
      case ResetMode::LiveScene: return "live-scene";
      case ResetMode::EarlySceneTransition: return "early-transition";
      case ResetMode::LateSceneTransition: return "late-transition";
    }
    return "unknown";
  };

  [[maybe_unused]] auto const retiredGeneration = _lifecycle.BeginRetirement();
  if (_lifecycle.RenderDepth() != 0) {
    if (!_pendingResetMode.has_value() ||
        resetRank(mode) > resetRank(_pendingResetMode.value())) {
      _pendingResetMode = mode;
    }
    _isResetting = true;
    VIVIFY_DEBUG("Vivify deferred {} reset until {} active render scope(s) leave",
                 resetName(mode), _lifecycle.RenderDepth());
    return;
  }

  VIVIFY_DEBUG("Vivify ResetRuntime: mode={} livePrefabs={} preloaded={} synced={} secondaryCameras={} declaredTextures={} assets={}",
               resetName(mode), _livePrefabs.size(), _instantiatePrefabs.size(), _syncedObjects.size(),
               _secondaryCameras.size(), _declaredTextures.size(), _assets.size());
  _isResetting = true;
  bool const canTouchSceneObjects = mode != ResetMode::LateSceneTransition;
  bool const preserveGameplayScene =
      mode == ResetMode::GameplayPreparation || mode == ResetMode::LiveScene;
  bool const preserveBundleVideoWarmups =
      mode == ResetMode::GameplayPreparation;

  if (canTouchSceneObjects) {
    // This path is used while the gameplay scene is still alive (for example a
    // practice-mode backward seek), so authored state can be restored normally.
    DestroyCameraApplier();
    RestoreGlobalProperties();
    RestoreAllVisualReplacements();
    RestoreMainCameraOriginals();

    std::unordered_set<UnityEngine::GameObject*> destroyed;
    for (auto& [id, prefab] : _livePrefabs) {
      if (prefab.gameObject == nullptr) continue;
      for (auto const& track : prefab.tracks) track.UnregisterGameObject(prefab.gameObject);
      if (destroyed.emplace(prefab.gameObject).second && IsAlive(prefab.gameObject)) {
        UnityEngine::Object::Destroy(prefab.gameObject);
      }
    }
    for (auto& [eventData, instantiate] : _instantiatePrefabs) {
      if (instantiate.instance != nullptr && destroyed.emplace(instantiate.instance).second &&
          IsAlive(instantiate.instance)) {
        UnityEngine::Object::Destroy(instantiate.instance);
      }
      instantiate.instance = nullptr;
    }
    if (IsAlive(_mirroredPrefabParent)) {
      UnityEngine::Object::Destroy(_mirroredPrefabParent);
    }

    for (auto& [name, dt] : _declaredTextures) ReleaseDeclaredTextureData(dt);
    for (auto& [name, cam] : _secondaryCameras) ReleaseSecondaryCameraData(cam);
    RemoveMidRenderCommandBuffers();
    ReleaseMidRenderTextures();
    ReleaseCachedBlitTextures();
    RestoreRenderSettings();

    if (IsAlive(_multipassController)) {
      _multipassController->set_enabled(false);
      UnityEngine::Object::Destroy(_multipassController);
    }
  } else {
    // Scene transitions are deliberately pointer-free. Crash tombstones showed
    // stale wrappers reaching RenderTexture::Release, Object::Destroy,
    // Renderer.enabled, and Behaviour.enabled after leaving a song. Only static
    // shader bindings are cleared here; Unity owns destruction of the old scene.
    for (auto const& [name, data] : _declaredTextures) {
      UnityEngine::Shader::SetGlobalTexture(data.propertyId, static_cast<UnityEngine::Texture*>(nullptr));
    }
    for (auto const& [name, data] : _secondaryCameras) {
      if (data.texturePropertyId.has_value()) {
        UnityEngine::Shader::SetGlobalTexture(data.texturePropertyId.value(), static_cast<UnityEngine::Texture*>(nullptr));
      }
      if (data.depthTexturePropertyId.has_value()) {
        UnityEngine::Shader::SetGlobalTexture(data.depthTexturePropertyId.value(), static_cast<UnityEngine::Texture*>(nullptr));
      }
    }
    for (auto const& [propertyId, value] : _currentGlobalProperties) {
      if (std::holds_alternative<UnityEngine::Texture*>(value)) {
        UnityEngine::Shader::SetGlobalTexture(propertyId, static_cast<UnityEngine::Texture*>(nullptr));
      }
    }
    for (auto const& [keyword, enabled] : _savedGlobalKeywords) {
      if (enabled) UnityEngine::Shader::EnableKeyword(StringW(keyword));
      else UnityEngine::Shader::DisableKeyword(StringW(keyword));
    }

    // Do not Dispose/Destroy transition-owned native objects. Clear every raw
    // pointer so the persistent VivifyRuntime behaviour cannot touch them on a
    // later menu frame or when another song is selected.
    _cameraApplier = nullptr;
    _cameraApplierGO = nullptr;
    _multipassController = nullptr;
    _lastMainCameraGO = nullptr;
    _midCommandBufferCamera = nullptr;
    _midCommandBufferOwner = nullptr;
    _activeMidCommandBuffers.clear();
    _midSelfBlitTemps.clear();
    _midRenderCommandCache.Invalidate();
    _midMainRT = nullptr;
    _midScratchRT = nullptr;
    _mainBlitTexture = nullptr;
    _scratchBlitTexture = nullptr;
    ReleaseImageBlitCommandBuffer(false);
    SetMultipassShaderState(false);
    _beatmapCallbacksController = nullptr;
  }

  _livePrefabs.clear();
  _instantiatePrefabs.clear();
  _deferredPrefabPrewarms.clear();
  if (!preserveBundleVideoWarmups) ReleaseBundleVideoWarmups();
  // Persistent video decoder proxies live under VivifyRuntime (DontDestroyOnLoad),
  // not under the gameplay prefab. They must be explicitly retired on every
  // reset or they would survive into the next song with stale renderer targets.
  for (auto& synced : _syncedObjects) ReleaseSyncedVideos(synced, false);
  _syncedObjects.clear();
  _blitMaterialValidCache.clear();
  _warnedInvalidBlitPasses.clear();
  _loggedBlitStereoMaterials.clear();
  _materialAnimations.clear();
  _globalAnimations.clear();
  _animatorAnimations.clear();
  _renderSettingAnimations.clear();
  _pausedMaterialAnimations.clear();
  _pausedGlobalAnimations.clear();
  _pausedAnimatorAnimations.clear();
  _pausedRenderSettingAnimations.clear();
  _savedGlobalProperties.clear();
  _savedGlobalKeywords.clear();
  _currentGlobalProperties.clear();
  _currentGlobalKeywords.clear();
  _repairedMaterials.clear();
  _genericFallbackMaterials.clear();
  _assets.clear();
  _assetsByName.clear();
  _ambiguousAssetAliases.clear();
  _missingAssetKeys.clear();
  _missingInstantiatePrefabAssets.clear();
  _supportedShadersByName.clear();
  _catchUpAppliedCustomEvents.clear();
  _deferredStartupPostProcessingEvents.clear();
  _deferredSaberVisualsUntilFrame = -1;
  _saberVisualRetryUntilFrame = -1;
  _lastSaberIntegrityFrame = -1000;
  _warnedInvalidBeatmapData = false;
  _warnedStartupDescriptorWait = false;
  _postProcessingReadyFrame = -1;
  _nextBeatmapPrepareProbeFrame = 0;
  _nextSyncedObjectPurgeFrame = 0;
  _declaredTextures.clear();
  _secondaryCameras.clear();
  _preEffects.clear();
  _postEffects.clear();
  for (auto& bucket : _midEffects) bucket.clear();
  _midRenderCommandCache.Invalidate();
  _hasMainDescriptor = false;
  _cachedMainVrUsage = -1;
  _savedRenderSettings.clear();
  _currentRenderSettings.clear();
  _assignedPrefabs.clear();
  InvalidateAssignedPrefabLookup();
  _activeDebrisPrefabStack.clear();
  _lastCutDebrisPrefabs.clear();
  if (!preserveGameplayScene) {
    _activeSabers.clear();
    _activeNoteControllers.clear();
  } else {
    // PrepareBeatmap and practice/restart resets run while the same gameplay
    // scene (and SaberModelController objects) are still alive. Erasing this
    // list made AssignObjectPrefab at beat 0 a no-op until pausing/restarting
    // happened to reconstruct the saber hierarchy.
    PurgeInvalidActiveSabers();
    for (auto it = _activeNoteControllers.begin(); it != _activeNoteControllers.end();) {
      if (!IsAlive(*it)) {
        it = _activeNoteControllers.erase(it);
      } else {
        ++it;
      }
    }
  }
  _noteReplacements.clear();
  _saberReplacements.clear();
  _debrisReplacements.clear();
  _cameraProperties.clear();
  _mainCameraPropsDirty = false;
  _mainCamOriginalDepthMode.reset();
  _mainCamOriginalClearFlags.reset();
  _mainCamOriginalBackgroundColor.reset();
  _mirroredPrefabParent = nullptr;

  if (preserveGameplayScene && _mainBundle != nullptr && !UnityEngine::Object::op_Implicit_bool(_mainBundle)) {
    _mainBundle = nullptr;
    _preloadedBundlePath.clear();
  }
  if (!preserveGameplayScene) _beatmapCallbacksController = nullptr;
  _currentBeatmapData = nullptr;
  _beatmapAD = nullptr;
  _audioTimeSyncController = nullptr;
  _lastSongTime = -1.0f;
  _lastSyncSongTime = -1.0f;
  _syncClockStallFrames = 0;
  _syncClockHasAdvanced = false;
  _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
  _lastQuestPerformanceFrame = -1000;
  _midCommandBufferCacheHits = 0;
  _midCommandBufferRebuilds = 0;
  _imageBlitExecutions = 0;
  _imageCommandBufferCreates = 0;
  _noteRefreshEvents = 0;
  _noteRefreshCandidates = 0;
  _assignedPrefabLookupRebuilds = 0;
  _songTimeCacheFrame = -1;
  _songTimeCache = 0.0f;
  _pauseMenuRequested = false;
  _applicationPaused = false;
  _applicationFocused = true;
  _pauseMenuActive = false;
  _reduceDebrisCached = false;
  _reduceDebris = false;
  _leftHandedCached = false;
  _leftHanded = false;
  _preparingGeneration = 0;
  _pendingResetMode.reset();
  [[maybe_unused]] bool const retired = _lifecycle.CompleteRetirement();
  _isResetting = false;
}

void Runtime::FinishPendingReset() {
  if (_lifecycle.RenderDepth() != 0 || !_pendingResetMode.has_value()) return;
  auto const mode = _pendingResetMode.value();
  _pendingResetMode.reset();
  _isResetting = false;
  ResetRuntime(mode);
}

}
