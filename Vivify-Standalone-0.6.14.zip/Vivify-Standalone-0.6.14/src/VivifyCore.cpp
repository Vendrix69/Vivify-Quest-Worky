#include "VivifyRuntimeInternal.hpp"
#include "VivifyComponents.hpp"
#include "UnityEngine/ParticleSystem.hpp"
#include "GlobalNamespace/PlayerDataModel.hpp"
#include "GlobalNamespace/PlayerData.hpp"
#include "GlobalNamespace/PlayerSpecificSettings.hpp"
#include "UnityEngine/SceneManagement/Scene.hpp"
#include "UnityEngine/SceneManagement/SceneManager.hpp"

namespace Vivify {

namespace {
constexpr int kVideoPrepareWatchdogFrames = 900;
constexpr int kVideoFirstFrameGraceFrames = 120;
constexpr int kVideoRecoveryBackoffFrames = 180;
constexpr int kVideoStallFrames = 300;
constexpr int kVideoDriftCorrectionCooldownFrames = 60;
constexpr float kVideoDriftToleranceSeconds = 0.5f;

bool IsMainMenuSceneActive() {
  auto scene = UnityEngine::SceneManagement::SceneManager::GetActiveScene();
  return scene.get_name() == "MainMenu";
}

UnityEngine::AnimationState* DefaultLegacyAnimationState(
    UnityEngine::Animation* animation) {
  if (!IsManagedAlive(animation)) return nullptr;
  auto clip = animation->get_clip();
  auto* clipPtr = clip.unsafePtr();
  if (!IsManagedAlive(clipPtr)) return nullptr;
  return animation->get_Item(clipPtr->get_name());
}

void SetLegacyAnimationSpeed(UnityEngine::Animation* animation, float speed) {
  auto* state = DefaultLegacyAnimationState(animation);
  if (state != nullptr && UnityEngine::TrackedReference::op_Implicit_bool(state)) {
    state->set_speed(speed);
  }
}

bool HasDecodedVideoOutput(UnityEngine::Video::VideoPlayer* player,
                           std::int64_t& decodedFrame) {
  decodedFrame = -1;
  if (!IsManagedAlive(player) || !player->get_isPrepared()) return false;

  auto texture = player->get_texture();
  if (!IsManagedAlive(texture.unsafePtr())) return false;

  // Android hardware decoders do not guarantee a usable frame index for every
  // clip. Some healthy Quest VideoPlayers report -1 while their external
  // texture is decoding normally. Treat texture + dimensions as the health
  // signal and use frame only when the backend actually exposes it.
  decodedFrame = player->get_frame();
  return player->get_width() > 0 && player->get_height() > 0;
}

bool ShouldVideoAdvance(UnityEngine::Video::VideoPlayer* player,
                        float videoTime, float playbackSpeed) {
  if (!IsManagedAlive(player) || playbackSpeed <= 0.001f) return false;
  if (player->get_isLooping()) return true;

  double const length = player->get_length();
  return !std::isfinite(length) || length <= 0.0 ||
         static_cast<double>(videoTime) + 0.1 < length;
}

float NormalizeVideoTime(UnityEngine::Video::VideoPlayer* player,
                         float elapsed) {
  if (!IsManagedAlive(player) || !player->get_isPrepared() ||
      !player->get_isLooping()) {
    return elapsed;
  }

  double const length = player->get_length();
  if (!std::isfinite(length) || length <= 0.0) return elapsed;
  return static_cast<float>(std::fmod(static_cast<double>(elapsed), length));
}

bool IsAuthoredVideoPlaybackActive(SyncedVideoPlayer const& video) {
  auto* authored = video.authoredPlayer;
  if (!IsManagedAlive(authored)) return true;
  auto object = authored->get_gameObject();
  auto* objectPtr = object.unsafePtr();
  return IsManagedAlive(objectPtr) && objectPtr->get_activeInHierarchy() &&
         authored->get_enabled();
}

std::string AuthoredVideoMaterialProperty(SyncedVideoPlayer const& video) {
  if (!IsManagedAlive(video.authoredPlayer)) return "_MainTex";
  std::string property = ToStdString(video.authoredPlayer->get_targetMaterialProperty());
  return property.empty() ? std::string("_MainTex") : property;
}

bool VideosShareOutput(SyncedVideoPlayer const& left,
                       SyncedVideoPlayer const& right) {
  if (&left == &right || !left.persistentDecoder || !right.persistentDecoder) {
    return false;
  }
  if (IsManagedAlive(left.renderTextureTarget) &&
      left.renderTextureTarget == right.renderTextureTarget) {
    return true;
  }
  return IsManagedAlive(left.materialTarget) &&
         left.materialTarget == right.materialTarget &&
         AuthoredVideoMaterialProperty(left) ==
             AuthoredVideoMaterialProperty(right);
}

void SetPersistentVideoPresentation(SyncedVideoPlayer& video, bool active) {
  video.outputPresentationActive = active;
  auto* player = video.player;
  if (!video.persistentDecoder || !IsManagedAlive(player)) return;

  auto mode = player->get_renderMode();
  int const desiredMode = active && video.authoredRenderModeValue >= 0
                              ? video.authoredRenderModeValue
                              : UnityEngine::Video::VideoRenderMode::APIOnly.value__;
  if (mode.value__ != desiredMode) {
    mode.value__ = desiredMode;
    player->set_renderMode(mode);
  }
}

bool EnsureVideoOutputBinding(SyncedVideoPlayer& video) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return false;

  auto renderMode = player->get_renderMode();
  if (video.persistentDecoder) {
    // Decoder lifetime and presentation lifetime are separate. A hidden
    // section must keep decoding for later reveals, but it must not retain
    // ownership of a shared MaterialOverride/RenderTexture while hidden.
    int const desiredMode =
        video.outputPresentationActive && video.authoredRenderModeValue >= 0
            ? video.authoredRenderModeValue
            : UnityEngine::Video::VideoRenderMode::APIOnly.value__;
    if (renderMode.value__ != desiredMode) {
      renderMode.value__ = desiredMode;
      player->set_renderMode(renderMode);
    }
    if (!video.outputPresentationActive) return true;
  }
  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    auto* target = video.renderTextureTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetTexture();
      target = targetReference.unsafePtr();
      video.renderTextureTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    if (!target->IsCreated()) target->Create();
    player->set_targetTexture(target);
    return target->IsCreated();
  }

  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    auto* target = video.materialTarget;
    if (!IsManagedAlive(target) && IsManagedAlive(video.authoredPlayer)) {
      auto targetReference = video.authoredPlayer->get_targetMaterialRenderer();
      target = targetReference.unsafePtr();
      if (!IsManagedAlive(target)) {
        target = video.authoredPlayer->GetComponent<UnityEngine::Renderer*>();
        if (!IsManagedAlive(target)) {
          target = video.authoredPlayer->GetComponentInChildren<UnityEngine::Renderer*>(true);
        }
      }
      video.materialTarget = target;
    }
    if (!IsManagedAlive(target)) return false;
    player->set_targetMaterialRenderer(target);
    // Keep the proxy's own MaterialOverride property contract. The Heartbeat-
    // working build used Unity's normal _MainTex target; copying arbitrary
    // authored property names onto the persistent proxy can bind a valid
    // decoder to a material slot that is not the visible video surface on
    // Quest, producing a solid white renderer even though playback is healthy.
    // AuthoredVideoMaterialProperty is still used only to identify whether two
    // authored players logically share an output for Teto-style arbitration.
    if (ToStdString(player->get_targetMaterialProperty()).empty()) {
      player->set_targetMaterialProperty(StringW("_MainTex"));
    }
    return true;
  }

  return true;
}

bool IsVideoOutputRenderable(SyncedVideoPlayer& video) {
  auto* player = video.player;
  if (!IsManagedAlive(player)) return false;
  auto renderMode = player->get_renderMode();
  if (video.persistentDecoder) {
    if (!video.outputPresentationActive) return false;
    if (video.authoredRenderModeValue >= 0 &&
        renderMode.value__ != video.authoredRenderModeValue) {
      renderMode.value__ = video.authoredRenderModeValue;
      player->set_renderMode(renderMode);
    }
  }
  if (renderMode.value__ ==
      UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
    return EnsureVideoOutputBinding(video);
  }
  if (renderMode.value__ !=
      UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
    return true;
  }
  if (!EnsureVideoOutputBinding(video) || !IsManagedAlive(video.materialTarget)) {
    return false;
  }
  auto targetObject = video.materialTarget->get_gameObject();
  auto* targetObjectPtr = targetObject.unsafePtr();
  return video.materialTarget->get_enabled() && IsManagedAlive(targetObjectPtr) &&
         targetObjectPtr->get_activeInHierarchy();
}

void ReleaseSyncedVideoPlayer(SyncedVideoPlayer& video, bool restoreAuthoredPlayer) {
  if (restoreAuthoredPlayer && IsManagedAlive(video.authoredPlayer)) {
    if (video.authoredRenderModeValue >= 0) {
      auto restoredMode = video.authoredPlayer->get_renderMode();
      restoredMode.value__ = video.authoredRenderModeValue;
      video.authoredPlayer->set_renderMode(restoredMode);
    }
    video.authoredPlayer->set_enabled(video.authoredPlayerWasEnabled);
    video.authoredPlayer->set_playOnAwake(video.authoredPlayerWasPlayOnAwake);
  }
  if (IsManagedAlive(video.decoderObject)) {
    UnityEngine::Object::Destroy(video.decoderObject);
  }
  video.player = nullptr;
  video.authoredPlayer = nullptr;
  video.decoderObject = nullptr;
  video.materialTarget = nullptr;
  video.renderTextureTarget = nullptr;
}

void ReleaseSyncedVideos(SyncedObject& synced, bool restoreAuthoredPlayer) {
  for (auto& video : synced.videoPlayers) {
    ReleaseSyncedVideoPlayer(video, restoreAuthoredPlayer);
  }
  synced.videoPlayers.clear();
}

void SetParticleClockSuppressed(SyncedParticleSystem& syncedParticle,
                                bool suppress) {
  auto* particleSystem = syncedParticle.particleSystem;
  if (!IsManagedAlive(particleSystem)) return;

  auto main = particleSystem->get_main();
  if (suppress) {
    if (!syncedParticle.clockSuppressed) {
      // Capture at the transition to a stopped song clock. Animator clips are
      // allowed to key this property every frame, so the current value—not the
      // prefab's original serialized value—is the one that must be restored.
      float const authoredSpeed = main.get_simulationSpeed();
      if (std::isfinite(authoredSpeed)) {
        syncedParticle.authoredSimulationSpeed = authoredSpeed;
      }
      syncedParticle.clockSuppressed = true;
    }
    main.set_simulationSpeed(0.0f);
    return;
  }

  if (syncedParticle.clockSuppressed) {
    main.set_simulationSpeed(syncedParticle.authoredSimulationSpeed);
    syncedParticle.clockSuppressed = false;
  }
}
}

Runtime& Runtime::Instance() {
  static Runtime runtime;
  return runtime;
}

bool Runtime::IsAlive(UnityEngine::Object* object) const {
  return IsManagedAlive(object);
}

void Runtime::LateLoad() {
  auto cjdModInfo = CustomJSONData::modInfo.to_c();
  auto tracksModInfo = CModInfo{.id = "Tracks"};
  modloader_require_mod(&cjdModInfo, CMatchType::MatchType_IdOnly);
  modloader_require_mod(&tracksModInfo, CMatchType::MatchType_IdOnly);
  EnsureBehaviour();
  if (!SongCore::API::Capabilities::IsCapabilityRegistered(kCapability)) {
    SongCore::API::Capabilities::RegisterCapability(kCapability);
  }
  CustomJSONData::CustomEventCallbacks::AddCustomEventCallback(&Runtime::OnCustomEventStatic);
  SongCore::API::LevelSelect::GetLevelWasSelectedEvent() += [](SongCore::API::LevelSelect::LevelWasSelectedEventArgs const& event) {
    Runtime::Instance().HandleLevelSelected(event);
  };
}

void Runtime::EnsureBehaviour() {
  if (_behaviour != nullptr) {
    return;
  }
  auto* gameObject = UnityEngine::GameObject::New_ctor(u"VivifyRuntime");
  UnityEngine::Object::DontDestroyOnLoad(gameObject);
  _behaviour = gameObject->AddComponent<RuntimeBehaviour*>();
  RefreshCameraComponents(false);
}

void Runtime::OnBehaviourDestroyed(RuntimeBehaviour* behaviour) {
  if (_behaviour == behaviour) _behaviour = nullptr;
}

void Runtime::OnCustomEventStatic(GlobalNamespace::BeatmapCallbacksController* callbackController,
                                  CustomJSONData::CustomEventData* customEventData) {
  Runtime::Instance().HandleCustomEvent(callbackController, customEventData);
}

void Runtime::Update() {
  try {
    if (_isResetting) return;

    // Beatmap callbacks can outlive the gameplay scene by several frames.
    // Leaving authored materials and CameraApplier active during that window
    // attached them to MenuMainCamera and eventually passed a destroyed
    // Material into CommandBuffer.Blit.  The transition reset is deliberately
    // pointer-free, so it is safe even after Unity has begun scene teardown.
    if (_currentBeatmapData != nullptr && IsMainMenuSceneActive()) {
      PaperLogger.info("Vivify detected MainMenu with live beatmap state; applying transition-safe reset");
      ResetRuntime(ResetMode::LateSceneTransition);
      return;
    }

    if (_currentBeatmapData == nullptr) {
      // Bundle video decoding begins in the menu. Keep its readiness gate
      // moving even though no gameplay beatmap is active yet.
      UpdateBundleVideoWarmups();
      // A seek can intentionally tear down live state. Rebuild from the active
      // gameplay callback, but do not probe every menu frame while Unity is
      // still constructing or destroying that callback.
      TryPrepareSelectedBeatmapFromScene();
      if (_currentBeatmapData == nullptr) return;
    }
    if (!_lifecycle.IsActive()) return;

    // Scene transitions can invalidate the cached controller before the
    // beatmap callbacks disappear. Reacquire it instead of permanently
    // disabling Vivify's frame updates for the rest of the level.
    if (!IsAlive(_audioTimeSyncController)) {
      _audioTimeSyncController =
          UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
    }
    if (!IsAlive(_audioTimeSyncController)) return;

    DetectSongRestart();
    // DetectSongRestart can call ResetRuntime(), which clears all beatmap
    // state. Never continue into the update systems after that reset.
    if (_isResetting || _currentBeatmapData == nullptr) return;

    // A malformed map component should not prevent unrelated systems (most
    // importantly Blit expiry) from running. Keep every subsystem isolated
    // and identify the failing one in the log.
    auto runUpdateStep = [this](char const* name, auto&& step) {
      try {
        step();
      } catch (std::exception const& ex) {
        LogThrottledUpdateError(std::string(name) + ": " + ex.what());
      } catch (...) {
        LogThrottledUpdateError(std::string(name) + ": non-std exception");
      }
    };

    runUpdateStep("UpdateStartupPostProcessingEvents",
                  [this]() { UpdateStartupPostProcessingEvents(); });
    runUpdateStep("UpdatePrefabPrewarm", [this]() { UpdatePrefabPrewarm(); });
    runUpdateStep("UpdateMaterialAnimations", [this]() { UpdateMaterialAnimations(); });
    runUpdateStep("UpdateGlobalAnimations", [this]() { UpdateGlobalAnimations(); });
    runUpdateStep("UpdateAnimatorAnimations", [this]() { UpdateAnimatorAnimations(); });
    runUpdateStep("UpdateRenderSettingAnimations",
                  [this]() { UpdateRenderSettingAnimations(); });
    runUpdateStep("UpdateBlitEffects", [this]() { UpdateBlitEffects(); });
    runUpdateStep("UpdateSyncedObjects", [this]() { UpdateSyncedObjects(); });
    runUpdateStep("UpdatePrefabAnimationSpeed",
                  [this]() { UpdatePrefabAnimationSpeed(); });

    runUpdateStep("DeferredSaberVisuals", [this]() {
      int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
      if (_deferredSaberVisualsUntilFrame < 0 ||
          frame < _deferredSaberVisualsUntilFrame) {
        return;
      }
      if (_currentBeatmapData != nullptr && !_isResetting) {
        VIVIFY_DEBUG("Vivify applying deferred/retry saber assignment");
        ApplySaberVisualsToActive();
      }
      _deferredSaberVisualsUntilFrame =
          frame < _saberVisualRetryUntilFrame ? frame + 15 : -1;
    });
    runUpdateStep("UpdateSaberReplacementColors",
                  [this]() { UpdateSaberReplacementColors(); });

    // Refresh last so a Blit dispatched by the startup queue is visible for
    // its intended frame, and so expired effects disable the applier again.
    runUpdateStep("RefreshCameraComponents",
                  [this]() { RefreshCameraComponents(true); });
    runUpdateStep("LogQuestPerformanceHeartbeat",
                  [this]() { LogQuestPerformanceHeartbeat(); });
  } catch (std::exception const& ex) {
    LogThrottledUpdateError(std::string("Runtime::Update: ") + ex.what());
  } catch (...) {
    LogThrottledUpdateError("Runtime::Update: non-std exception");
  }
}

void Runtime::TryPrepareSelectedBeatmapFromScene() {
  if (!_selectedMapHasVivifyRequirement || _selectedLevelPath.empty() ||
      _mainBundle == nullptr || !UnityEngine::Object::op_Implicit_bool(_mainBundle) ||
      _beatmapCallbacksController == nullptr) return;

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame < _nextBeatmapPrepareProbeFrame) return;
  _nextBeatmapPrepareProbeFrame = frame + 15;

  auto* audioController =
      UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
  if (!IsAlive(audioController)) return;

  auto* customBeatmapData = GetCustomBeatmapData(_beatmapCallbacksController);
  if (customBeatmapData == nullptr) return;
  float const triggerTime = std::max(0.0f, audioController->get_songTime());
  VIVIFY_DEBUG("Vivify proactive gameplay prepare: customEvents={} songTime={}",
               customBeatmapData->customEventDatas.size(), triggerTime);
  PrepareBeatmap(customBeatmapData, triggerTime, _beatmapCallbacksController);
}

void Runtime::LogThrottledUpdateError(std::string_view what) {

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame - _lastUpdateErrorFrame < 60) return;
  _lastUpdateErrorFrame = frame;
  PaperLogger.error("Vivify Update threw (frame {}, songTime {}): {} — repeats suppressed ~1s",
                    frame, _songTimeCache, std::string(what));
}

float Runtime::CurrentSongTime() {

  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame == _songTimeCacheFrame) return _songTimeCache;
  _songTimeCacheFrame = frame;
  // BeatmapCallbacksController is the authoritative clock used to fire the
  // same callbacks that drive notes and cubes. Prefer it over a globally found
  // AudioTimeSyncController so Vivify cannot bind to a stale controller during
  // practice/catch-up or a gameplay-scene transition.
  if (_beatmapCallbacksController != nullptr) {
    _songTimeCache = _beatmapCallbacksController->get_songTime();
    return _songTimeCache;
  }
  if (!IsAlive(_audioTimeSyncController)) {
    _audioTimeSyncController = UnityEngine::Object::FindObjectOfType<GlobalNamespace::AudioTimeSyncController*>();
  }
  _songTimeCache = IsAlive(_audioTimeSyncController) ? _audioTimeSyncController->get_songTime() : 0.0f;
  return _songTimeCache;
}

void Runtime::DetectSongRestart() {
  if (_currentBeatmapData == nullptr || _isResetting) return;
  float songTime = CurrentSongTime();
  // Only reset if there's a significant backward jump (>0.25 second) to avoid
  // false positives at song start (0:00) or small timing adjustments
  if (_lastSongTime >= 0.0f && songTime + 0.25f < _lastSongTime) {
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    bool const restartingFromPause =
        _pauseMenuActive && songTime <= 0.25f && _lastSongTime > 1.0f;
    if (restartingFromPause) {
      // The RestartButtonPressed hook normally retires the session before the
      // scene is dismissed. This remains as a live-scene fallback for practice
      // controllers that seek without invoking the pause-menu method.
      VIVIFY_DEBUG("Vivify detected pause-menu restart; retiring the active session");
      ResetRuntime(ResetMode::LiveScene);
      _nextBeatmapPrepareProbeFrame = frame + 90;
    } else {
      ResetRuntime();
    }
    return;
  }
  _lastSongTime = songTime;
}

float Runtime::CurrentBpm() const {
  if (TracksStatic::bpmController) {
    return TracksStatic::bpmController->get_currentBpm();
  }
  return 0.0f;
}

float Runtime::DurationBeatsToSeconds(float durationBeats) const {
  float bpm = CurrentBpm();
  if (bpm <= 0.0f) {
    return 0.0f;
  }
  return (60.0f * durationBeats) / bpm;
}

void Runtime::RegisterSyncedObject(UnityEngine::GameObject* root,
                                   float eventStartSongTime) {
  if (!IsAlive(root)) return;

  // Prewarmed prefabs can register their persistent video decoders many seconds
  // before the actual InstantiatePrefab event. Reuse that prepared decoder when
  // the same instance goes live instead of destroying/recreating it at t=0.
  for (auto& existing : _syncedObjects) {
    if (existing.root != root) continue;
    existing.startTime = eventStartSongTime;
    existing.needsInitialTimelineSample = true;
    existing.nextVideoClockPollFrame = 0;
    // A prewarmed object can become live after the global playback rate was
    // already applied. Force this newly-live component set to receive the
    // current clock-gated rate on the next update.
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    for (auto& video : existing.videoPlayers) {
      video.needsStartupKick = true;
      video.nextStartRetryFrame = 0;
      video.hasProducedTexture = false;
      video.lastDecodedFrame = -1;
      video.playbackElapsedBeforePause = 0.0f;
      bool const authoredActive = IsAuthoredVideoPlaybackActive(video);
      video.authoredPlaybackActive = authoredActive;
      video.playbackTimelineStarted = authoredActive;
      video.outputPresentationActive = false;
      if (video.persistentDecoder) {
        SetPersistentVideoPresentation(video, false);
      }
      video.activeSegmentStartSongTime = authoredActive ? eventStartSongTime : 0.0f;
      if (IsManagedAlive(video.player) && video.player->get_isPlaying()) {
        video.player->Pause();
      }
    }
    VIVIFY_DEBUG("Vivify sync: reusing prewarmed synced object '{}' for eventStart={}",
                 ToStdString(root->get_name()), eventStartSongTime);
    return;
  }

  float const currentSongTime = CurrentSongTime();
  float const initialElapsed =
      PrefabInitialElapsed(currentSongTime, eventStartSongTime);
  SyncedObject synced;
  synced.root = root;
  // Videos remain tied to the absolute event time; only Animator.Update uses
  // the elapsed time inside the prefab.
  synced.startTime = eventStartSongTime;

  auto videoPlayers = root->GetComponentsInChildren<UnityEngine::Video::VideoPlayer*>(true);
  for (int i = 0; i < videoPlayers.size(); i++) {
    auto* authored = videoPlayers[i];
    if (!IsAlive(authored) || !authored->get_playOnAwake()) continue;

    auto const authoredRenderMode = authored->get_renderMode();
    UnityEngine::Renderer* materialTarget = nullptr;
    UnityEngine::RenderTexture* renderTextureTarget = nullptr;
    if (authoredRenderMode.value__ ==
        UnityEngine::Video::VideoRenderMode::MaterialOverride.value__) {
      auto targetReference = authored->get_targetMaterialRenderer();
      materialTarget = targetReference.unsafePtr();
      if (!IsAlive(materialTarget)) {
        materialTarget = authored->GetComponent<UnityEngine::Renderer*>();
        if (!IsAlive(materialTarget)) {
          materialTarget = authored->GetComponentInChildren<UnityEngine::Renderer*>(true);
        }
        if (IsAlive(materialTarget)) {
          authored->set_targetMaterialRenderer(materialTarget);
          if (ToStdString(authored->get_targetMaterialProperty()).empty()) {
            authored->set_targetMaterialProperty(StringW("_MainTex"));
          }
          PaperLogger.info(
              "Vivify repaired embedded VideoPlayer target: object='{}' renderer='{}' property='{}'",
              ToStdString(authored->get_gameObject()->get_name()),
              ToStdString(materialTarget->get_gameObject()->get_name()),
              ToStdString(authored->get_targetMaterialProperty()));
        } else {
          PaperLogger.warn(
              "Vivify embedded VideoPlayer has no MaterialOverride renderer: object='{}'",
              ToStdString(authored->get_gameObject()->get_name()));
        }
      }
    } else if (authoredRenderMode.value__ ==
               UnityEngine::Video::VideoRenderMode::RenderTexture.value__) {
      auto targetReference = authored->get_targetTexture();
      renderTextureTarget = targetReference.unsafePtr();
      if (IsAlive(renderTextureTarget)) {
        if (!renderTextureTarget->IsCreated()) renderTextureTarget->Create();
      } else {
        PaperLogger.warn(
            "Vivify embedded VideoPlayer has no RenderTexture target: object='{}'",
            ToStdString(authored->get_gameObject()->get_name()));
      }
    }

    SyncedVideoPlayer video;
    video.authoredPlayer = authored;
    video.player = authored;
    video.materialTarget = materialTarget;
    video.renderTextureTarget = renderTextureTarget;
    video.authoredPlayerWasEnabled = authored->get_enabled();
    video.authoredPlayerWasPlayOnAwake = authored->get_playOnAwake();
    video.authoredRenderModeValue = authoredRenderMode.value__;

    // Unity VideoPlayer preparation does not progress on an inactive prefab.
    // Move both MaterialOverride and RenderTexture playback to an always-active
    // decoder. Embedded clips can adopt the decoder that was already warmed
    // while the song was selected in the menu.
    bool const supportsPersistentOutput =
        (authoredRenderMode.value__ ==
             UnityEngine::Video::VideoRenderMode::MaterialOverride.value__ &&
         IsAlive(materialTarget)) ||
        (authoredRenderMode.value__ ==
             UnityEngine::Video::VideoRenderMode::RenderTexture.value__ &&
         IsAlive(renderTextureTarget));
    if (supportsPersistentOutput && IsManagedAlive(_behaviour)) {
      UnityEngine::GameObject* decoderObject = nullptr;
      UnityEngine::Video::VideoPlayer* decoder = nullptr;
      bool adoptedWarmup = false;
      if (authored->get_source().value__ == 0) {
        auto clipReference = authored->get_clip();
        decoder = ClaimBundleVideoWarmup(clipReference.unsafePtr(), decoderObject);
        adoptedWarmup = IsAlive(decoder) && IsAlive(decoderObject);
      }

      if (!adoptedWarmup) {
        decoderObject = UnityEngine::GameObject::New_ctor(u"VivifyVideoDecoder");
      }
      if (IsAlive(decoderObject)) {
        // Never deactivate an adopted warmup: on Quest that can retire the
        // MediaCodec instance we are deliberately carrying into gameplay.
        if (!adoptedWarmup) decoderObject->SetActive(false);
        auto behaviourObject = _behaviour->get_gameObject();
        auto* behaviourObjectPtr = behaviourObject.unsafePtr();
        if (IsAlive(behaviourObjectPtr)) {
          decoderObject->get_transform()->SetParent(behaviourObjectPtr->get_transform(), false);
        }
        if (!adoptedWarmup) {
          decoder = decoderObject->AddComponent<UnityEngine::Video::VideoPlayer*>();
        }
        if (IsAlive(decoder)) {
          if (decoder->get_isPlaying()) decoder->Pause();
          if (!adoptedWarmup) {
            // Setting clip/url also selects the matching VideoSource in Unity.
            if (authored->get_source().value__ == 0) {
              decoder->set_clip(authored->get_clip());
            } else {
              decoder->set_url(authored->get_url());
            }
          }
          // Keep the warm/prepared proxy API-only until the authored event
          // actually starts. Binding a menu-warmed decoder to the live
          // MaterialOverride/RenderTexture here leaks whatever frame the
          // decoder reached in the menu onto the gameplay surface before the
          // event and then forces a visible seek backwards.
          auto proxyMode = decoder->get_renderMode();
          proxyMode.value__ = UnityEngine::Video::VideoRenderMode::APIOnly.value__;
          decoder->set_renderMode(proxyMode);
          auto audioOutputMode = decoder->get_audioOutputMode();
          audioOutputMode.value__ = 0;  // VideoAudioOutputMode::None without linking enum statics.
          decoder->set_audioOutputMode(audioOutputMode);
          decoder->set_playOnAwake(false);
          decoder->set_waitForFirstFrame(true);
          // Do not overwrite the proxy's MaterialOverride property here.
          // Unity initializes the proxy for _MainTex, which is the behavior
          // verified by the Heartbeat-working build. The authored property is
          // retained on authoredPlayer for shared-output identity only.
          decoder->set_isLooping(authored->get_isLooping());
          decoder->set_skipOnDrop(true);
          decoderObject->SetActive(true);

          if (authored->get_isPlaying()) authored->Pause();
          // Keep the authored component enabled so its GameObject/component
          // activation remains observable, but remove its render ownership.
          // Pausing + playOnAwake=false is not sufficient on Android: an enabled
          // VideoPlayer can continue publishing its retained external texture to
          // MaterialOverride/RenderTexture while the proxy publishes new frames,
          // producing the characteristic two-frame/character flicker. APIOnly
          // makes the authored player a lifecycle probe and the proxy the sole
          // owner of the visible output.
          authored->set_playOnAwake(false);
          auto authoredProbeMode = authored->get_renderMode();
          authoredProbeMode.value__ = UnityEngine::Video::VideoRenderMode::APIOnly.value__;
          authored->set_renderMode(authoredProbeMode);

          video.player = decoder;
          video.decoderObject = decoderObject;
          video.persistentDecoder = true;
          PaperLogger.info(
              "Vivify {} persistent Quest video decoder: object='{}' output='{}' target='{}' prepared={}",
              adoptedWarmup ? "adopted menu-warmed" : "created",
              ToStdString(authored->get_gameObject()->get_name()),
              authoredRenderMode.value__ ==
                      UnityEngine::Video::VideoRenderMode::RenderTexture.value__
                  ? "RenderTexture"
                  : "MaterialOverride",
              IsAlive(renderTextureTarget)
                  ? ToStdString(renderTextureTarget->get_name())
                  : (IsAlive(materialTarget)
                         ? ToStdString(materialTarget->get_gameObject()->get_name())
                         : std::string("<missing>")),
              decoder->get_isPrepared());
        } else {
          UnityEngine::Object::Destroy(decoderObject);
        }
      }
    }

    auto* vp = video.player;
    if (!IsAlive(vp)) continue;
    if (!video.persistentDecoder) {
      if (vp->get_isPlaying()) vp->Pause();
      vp->set_playOnAwake(false);
      vp->set_skipOnDrop(true);
    }

    bool const authoredActiveAtRegistration = IsAuthoredVideoPlaybackActive(video);
    video.authoredPlaybackActive = authoredActiveAtRegistration;
    video.playbackTimelineStarted = authoredActiveAtRegistration;
    video.outputPresentationActive = false;
    if (video.persistentDecoder) {
      // Keep every proxy API-only until UpdateSyncedObjects has seen the full
      // output topology and can grant one deterministic owner.
      SetPersistentVideoPresentation(video, false);
    }
    video.playbackElapsedBeforePause = 0.0f;
    video.activeSegmentStartSongTime =
        authoredActiveAtRegistration ? eventStartSongTime : 0.0f;

    video.needsStartupKick = true;
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    video.nextStartRetryFrame = frame;
    video.nextOutputRecoveryFrame = frame;
    video.lastDecodedFrameAdvanceFrame = frame;
    if (!vp->get_isPrepared()) {
      vp->Prepare();
      video.preparePending = true;
      // Large embedded clips can need several seconds to reserve MediaCodec
      // resources on Quest. Do not repeatedly restart that asynchronous work.
      video.nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames;
    }
    synced.videoPlayers.emplace_back(video);
  }

  float initialSyncSpeed = 0.0f;
  if (!_pauseMenuActive && _syncClockHasAdvanced && IsManagedAlive(_audioTimeSyncController)) {
    float const authoredSpeed = _audioTimeSyncController->get_timeScale();
    if (std::isfinite(authoredSpeed) && authoredSpeed > 0.0f) initialSyncSpeed = authoredSpeed;
  }

  auto animators = root->GetComponentsInChildren<UnityEngine::Animator*>(true);
  for (int i = 0; i < animators.size(); i++) {
    if (!IsAlive(animators[i])) continue;
    animators[i]->set_updateMode(UnityEngine::AnimatorUpdateMode::Normal);
    // Vivify's authored environment animations are song-timed, not visibility-
    // timed. In normal gameplay a large note/custom-model renderer can make a
    // prefab briefly fail Unity's renderer-visibility culling while Zen mode
    // never does. Never let Animator culling stop the authored timeline.
    animators[i]->set_cullingMode(UnityEngine::AnimatorCullingMode::AlwaysAnimate);
    if (initialElapsed > 0.0f) animators[i]->Update(initialElapsed);
    // Freeze the exact catch-up pose until the authoritative song clock is seen
    // moving. This removes practice-load drift between Zen and normal gameplay.
    animators[i]->set_speed(initialSyncSpeed);
    synced.animators.emplace_back(animators[i]);
  }
  auto legacyAnimations = root->GetComponentsInChildren<UnityEngine::Animation*>(true);
  for (int i = 0; i < legacyAnimations.size(); i++) {
    auto* animation = legacyAnimations[i];
    if (!IsAlive(animation) || !animation->get_playAutomatically()) continue;
    auto* state = DefaultLegacyAnimationState(animation);
    if (state == nullptr || !UnityEngine::TrackedReference::op_Implicit_bool(state)) continue;

    // Unity's legacy Animation clock is independent from AudioTimeSyncController.
    // Dynasty's lyrics and environment prefabs use this component rather than
    // Animator, so sample the authored clip at the actual practice/song time.
    if (initialElapsed > 0.0f) {
      state->set_time(initialElapsed);
      animation->Sample();
    }
    state->set_speed(initialSyncSpeed);
    synced.legacyAnimations.emplace_back(animation);
  }
  auto particleSystems = root->GetComponentsInChildren<UnityEngine::ParticleSystem*>(true);
  for (int i = 0; i < particleSystems.size(); i++) {
    if (!IsAlive(particleSystems[i])) continue;
    auto main = particleSystems[i]->get_main();
    SyncedParticleSystem syncedParticle{
        .particleSystem = particleSystems[i],
        .authoredSimulationSpeed = main.get_simulationSpeed(),
        .clockSuppressed = false,
    };
    SetParticleClockSuppressed(syncedParticle, initialSyncSpeed <= 0.0f);
    synced.particleSystems.emplace_back(syncedParticle);
  }

  if (!synced.videoPlayers.empty() || !synced.animators.empty() ||
      !synced.legacyAnimations.empty() || !synced.particleSystems.empty()) {
    VIVIFY_DEBUG("Vivify sync: registered '{}' with {} video / {} animator / {} legacy animation / {} particle component(s), eventStart={} songTime={} initialElapsed={}",
                 IsAlive(root) ? ToStdString(root->get_name()) : std::string("?"),
                 synced.videoPlayers.size(), synced.animators.size(),
                 synced.legacyAnimations.size(), synced.particleSystems.size(),
                 eventStartSongTime, currentSongTime, initialElapsed);
    _syncedObjects.emplace_back(std::move(synced));
    // A newly registered animator/particle system must receive the current
    // practice speed even if that speed did not change this frame.
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
  }
}

void Runtime::UpdatePrefabAnimationSpeed() {
  if (_syncedObjects.empty()) {
    bool const controllerUnavailable = !IsManagedAlive(_audioTimeSyncController);
    float const songTime = controllerUnavailable ? -1.0f : CurrentSongTime();
    float const timeScale = controllerUnavailable ? 0.0f : _audioTimeSyncController->get_timeScale();
    // Observe the callback clock even before the first synchronized prefab is
    // spawned. A mid-song prefab can then start immediately, while a practice
    // catch-up prefab created during a frozen pre-roll remains pinned.
    (void) ClockGatedSyncRate(_pauseMenuActive || controllerUnavailable,
                              _lastSyncSongTime, songTime, timeScale,
                              _syncClockStallFrames, _syncClockHasAdvanced);
    if (!controllerUnavailable) _lastSyncSongTime = songTime;
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    return;
  }

  bool const controllerUnavailable = !IsManagedAlive(_audioTimeSyncController);
  float const songTime = controllerUnavailable ? -1.0f : CurrentSongTime();
  float const timeScale = controllerUnavailable ? 0.0f : _audioTimeSyncController->get_timeScale();
  float const speed = ClockGatedSyncRate(_pauseMenuActive || controllerUnavailable,
                                          _lastSyncSongTime, songTime, timeScale,
                                          _syncClockStallFrames,
                                          _syncClockHasAdvanced);
  if (!controllerUnavailable) _lastSyncSongTime = songTime;

  if (!MeaningfulRateChange(_lastAppliedSyncSpeed, speed)) return;
  _lastAppliedSyncSpeed = speed;

  auto drive = [speed](std::vector<UnityEngine::Animator*> const& animators,
                       std::vector<UnityEngine::Animation*> const& legacyAnimations,
                       std::vector<SyncedParticleSystem>& particleSystems) {
    for (auto* animator : animators) {
      if (IsManagedAlive(animator)) animator->set_speed(speed);
    }
    for (auto* animation : legacyAnimations) {
      SetLegacyAnimationSpeed(animation, speed);
    }
    for (auto& particleSystem : particleSystems) {
      // Animator-authored ParticleSystem speed curves own the running value.
      // Vivify only suppresses/restores them at song-clock stop transitions.
      SetParticleClockSuppressed(particleSystem, speed <= 0.0f);
    }
  };
  for (auto& synced : _syncedObjects) {
    drive(synced.animators, synced.legacyAnimations, synced.particleSystems);
  }
}

void Runtime::LogQuestPerformanceHeartbeat() {
  if (!GetVivifyDebugLogging()) return;
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  if (frame - _lastQuestPerformanceFrame < 900) return;
  _lastQuestPerformanceFrame = frame;
  PaperLogger.info(
      "Vivify Quest perf window: frame={} midCacheHits={} midRebuilds={} imageBlits={} imageCommandBufferCreates={} noteRefreshEvents={} noteRefreshCandidates={} prefabLookupRebuilds={} synced={} livePrefabs={} replacements[note={} saber={} debris={}] declaredTextures={} secondaryCameras={}",
      frame, _midCommandBufferCacheHits, _midCommandBufferRebuilds,
      _imageBlitExecutions, _imageCommandBufferCreates, _noteRefreshEvents,
      _noteRefreshCandidates, _assignedPrefabLookupRebuilds, _syncedObjects.size(),
      _livePrefabs.size(), _noteReplacements.size(), _saberReplacements.size(),
      _debrisReplacements.size(), _declaredTextures.size(), _secondaryCameras.size());
  _midCommandBufferCacheHits = 0;
  _midCommandBufferRebuilds = 0;
  _imageBlitExecutions = 0;
  _imageCommandBufferCreates = 0;
  _noteRefreshEvents = 0;
  _noteRefreshCandidates = 0;
  _assignedPrefabLookupRebuilds = 0;
}

void Runtime::UnregisterSyncedObject(UnityEngine::GameObject* root) {
  for (auto& synced : _syncedObjects) {
    if (synced.root == root) ReleaseSyncedVideos(synced, false);
  }
  _syncedObjects.erase(std::remove_if(_syncedObjects.begin(), _syncedObjects.end(),
                                      [root](SyncedObject const& synced) { return synced.root == root; }),
                       _syncedObjects.end());
}

void Runtime::UpdateSyncedObjects() {
  if (_syncedObjects.empty()) return;
  int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
  // Explicit DestroyObject paths unregister immediately. This cadence is only
  // a safety net for prefabs destroyed by their own animation/scripts, so a
  // full managed-object validity pass is unnecessary on every render frame.
  if (frame >= _nextSyncedObjectPurgeFrame) {
    _nextSyncedObjectPurgeFrame = frame + 30;
    for (auto& synced : _syncedObjects) {
      if (!IsManagedAlive(synced.root)) ReleaseSyncedVideos(synced, false);
    }
    _syncedObjects.erase(std::remove_if(_syncedObjects.begin(), _syncedObjects.end(),
                                        [](SyncedObject const& synced) { return !IsManagedAlive(synced.root); }),
                         _syncedObjects.end());
  }
  if (_syncedObjects.empty()) return;

  bool const paused = _pauseMenuActive || !IsManagedAlive(_audioTimeSyncController);
  float const songTime = IsManagedAlive(_audioTimeSyncController) ? CurrentSongTime() : 0.0f;
  // Video event start times are authored in the same timeline used by
  // BeatmapCallbacksController. Do not mix AudioTimeSyncController::songTime
  // with callback-authored startTime values: the two clocks can differ during
  // gameplay startup/catch-up, which turns a harmless scheduler offset into a
  // visible seek ahead. Keep one clock domain for event time and video time.
  float const playbackSpeed = IsManagedAlive(_audioTimeSyncController)
                                  ? _audioTimeSyncController->get_timeScale()
                                  : 0.0f;
  // VideoPlayer exposes a seekable time directly, but Unity's legacy
  // AnimationState does not.  Re-sample captions/environment clips on the
  // first live frame and after a real timeline jump (practice start, seek or
  // restart) so they follow the same absolute song clock as video and notes.
  bool const timelineJumped =
      _lastSyncSongTime >= 0.0f &&
      (songTime + 0.25f < _lastSyncSongTime || songTime > _lastSyncSongTime + 0.5f);

  bool const heartbeat = [&]() {
    if (!GetVivifyDebugLogging()) return false;
    int const frame = static_cast<int>(UnityEngine::Time::get_frameCount());
    if (frame - _lastSyncHeartbeatFrame < 120) return false;
    _lastSyncHeartbeatFrame = frame;
    return true;
  }();

  // Lone-player clips and shared-screen clip sets need different hide behavior.
  // Heartbeat uses one player that must keep advancing while hidden; maps such
  // as Teto-style cut sequences can have several players take turns on the same
  // MaterialOverride/RenderTexture and expect each hidden section to pause.
  auto hasSharedVideoOutput = [this](SyncedVideoPlayer const& video) {
    if (!video.persistentDecoder) return false;
    for (auto const& candidateObject : _syncedObjects) {
      for (auto const& candidate : candidateObject.videoPlayers) {
        if (VideosShareOutput(video, candidate)) return true;
      }
    }
    return false;
  };

  // Resolve overlapping authored activation deterministically. Only the last
  // active player in stable map/component order may publish to a shared output.
  // Other decoders are kept API-only, so Android never has two writers racing
  // one screen/RenderTexture.
  auto isPreferredSharedOutputOwner = [this](SyncedVideoPlayer const& video) {
    if (!IsAuthoredVideoPlaybackActive(video)) return false;
    bool passedVideo = false;
    for (auto const& candidateObject : _syncedObjects) {
      for (auto const& candidate : candidateObject.videoPlayers) {
        if (&candidate == &video) {
          passedVideo = true;
          continue;
        }
        if (passedVideo && VideosShareOutput(video, candidate) &&
            IsAuthoredVideoPlaybackActive(candidate)) {
          return false;
        }
      }
    }
    return true;
  };

  for (auto& synced : _syncedObjects) {
    float const animationTime = std::max(0.0f, songTime - synced.startTime);
    if (synced.needsInitialTimelineSample || timelineJumped) {
      for (auto* animation : synced.legacyAnimations) {
        auto* state = DefaultLegacyAnimationState(animation);
        if (state == nullptr || !UnityEngine::TrackedReference::op_Implicit_bool(state)) continue;
        state->set_time(animationTime);
        animation->Sample();
      }
      synced.needsInitialTimelineSample = false;
      if (timelineJumped) {
        VIVIFY_DEBUG("Vivify sync: sampled legacy animation timeline at songTime={} startTime={} elapsed={}",
                     songTime, synced.startTime, animationTime);
      }
    }
    bool const pollVideoClock = timelineJumped || heartbeat ||
                                frame >= synced.nextVideoClockPollFrame;
    if (pollVideoClock) synced.nextVideoClockPollFrame = frame + 6;
    for (auto& video : synced.videoPlayers) {
      auto* vp = video.player;
      if (!IsManagedAlive(vp)) continue;
      if (paused) {
        if (vp->get_isPlaying()) {
          VIVIFY_DEBUG("Vivify sync: pausing video (songTime={})", songTime);
          vp->Pause();
        }
        video.needsStartupKick = true;
        video.wasRenderable = false;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.nextOutputRecoveryFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.nextDriftCorrectionFrame = 0;
        continue;
      }
      if (MeaningfulRateChange(synced.lastVideoPlaybackSpeed, playbackSpeed)) {
        vp->set_playbackSpeed(playbackSpeed);
        synced.lastVideoPlaybackSpeed = playbackSpeed;
      }

      // Keep preparation warm even while an authored animation has the video
      // screen hidden. That way a later section does not pay decoder startup
      // latency on the first visible frame.
      if (!vp->get_isPrepared()) {
        if (!video.preparePending || frame >= video.nextPrepareRetryFrame) {
          VIVIFY_DEBUG("Vivify sync: starting/retrying video Prepare after watchdog (songTime={})",
                       songTime);
          vp->Prepare();
          video.preparePending = true;
          video.nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames;
        }
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        continue;
      }
      video.preparePending = false;
      video.nextPrepareRetryFrame = 0;

      if (video.persistentDecoder) {
        bool const beforeEventStart = songTime + 0.001f < synced.startTime;
        if (beforeEventStart) {
          // Prefab prewarming is decoder-only. Never publish output or start the
          // authored video timeline before the InstantiatePrefab event.
          if (!video.requestedPrewarmFrame) {
            vp->set_time(0.0);
            vp->Play();
            video.requestedPrewarmFrame = true;
            video.outputGraceUntilFrame = frame + kVideoFirstFrameGraceFrames;
            video.nextOutputRecoveryFrame = frame + kVideoRecoveryBackoffFrames;
            video.lastDecodedFrame = -1;
            video.lastDecodedFrameAdvanceFrame = frame;
          }
          if (!video.hasProducedTexture) {
            std::int64_t decodedFrame = -1;
            if (HasDecodedVideoOutput(vp, decodedFrame)) {
              video.hasProducedTexture = true;
              video.lastDecodedFrame = decodedFrame;
              video.lastDecodedFrameAdvanceFrame = frame;
              if (vp->get_isPlaying()) vp->Pause();
              vp->set_time(0.0);
            }
          }
          continue;
        }

        bool const authoredActive = IsAuthoredVideoPlaybackActive(video);
        bool const sharedOutput = hasSharedVideoOutput(video);
        bool const ownsSharedOutput =
            !sharedOutput || isPreferredSharedOutputOwner(video);
        bool const presentationActive = authoredActive && ownsSharedOutput;
        bool const timelineGate = sharedOutput ? presentationActive : authoredActive;

        if (!video.playbackTimelineStarted) {
          if (!timelineGate) {
            SetPersistentVideoPresentation(video, false);
            if (vp->get_isPlaying()) vp->Pause();
            continue;
          }
          video.playbackTimelineStarted = true;
          video.authoredPlaybackActive = authoredActive;
          video.playbackElapsedBeforePause = 0.0f;
          video.activeSegmentStartSongTime = songTime;
          SetPersistentVideoPresentation(video, presentationActive);
          video.needsStartupKick = true;
          video.nextStartRetryFrame = frame;
        } else if (sharedOutput) {
          bool const wasPresentationActive = video.outputPresentationActive;
          video.authoredPlaybackActive = authoredActive;
          if (presentationActive != wasPresentationActive) {
            if (!presentationActive) {
              video.playbackElapsedBeforePause +=
                  std::max(0.0f, songTime - video.activeSegmentStartSongTime);
              SetPersistentVideoPresentation(video, false);
              video.wasRenderable = false;
              if (vp->get_isPlaying()) vp->Pause();
              video.needsStartupKick = true;
              continue;
            }
            video.activeSegmentStartSongTime = songTime;
            SetPersistentVideoPresentation(video, true);
            video.wasRenderable = false;
            video.needsStartupKick = true;
            video.nextStartRetryFrame = frame;
            VIVIFY_DEBUG("Vivify sync: shared video output ownership changed; resuming local segment");
          }
          if (!presentationActive) continue;
        } else if (authoredActive != video.authoredPlaybackActive) {
          // Lone output: preserve Heartbeat-style continuity after the first
          // authored start. Hiding only detaches presentation; time keeps moving.
          video.authoredPlaybackActive = authoredActive;
          SetPersistentVideoPresentation(video, authoredActive);
          video.wasRenderable = false;
          if (authoredActive) {
            EnsureVideoOutputBinding(video);
            VIVIFY_DEBUG("Vivify sync: persistent video presentation resumed without timeline restart");
          } else {
            VIVIFY_DEBUG("Vivify sync: persistent video presentation hidden; decoder continues APIOnly");
          }
        } else if (video.outputPresentationActive != presentationActive) {
          // Registration starts API-only so target ownership cannot leak before
          // the first complete update/arbitration pass.
          SetPersistentVideoPresentation(video, presentationActive);
          video.wasRenderable = false;
          if (presentationActive) EnsureVideoOutputBinding(video);
        }

        float const rawVideoTime =
            video.playbackElapsedBeforePause +
            std::max(0.0f, songTime - video.activeSegmentStartSongTime);
        float const videoTime = NormalizeVideoTime(vp, rawVideoTime);

        if (timelineJumped) {
          video.needsStartupKick = true;
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.nextStartRetryFrame = frame;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
        }

        // Start/restart the decoder at the current timeline position. Lone
        // outputs keep running while hidden; shared-output players only reach
        // this point while they own their active section.
        if (video.needsStartupKick) {
          EnsureVideoOutputBinding(video);
          if (vp->get_isPlaying()) vp->Pause();
          vp->set_time(static_cast<double>(videoTime));
          vp->Play();
          video.needsStartupKick = false;
          video.requestedPrewarmFrame = true;
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.outputGraceUntilFrame =
              frame + kVideoFirstFrameGraceFrames;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
          video.nextStartRetryFrame = frame + 30;
          video.nextDriftCorrectionFrame =
              frame + kVideoDriftCorrectionCooldownFrames;
          synced.nextVideoClockPollFrame = frame + 2;
          VIVIFY_DEBUG("Vivify sync: started persistent decoder (songTime={} videoTime={})",
                       songTime, videoTime);
        }

        bool const targetRenderable = IsVideoOutputRenderable(video);
        if (targetRenderable && !video.wasRenderable) {
          // A lone decoder may have kept running while hidden; a shared decoder
          // reaches here after its local segment restart. In both cases only the
          // current owner is allowed to bind the output.
          EnsureVideoOutputBinding(video);
          video.wasRenderable = true;
          VIVIFY_DEBUG("Vivify sync: rebound persistent decoder output");
        } else if (!targetRenderable) {
          video.wasRenderable = false;
        }

        // Poll healthy decoders on the shared six-frame cadence. New/recovering
        // decoders still get checked every frame so their first frame is bound
        // as soon as Android produces it.
        if (video.hasProducedTexture && !pollVideoClock) continue;

        std::int64_t decodedFrame = -1;
        bool const hasOutputTexture = HasDecodedVideoOutput(vp, decodedFrame);
        if (hasOutputTexture) {
          if (!video.hasProducedTexture) {
            // Android can create the external texture after the original
            // output assignment. Rebind exactly when the first real
            // decoded frame appears so the screen cannot retain the black shell.
            EnsureVideoOutputBinding(video);
          }
          video.hasProducedTexture = true;
          if (decodedFrame >= 0 && decodedFrame != video.lastDecodedFrame) {
            video.lastDecodedFrame = decodedFrame;
            video.lastDecodedFrameAdvanceFrame = frame;
          }
        }

        bool const shouldAdvance =
            ShouldVideoAdvance(vp, videoTime, playbackSpeed);
        bool const frameIndexAvailable = decodedFrame >= 0 && video.lastDecodedFrame >= 0;
        bool const decoderStalled =
            frameIndexAvailable && hasOutputTexture && video.hasProducedTexture &&
            shouldAdvance && vp->get_isPlaying() &&
            frame - video.lastDecodedFrameAdvanceFrame >= kVideoStallFrames;
        bool const missingDecodedFrame = !hasOutputTexture;

        // Recover the individual decoder only after MediaCodec has had a full
        // startup window. The previous 8-12 frame loop could repeatedly seek a
        // slow clip before it ever emitted frame 0, while a pause/resume worked
        // simply because it provided a later clean startup attempt.
        if ((missingDecodedFrame || decoderStalled) &&
            frame >= video.outputGraceUntilFrame &&
            frame >= video.nextOutputRecoveryFrame) {
          EnsureVideoOutputBinding(video);
          if (vp->get_isPlaying()) vp->Pause();
          vp->set_time(static_cast<double>(videoTime));
          vp->Play();
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.outputGraceUntilFrame =
              frame + kVideoFirstFrameGraceFrames;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
          video.nextStartRetryFrame = frame + 30;
          video.nextDriftCorrectionFrame =
              frame + kVideoDriftCorrectionCooldownFrames;
          VIVIFY_DEBUG("Vivify sync: persistent decoder {} at songTime={}; applying local pause/seek/play recovery",
                       decoderStalled ? "stalled" : "has no decoded frame",
                       songTime);
          continue;
        }

        if (!pollVideoClock) continue;
        if (!vp->get_isPlaying()) {
          if (shouldAdvance && frame >= video.nextStartRetryFrame) {
            vp->set_time(static_cast<double>(videoTime));
            vp->Play();
            video.hasProducedTexture = false;
            video.lastDecodedFrame = -1;
            video.lastDecodedFrameAdvanceFrame = frame;
            video.outputGraceUntilFrame =
                frame + kVideoFirstFrameGraceFrames;
            video.nextStartRetryFrame = frame + 30;
            video.nextOutputRecoveryFrame =
                frame + kVideoRecoveryBackoffFrames;
            video.nextDriftCorrectionFrame =
                frame + kVideoDriftCorrectionCooldownFrames;
          }
          continue;
        }
        float const drift = static_cast<float>(vp->get_time()) - videoTime;
        if (frameIndexAvailable && std::isfinite(drift) &&
            std::abs(drift) > kVideoDriftToleranceSeconds &&
            frame >= video.nextDriftCorrectionFrame) {
          vp->set_time(static_cast<double>(videoTime));
          video.lastDecodedFrameAdvanceFrame = frame;
          video.outputGraceUntilFrame =
              frame + kVideoFirstFrameGraceFrames;
          video.nextDriftCorrectionFrame =
              frame + kVideoDriftCorrectionCooldownFrames;
        }
        if (heartbeat) {
          PaperLogger.info("Vivify sync heartbeat: persistent videoTime={} target={} drift={} songTime={} prepared={} playing={} texture={} targetVisible={}",
                           static_cast<float>(vp->get_time()), videoTime, drift, songTime,
                           vp->get_isPrepared(), vp->get_isPlaying(),
                           hasOutputTexture, targetRenderable);
        }
        continue;
      }

      // MaterialOverride output can be detached when either the VideoPlayer's
      // GameObject or its target renderer is disabled and later re-enabled by
      // an Animator. That is the section-to-section failure seen on Quest: the
      // decoder remains prepared but the screen is black until a pause/resume.
      bool componentActive = false;
      auto videoObject = vp->get_gameObject();
      auto* videoObjectPtr = videoObject.unsafePtr();
      if (IsAlive(videoObjectPtr)) {
        componentActive = videoObjectPtr->get_activeInHierarchy() && vp->get_enabled();
      }

      bool const targetRenderable = IsVideoOutputRenderable(video);

      bool const renderable = componentActive && targetRenderable;
      if (!renderable) {
        if (video.wasRenderable) {
          VIVIFY_DEBUG("Vivify sync: video target became inactive; arming reactivation kick");
        }
        video.wasRenderable = false;
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        continue;
      }

      if (!video.playbackTimelineStarted) {
        video.playbackTimelineStarted = true;
        video.authoredPlaybackActive = true;
        video.playbackElapsedBeforePause = 0.0f;
        video.activeSegmentStartSongTime = synced.startTime;
      }
      float const rawVideoTime =
          video.playbackElapsedBeforePause +
          std::max(0.0f, songTime - video.activeSegmentStartSongTime);
      float const videoTime = NormalizeVideoTime(vp, rawVideoTime);

      if (!video.wasRenderable) {
        // Rebind on the exact transition back to a visible/active screen. This
        // replaces the manual pause/resume users previously needed between
        // authored video sections without restarting already healthy videos.
        video.wasRenderable = true;
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.nextStartRetryFrame = frame;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
      }

      if (timelineJumped) {
        video.needsStartupKick = true;
        video.hasProducedTexture = false;
        video.nextStartRetryFrame = frame;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
      }

      if (video.needsStartupKick) {
        // Re-assigning the same target is intentional: on Android this
        // recreates the output binding after an inactive->active transition.
        EnsureVideoOutputBinding(video);
        if (vp->get_isPlaying()) vp->Pause();
        vp->set_time(static_cast<double>(videoTime));
        vp->Play();
        video.needsStartupKick = false;
        video.hasProducedTexture = false;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame =
            frame + kVideoFirstFrameGraceFrames;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
        video.nextStartRetryFrame = frame + 30;
        video.nextDriftCorrectionFrame =
            frame + kVideoDriftCorrectionCooldownFrames;
        synced.nextVideoClockPollFrame = frame + 2;
        VIVIFY_DEBUG("Vivify sync: video activation/start kick (songTime={} videoTime={})",
                     songTime, videoTime);
        continue;
      }

      // As above, keep native decoder-health polling cheap once output is
      // established, while sampling startup/recovery on every frame.
      if (video.hasProducedTexture && !pollVideoClock) continue;

      // A valid external texture with dimensions is enough to prove output on
      // Quest. Some hardware decoders never expose a usable frame index; only
      // run frame-stall/drift logic when that optional telemetry exists.
      std::int64_t decodedFrame = -1;
      bool const hasOutputTexture = HasDecodedVideoOutput(vp, decodedFrame);
      if (hasOutputTexture && !video.hasProducedTexture) {
        // First decoded frame is now real. Re-assert the output once at this
        // transition so its target receives the newly-created external
        // texture even on drivers that ignored the pre-frame binding.
        EnsureVideoOutputBinding(video);
        video.hasProducedTexture = true;
      }
      if (hasOutputTexture && decodedFrame >= 0 &&
          decodedFrame != video.lastDecodedFrame) {
        video.lastDecodedFrame = decodedFrame;
        video.lastDecodedFrameAdvanceFrame = frame;
      }

      bool const shouldAdvance =
          ShouldVideoAdvance(vp, videoTime, playbackSpeed);
      bool const frameIndexAvailable = decodedFrame >= 0 && video.lastDecodedFrame >= 0;
      bool const decoderStalled =
          frameIndexAvailable && hasOutputTexture && video.hasProducedTexture &&
          shouldAdvance && vp->get_isPlaying() &&
          frame - video.lastDecodedFrameAdvanceFrame >= kVideoStallFrames;

      if ((!hasOutputTexture || decoderStalled) &&
          frame >= video.outputGraceUntilFrame &&
          frame >= video.nextOutputRecoveryFrame) {
        EnsureVideoOutputBinding(video);
        if (vp->get_isPlaying()) vp->Pause();
        vp->set_time(static_cast<double>(videoTime));
        vp->Play();
        video.hasProducedTexture = false;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame =
            frame + kVideoFirstFrameGraceFrames;
        video.nextOutputRecoveryFrame =
            frame + kVideoRecoveryBackoffFrames;
        video.nextStartRetryFrame = frame + 30;
        video.nextDriftCorrectionFrame =
            frame + kVideoDriftCorrectionCooldownFrames;
        synced.nextVideoClockPollFrame = frame + 2;
        VIVIFY_DEBUG("Vivify sync: recovering {} video output (songTime={} videoTime={})",
                     decoderStalled ? "stalled" : "black", songTime,
                     videoTime);
        continue;
      }

      if (!pollVideoClock) continue;
      if (!vp->get_isPlaying()) {
        if (shouldAdvance && frame >= video.nextStartRetryFrame) {
          vp->set_time(static_cast<double>(videoTime));
          vp->Play();
          video.hasProducedTexture = false;
          video.lastDecodedFrame = -1;
          video.lastDecodedFrameAdvanceFrame = frame;
          video.outputGraceUntilFrame =
              frame + kVideoFirstFrameGraceFrames;
          video.nextStartRetryFrame = frame + 30;
          video.nextOutputRecoveryFrame =
              frame + kVideoRecoveryBackoffFrames;
          video.nextDriftCorrectionFrame =
              frame + kVideoDriftCorrectionCooldownFrames;
          VIVIFY_DEBUG("Vivify sync: retrying prepared video start (songTime={} videoTime={})",
                       songTime, videoTime);
        }
        continue;
      }

      float const drift = static_cast<float>(vp->get_time()) - videoTime;
      if (frameIndexAvailable && std::isfinite(drift) &&
          std::abs(drift) > kVideoDriftToleranceSeconds &&
          frame >= video.nextDriftCorrectionFrame) {
        vp->set_time(static_cast<double>(videoTime));
        video.lastDecodedFrameAdvanceFrame = frame;
        video.outputGraceUntilFrame =
            frame + kVideoFirstFrameGraceFrames;
        video.nextDriftCorrectionFrame =
            frame + kVideoDriftCorrectionCooldownFrames;
      }
      if (heartbeat) {
        PaperLogger.info("Vivify sync heartbeat: videoTime={} target={} songTime={} startTime={} drift={} speed={} prepared={} playing={} renderable={} texture={}",
                         static_cast<float>(vp->get_time()), videoTime, songTime, synced.startTime,
                         drift, playbackSpeed, vp->get_isPrepared(), vp->get_isPlaying(),
                         renderable, hasOutputTexture);
      }
    }
  }
}

bool Runtime::IsReduceDebrisEnabled() {

  if (!_reduceDebrisCached) {
    _reduceDebrisCached = true;
    _reduceDebris = false;
    auto* playerDataModel = UnityEngine::Object::FindObjectOfType<GlobalNamespace::PlayerDataModel*>();
    if (IsManagedAlive(playerDataModel)) {
      auto* playerData = playerDataModel->get_playerData();
      if (playerData != nullptr) {
        auto* settings = playerData->get_playerSpecificSettings();
        if (settings != nullptr) {
          _reduceDebris = settings->get_reduceDebris();
        }
      }
    }
    VIVIFY_DEBUG("Vivify: Reduce Debris player option = {} (custom debris {})", _reduceDebris,
                 _reduceDebris ? "disabled" : "enabled");
  }
  return _reduceDebris;
}

bool Runtime::IsLeftHanded() {
  if (_leftHandedCached) return _leftHanded;

  _leftHandedCached = true;
  _leftHanded = false;
  auto* playerDataModel = UnityEngine::Object::FindObjectOfType<GlobalNamespace::PlayerDataModel*>();
  if (IsAlive(playerDataModel)) {
    auto* playerData = playerDataModel->get_playerData();
    if (playerData != nullptr) {
      auto* settings = playerData->get_playerSpecificSettings();
      if (settings != nullptr) _leftHanded = settings->get_leftHanded();
    }
  }
  VIVIFY_DEBUG("Vivify prefab mirroring: left-handed mode={}", BoolText(_leftHanded));
  return _leftHanded;
}

UnityEngine::Transform* Runtime::EnsureMirroredPrefabParent() {
  if (!IsLeftHanded()) return nullptr;
  if (!IsAlive(_mirroredPrefabParent)) {
    _mirroredPrefabParent = UnityEngine::GameObject::New_ctor(u"VivifyLeftHandPrefabParent");
    if (!IsAlive(_mirroredPrefabParent)) return nullptr;
    _mirroredPrefabParent->get_transform()->set_localScale(UnityEngine::Vector3(-1.0f, 1.0f, 1.0f));
  }
  return _mirroredPrefabParent->get_transform().unsafePtr();
}

void Runtime::SetPauseMenuActive(bool active) {
  _pauseMenuRequested = active;
  ApplyPauseState();
}

void Runtime::SetApplicationPaused(bool paused) {
  _applicationPaused = paused;
  ApplyPauseState();
}

void Runtime::SetApplicationFocused(bool focused) {
  _applicationFocused = focused;
  ApplyPauseState();
}

void Runtime::ApplyPauseState() {
  bool const active = _pauseMenuRequested || _applicationPaused || !_applicationFocused;
  if (_currentBeatmapData == nullptr) {
    _pauseMenuActive = false;
    return;
  }
  if (_pauseMenuActive == active) return;
  _pauseMenuActive = active;
  VIVIFY_DEBUG("Vivify suspension {}: menu={} applicationPaused={} applicationFocused={} syncedObjects={} secondaryCameras={}",
               active ? "entered" : "left", _pauseMenuRequested, _applicationPaused,
               _applicationFocused, _syncedObjects.size(), _secondaryCameras.size());
  if (active) {
    // Suspend Unity-driven prefab time immediately. Runtime::Update stops as
    // soon as the lifecycle is suspended, so deferring this to
    // UpdatePrefabAnimationSpeed lets Animator and ParticleSystem components
    // keep advancing behind the pause or Quest system menu.
    for (auto& synced : _syncedObjects) {
      for (auto* animator : synced.animators) {
        if (IsManagedAlive(animator)) animator->set_speed(0.0f);
      }
      for (auto* animation : synced.legacyAnimations) {
        SetLegacyAnimationSpeed(animation, 0.0f);
      }
      for (auto& particleSystem : synced.particleSystems) {
        SetParticleClockSuppressed(particleSystem, true);
      }
      for (auto& video : synced.videoPlayers) {
        auto* vp = video.player;
        if (IsManagedAlive(vp) && vp->get_isPlaying()) vp->Pause();
        video.needsStartupKick = true;
      }
    }
    _lastAppliedSyncSpeed = 0.0f;

    _lifecycle.Suspend();

    if (_cameraApplier != nullptr && UnityEngine::Object::op_Implicit_bool(_cameraApplier)) {
      _cameraApplier->set_enabled(false);
    }
    // A secondary camera can be disabled intentionally (for example when it
    // has no color/depth target). Remember that state exactly; blindly enabling
    // every camera on resume can render an un-targeted helper into the headset.
    RestoreSecondaryCullingLayers();
    RemoveMidRenderCommandBuffers();
    for (auto& [name, cam] : _secondaryCameras) {
      cam.enabledBeforePause = IsAlive(cam.camera) && cam.camera->get_enabled();
      if (IsAlive(cam.camera)) cam.camera->set_enabled(false);
    }

    RestoreGlobalProperties();

    // Keep authored render and QualitySettings values alive through the pause
    // menu. Restoring antiAliasing here and reapplying it immediately after an
    // Android XR resume can recreate the eye render targets while OpenXR is
    // reattaching its swapchain. The captured XR-resume freeze stopped on exactly
    // that resume path. Desktop Vivify also keeps these values until runtime
    // disposal, so teardown/restart remains the only place that restores them.
    VIVIFY_DEBUG("Vivify pause: preserving {} authored render setting(s) across XR suspend",
                 _currentRenderSettings.size());

    _pausedMaterialAnimations = std::move(_materialAnimations);
    _pausedGlobalAnimations = std::move(_globalAnimations);
    _pausedAnimatorAnimations = std::move(_animatorAnimations);
    _pausedRenderSettingAnimations = std::move(_renderSettingAnimations);
    _materialAnimations.clear();
    _globalAnimations.clear();
    _animatorAnimations.clear();
    _renderSettingAnimations.clear();
  } else {
    for (auto& [name, cam] : _secondaryCameras) {
      if (IsAlive(cam.camera)) cam.camera->set_enabled(cam.enabledBeforePause);
      cam.enabledBeforePause = false;
    }
    VIVIFY_DEBUG("Vivify resume checkpoint: secondary cameras restored");

    ReapplyCurrentGlobalProperties();
    VIVIFY_DEBUG("Vivify resume checkpoint: global shader state restored; authored render settings preserved");
    _materialAnimations = std::move(_pausedMaterialAnimations);
    _globalAnimations = std::move(_pausedGlobalAnimations);
    _animatorAnimations = std::move(_pausedAnimatorAnimations);
    _renderSettingAnimations = std::move(_pausedRenderSettingAnimations);
    _pausedMaterialAnimations.clear();
    _pausedGlobalAnimations.clear();
    _pausedAnimatorAnimations.clear();
    _pausedRenderSettingAnimations.clear();
    VIVIFY_DEBUG("Vivify resume checkpoint: authored animations restored");

    float resumeSpeed = 0.0f;
    if (IsManagedAlive(_audioTimeSyncController)) {
      float const authoredSpeed = _audioTimeSyncController->get_timeScale();
      if (std::isfinite(authoredSpeed) && authoredSpeed > 0.0f) resumeSpeed = authoredSpeed;
    }
    for (auto& synced : _syncedObjects) {
      for (auto* animator : synced.animators) {
        if (IsManagedAlive(animator)) animator->set_speed(resumeSpeed);
      }
      for (auto* animation : synced.legacyAnimations) {
        SetLegacyAnimationSpeed(animation, resumeSpeed);
      }
      for (auto& particleSystem : synced.particleSystems) {
        SetParticleClockSuppressed(particleSystem, resumeSpeed <= 0.0f);
      }
      for (auto& video : synced.videoPlayers) {
        video.needsStartupKick = true;
        video.nextStartRetryFrame = 0;
        video.wasRenderable = false;
        video.hasProducedTexture = false;
        video.outputGraceUntilFrame = 0;
        video.nextOutputRecoveryFrame = 0;
        video.lastDecodedFrame = -1;
        video.lastDecodedFrameAdvanceFrame = 0;
        video.nextDriftCorrectionFrame = 0;
      }
      synced.nextVideoClockPollFrame = 0;
    }

    _lifecycle.Resume();
    // Force a fresh callback-clock sample and reapply the practice speed on
    // the first resumed frame. Otherwise a long Android sleep can leave
    // Animator/ParticleSystem components at the pause speed of zero.
    _songTimeCacheFrame = -1;
    _lastSyncSongTime = -1.0f;
    _syncClockStallFrames = 0;
    _syncClockHasAdvanced = false;
    _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
    VIVIFY_DEBUG("Vivify resume checkpoint: lifecycle active; refreshing camera components");
    if (!_isResetting) RefreshCameraComponents(true);
    VIVIFY_DEBUG("Vivify resume complete: songTime={} syncedObjects={} secondaryCameras={} renderSettingsPreserved={}",
                 CurrentSongTime(), _syncedObjects.size(), _secondaryCameras.size(),
                 _currentRenderSettings.size());
  }
}

void Runtime::HandleScenesWillDismiss() {
  if (_currentBeatmapData == nullptr && _lifecycle.Phase() == RuntimePhase::Dormant &&
      _activeSabers.empty() && _cameraApplier == nullptr &&
      _secondaryCameras.empty() && _livePrefabs.empty()) {
    return;
  }
  VIVIFY_DEBUG("Vivify retiring gameplay session before scene dismissal");
  ResetRuntime(ResetMode::EarlySceneTransition);
}

void Runtime::HandleGameplayRestart() {
  if (_currentBeatmapData == nullptr || _isResetting) return;
  VIVIFY_DEBUG("Vivify retiring gameplay session before restart");
  ResetRuntime(ResetMode::LiveScene);
}

bool Runtime::IsCameraApplierCurrent(CameraApplier* applier) const {
  if (!IsAlive(applier) || applier != _cameraApplier ||
      !_lifecycle.CanRender(applier->sessionGeneration)) {
    return false;
  }
  auto gameObject = applier->get_gameObject();
  return IsAlive(gameObject.unsafePtr()) && gameObject.unsafePtr() == _cameraApplierGO;
}

bool Runtime::BeginCameraRender(CameraApplier* applier) {
  return IsCameraApplierCurrent(applier) &&
         _lifecycle.TryEnterRender(applier->sessionGeneration);
}

void Runtime::EndCameraRender(CameraApplier* applier) {
  (void)applier;
  _lifecycle.LeaveRender();
  FinishPendingReset();
}

bool Runtime::ShouldSuppressOriginalImageEffect(
    GlobalNamespace::ImageEffectController* controller) const {
  return IsAlive(controller) && IsCameraApplierCurrent(_cameraApplier) &&
         _cameraApplier->get_enabled() && _cameraApplier->hasMainEffect &&
         _cameraApplier->imageEffectController == controller;
}

void Runtime::OnCameraApplierDestroyed(CameraApplier* applier) {
  RemoveMidRenderCommandBuffers(applier);
  if (_cameraApplier != applier) return;
  _cameraApplier = nullptr;
  _cameraApplierGO = nullptr;
}

void Runtime::RefreshMultipassRendering() {
  auto mainCam = UnityEngine::Camera::get_main();
  auto mainCamGO = IsAlive(mainCam.unsafePtr()) ? mainCam->get_gameObject().unsafePtr() : nullptr;
  RefreshMultipassRendering(mainCamGO);
  RefreshLoadedMaterialStereoKeywords();
}

void Runtime::RefreshIsolationSettings() {
  if (GetDisableAllBlits()) {
    if ((!_preEffects.empty() || !_postEffects.empty() || HasMidRenderEffects()) && GetVivifyDebugLogging()) {
      PaperLogger.info("Vivify isolation: clearing active blits (Blit effects disabled) pre={} post={}",
                       _preEffects.size(), _postEffects.size());
    }
    _preEffects.clear();
    _postEffects.clear();
    for (auto& bucket : _midEffects) bucket.clear();
    DestroyCameraApplier();
    ReleaseMidRenderTextures();
    ReleaseCachedBlitTextures();
  } else if (GetDisableBeat0FilmgrainBlit()) {
    UpdateBlitEffects();
  }

  if (GetDisableCreateCameraDepth()) {
    if (!_secondaryCameras.empty() && GetVivifyDebugLogging()) {
      PaperLogger.info("Vivify isolation: releasing secondary cameras count={}", _secondaryCameras.size());
    }
    for (auto& [name, camera] : _secondaryCameras) {
      ReleaseSecondaryCameraData(camera);
    }
    _secondaryCameras.clear();
    for (auto it = _cameraProperties.begin(); it != _cameraProperties.end();) {
      if (it->first != kMainCameraId) {
        it = _cameraProperties.erase(it);
      } else {
        it++;
      }
    }
  } else {
    // Re-apply stored secondary-camera properties after an isolation setting
    // changes. The culling controller owns temporary layer restoration.
    for (auto& [name, camera] : _secondaryCameras) {
      if (!IsAlive(camera.camera)) continue;
      ApplySecondaryCameraProperties(camera);
      ApplyCameraGameObjectProperties(camera.camera, camera.properties);
    }
  }

  RefreshCameraComponents(_currentBeatmapData != nullptr && !_isResetting && !_pauseMenuActive);
}

void Runtime::ResetRuntime(ResetMode mode) {
  auto const resetRank = [](ResetMode candidate) {
    switch (candidate) {
      case ResetMode::GameplayPreparation: return 0;
      case ResetMode::LiveScene: return 1;
      case ResetMode::EarlySceneTransition: return 2;
      case ResetMode::LateSceneTransition: return 3;
    }
    return 3;
  };
  auto const resetName = [](ResetMode candidate) -> char const* {
    switch (candidate) {
      case ResetMode::GameplayPreparation: return "gameplay-preparation";
      case ResetMode::LiveScene: return "live-scene";
      case ResetMode::EarlySceneTransition: return "early-transition";
      case ResetMode::LateSceneTransition: return "late-transition";
    }
    return "unknown";
  };

  [[maybe_unused]] auto const retiredGeneration = _lifecycle.BeginRetirement();
  if (_lifecycle.RenderDepth() != 0) {
    if (!_pendingResetMode.has_value() ||
        resetRank(mode) > resetRank(_pendingResetMode.value())) {
      _pendingResetMode = mode;
    }
    _isResetting = true;
    VIVIFY_DEBUG("Vivify deferred {} reset until {} active render scope(s) leave",
                 resetName(mode), _lifecycle.RenderDepth());
    return;
  }

  VIVIFY_DEBUG("Vivify ResetRuntime: mode={} livePrefabs={} preloaded={} synced={} secondaryCameras={} declaredTextures={} assets={}",
               resetName(mode), _livePrefabs.size(), _instantiatePrefabs.size(), _syncedObjects.size(),
               _secondaryCameras.size(), _declaredTextures.size(), _assets.size());
  _isResetting = true;
  bool const canTouchSceneObjects = mode != ResetMode::LateSceneTransition;
  bool const preserveGameplayScene =
      mode == ResetMode::GameplayPreparation || mode == ResetMode::LiveScene;
  bool const preserveBundleVideoWarmups =
      mode == ResetMode::GameplayPreparation;

  if (canTouchSceneObjects) {
    // This path is used while the gameplay scene is still alive (for example a
    // practice-mode backward seek), so authored state can be restored normally.
    DestroyCameraApplier();
    RestoreGlobalProperties();
    RestoreAllVisualReplacements();
    RestoreMainCameraOriginals();

    std::unordered_set<UnityEngine::GameObject*> destroyed;
    for (auto& [id, prefab] : _livePrefabs) {
      if (prefab.gameObject == nullptr) continue;
      for (auto const& track : prefab.tracks) track.UnregisterGameObject(prefab.gameObject);
      if (destroyed.emplace(prefab.gameObject).second && IsAlive(prefab.gameObject)) {
        UnityEngine::Object::Destroy(prefab.gameObject);
      }
    }
    for (auto& [eventData, instantiate] : _instantiatePrefabs) {
      if (instantiate.instance != nullptr && destroyed.emplace(instantiate.instance).second &&
          IsAlive(instantiate.instance)) {
        UnityEngine::Object::Destroy(instantiate.instance);
      }
      instantiate.instance = nullptr;
    }
    if (IsAlive(_mirroredPrefabParent)) {
      UnityEngine::Object::Destroy(_mirroredPrefabParent);
    }

    for (auto& [name, dt] : _declaredTextures) ReleaseDeclaredTextureData(dt);
    for (auto& [name, cam] : _secondaryCameras) ReleaseSecondaryCameraData(cam);
    RemoveMidRenderCommandBuffers();
    ReleaseMidRenderTextures();
    ReleaseCachedBlitTextures();
    RestoreRenderSettings();

    if (IsAlive(_multipassController)) {
      _multipassController->set_enabled(false);
      UnityEngine::Object::Destroy(_multipassController);
    }
  } else {
    // Scene transitions are deliberately pointer-free. Crash tombstones showed
    // stale wrappers reaching RenderTexture::Release, Object::Destroy,
    // Renderer.enabled, and Behaviour.enabled after leaving a song. Only static
    // shader bindings are cleared here; Unity owns destruction of the old scene.
    for (auto const& [name, data] : _declaredTextures) {
      UnityEngine::Shader::SetGlobalTexture(data.propertyId, static_cast<UnityEngine::Texture*>(nullptr));
    }
    for (auto const& [name, data] : _secondaryCameras) {
      if (data.texturePropertyId.has_value()) {
        UnityEngine::Shader::SetGlobalTexture(data.texturePropertyId.value(), static_cast<UnityEngine::Texture*>(nullptr));
      }
      if (data.depthTexturePropertyId.has_value()) {
        UnityEngine::Shader::SetGlobalTexture(data.depthTexturePropertyId.value(), static_cast<UnityEngine::Texture*>(nullptr));
      }
    }
    for (auto const& [propertyId, value] : _currentGlobalProperties) {
      if (std::holds_alternative<UnityEngine::Texture*>(value)) {
        UnityEngine::Shader::SetGlobalTexture(propertyId, static_cast<UnityEngine::Texture*>(nullptr));
      }
    }
    for (auto const& [keyword, enabled] : _savedGlobalKeywords) {
      if (enabled) UnityEngine::Shader::EnableKeyword(StringW(keyword));
      else UnityEngine::Shader::DisableKeyword(StringW(keyword));
    }

    // Do not Dispose/Destroy transition-owned native objects. Clear every raw
    // pointer so the persistent VivifyRuntime behaviour cannot touch them on a
    // later menu frame or when another song is selected.
    _cameraApplier = nullptr;
    _cameraApplierGO = nullptr;
    _multipassController = nullptr;
    _lastMainCameraGO = nullptr;
    _midCommandBufferCamera = nullptr;
    _midCommandBufferOwner = nullptr;
    _activeMidCommandBuffers.clear();
    _midSelfBlitTemps.clear();
    _midRenderCommandCache.Invalidate();
    _midMainRT = nullptr;
    _midScratchRT = nullptr;
    _mainBlitTexture = nullptr;
    _scratchBlitTexture = nullptr;
    ReleaseImageBlitCommandBuffer(false);
    SetMultipassShaderState(false);
    _beatmapCallbacksController = nullptr;
  }

  _livePrefabs.clear();
  _instantiatePrefabs.clear();
  _deferredPrefabPrewarms.clear();
  if (!preserveBundleVideoWarmups) ReleaseBundleVideoWarmups();
  // Persistent video decoder proxies live under VivifyRuntime (DontDestroyOnLoad),
  // not under the gameplay prefab. They must be explicitly retired on every
  // reset or they would survive into the next song with stale renderer targets.
  for (auto& synced : _syncedObjects) ReleaseSyncedVideos(synced, false);
  _syncedObjects.clear();
  _blitMaterialValidCache.clear();
  _warnedInvalidBlitPasses.clear();
  _loggedBlitStereoMaterials.clear();
  _materialAnimations.clear();
  _globalAnimations.clear();
  _animatorAnimations.clear();
  _renderSettingAnimations.clear();
  _pausedMaterialAnimations.clear();
  _pausedGlobalAnimations.clear();
  _pausedAnimatorAnimations.clear();
  _pausedRenderSettingAnimations.clear();
  _savedGlobalProperties.clear();
  _savedGlobalKeywords.clear();
  _currentGlobalProperties.clear();
  _currentGlobalKeywords.clear();
  _repairedMaterials.clear();
  _genericFallbackMaterials.clear();
  _assets.clear();
  _assetsByName.clear();
  _ambiguousAssetAliases.clear();
  _missingAssetKeys.clear();
  _missingInstantiatePrefabAssets.clear();
  _supportedShadersByName.clear();
  _catchUpAppliedCustomEvents.clear();
  _deferredStartupPostProcessingEvents.clear();
  _deferredSaberVisualsUntilFrame = -1;
  _saberVisualRetryUntilFrame = -1;
  _lastSaberIntegrityFrame = -1000;
  _warnedInvalidBeatmapData = false;
  _warnedStartupDescriptorWait = false;
  _postProcessingReadyFrame = -1;
  _nextBeatmapPrepareProbeFrame = 0;
  _nextSyncedObjectPurgeFrame = 0;
  _declaredTextures.clear();
  _secondaryCameras.clear();
  _preEffects.clear();
  _postEffects.clear();
  for (auto& bucket : _midEffects) bucket.clear();
  _midRenderCommandCache.Invalidate();
  _hasMainDescriptor = false;
  _cachedMainVrUsage = -1;
  _savedRenderSettings.clear();
  _currentRenderSettings.clear();
  _assignedPrefabs.clear();
  InvalidateAssignedPrefabLookup();
  _activeDebrisPrefabStack.clear();
  _lastCutDebrisPrefabs.clear();
  if (!preserveGameplayScene) {
    _activeSabers.clear();
    _activeNoteControllers.clear();
  } else {
    // PrepareBeatmap and practice/restart resets run while the same gameplay
    // scene (and SaberModelController objects) are still alive. Erasing this
    // list made AssignObjectPrefab at beat 0 a no-op until pausing/restarting
    // happened to reconstruct the saber hierarchy.
    PurgeInvalidActiveSabers();
    for (auto it = _activeNoteControllers.begin(); it != _activeNoteControllers.end();) {
      if (!IsAlive(*it)) {
        it = _activeNoteControllers.erase(it);
      } else {
        ++it;
      }
    }
  }
  _noteReplacements.clear();
  _saberReplacements.clear();
  _debrisReplacements.clear();
  _cameraProperties.clear();
  _mainCameraPropsDirty = false;
  _mainCamOriginalDepthMode.reset();
  _mainCamOriginalClearFlags.reset();
  _mainCamOriginalBackgroundColor.reset();
  _mirroredPrefabParent = nullptr;

  if (preserveGameplayScene && _mainBundle != nullptr && !UnityEngine::Object::op_Implicit_bool(_mainBundle)) {
    _mainBundle = nullptr;
    _preloadedBundlePath.clear();
  }
  if (!preserveGameplayScene) _beatmapCallbacksController = nullptr;
  _currentBeatmapData = nullptr;
  _beatmapAD = nullptr;
  _audioTimeSyncController = nullptr;
  _lastSongTime = -1.0f;
  _lastSyncSongTime = -1.0f;
  _syncClockStallFrames = 0;
  _syncClockHasAdvanced = false;
  _lastAppliedSyncSpeed = std::numeric_limits<float>::quiet_NaN();
  _lastQuestPerformanceFrame = -1000;
  _midCommandBufferCacheHits = 0;
  _midCommandBufferRebuilds = 0;
  _imageBlitExecutions = 0;
  _imageCommandBufferCreates = 0;
  _noteRefreshEvents = 0;
  _noteRefreshCandidates = 0;
  _assignedPrefabLookupRebuilds = 0;
  _songTimeCacheFrame = -1;
  _songTimeCache = 0.0f;
  _pauseMenuRequested = false;
  _applicationPaused = false;
  _applicationFocused = true;
  _pauseMenuActive = false;
  _reduceDebrisCached = false;
  _reduceDebris = false;
  _leftHandedCached = false;
  _leftHanded = false;
  _preparingGeneration = 0;
  _pendingResetMode.reset();
  [[maybe_unused]] bool const retired = _lifecycle.CompleteRetirement();
  _isResetting = false;
}

void Runtime::FinishPendingReset() {
  if (_lifecycle.RenderDepth() != 0 || !_pendingResetMode.has_value()) return;
  auto const mode = _pendingResetMode.value();
  _pendingResetMode.reset();
  _isResetting = false;
  ResetRuntime(mode);
}

}
