> Commit 106 test build: keeps Commit 105 sync behavior but removes redundant VideoPlayer native-state reads from the hot path. Commit 104 remains reverted; Luminescent ending issues are unchanged.

# Vivify Quest standalone source

This repository contains only the Vivify Quest source and its build files.

## Build on GitHub

1. Upload the contents of this folder to an empty GitHub repository.
2. Commit to `main` (or `master`). The **Build Vivify Quest** action starts automatically.
3. Or open **Actions → Build Vivify Quest → Run workflow**.
4. When **ARM64 QMOD** is green, download the `Vivify-Quest-0.6.14` artifact.
5. Extract the artifact ZIP to get `Vivify-Quest-0.6.14.qmod`.

The workflow builds only Vivify. It does not build or validate Noodle Extensions, Nexora, AudioLink, TimelinePreview, or the original monorepo projects.
