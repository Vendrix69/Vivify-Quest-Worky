# Vivify Quest 0.6.14 — Clean Baseline

This source tree is a reset to a small, testable foundation after several video experiments interacted badly.

The video implementation is Commit 103. Only already-proven non-video fixes are layered on top: Luminescent's per-eye sampler2D compatibility fix and restart/material-state hygiene.

The purpose of this build is stability and reproducibility. Do not treat it as a new attempt to solve every remaining visual/video issue at once.

Known remaining items to test/fix separately:
- 3 Big Shots: 200% random-timeline catch-up speed.
- Heartbeat: verify Commit 103 behavior still reproduces with the retained reset fixes.
- Luminescent: short blackout during the Glitch/Pixelate handoff remains.
