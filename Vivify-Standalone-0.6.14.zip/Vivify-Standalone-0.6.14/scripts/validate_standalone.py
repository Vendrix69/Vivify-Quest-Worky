#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def text(rel):
    return (ROOT / rel).read_text(errors='replace')

def require(cond, message):
    if not cond:
        print(f'FAIL: {message}', file=sys.stderr)
        raise SystemExit(1)
    print(f'PASS: {message}')

obj = text('src/VivifyObjectPrefabs.cpp')
comp = text('src/VivifyComponents.cpp')
hooks = text('src/VivifyHooks.cpp')
core = text('src/VivifyCore.cpp')
perf = text('include/VivifyQuestPerformance.hpp')
post = text('src/VivifyPostProcessing.cpp')
main = text('src/main.cpp')

# No old one-root saber field/call remains.
require('target.parent' not in obj, 'no stale ActiveSaberVisual::parent call sites')
require('replacementParent' in obj and 'visualRoot' in obj,
        'saber replacement and original/custom visual roots are separated')
require('RefreshSaberRoots' in obj,
        'saber roots are refreshed after external custom-saber hierarchy rebuilds')
require('frame + 8' in obj and 'frame + 300' in obj,
        'Quest saber replacement waits for custom-saber construction and retries')
require('preexistingSaberRenderers' in obj and 'GetComponentsInChildren<UnityEngine::Renderer*>(true)' in obj,
        'non-additive Vivify saber snapshots sibling custom-saber renderers')
require('DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in obj and
        'DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in text('include/VivifyRuntimeInternal.hpp'),
        'snapshot vector has a matching DisableOriginalRenderers overload')
require('hideOriginalTrails' in obj and 'OwnsSaberTrail(trail)' in obj,
        'trail-only replacement hides external trails without claiming their lifecycle')

# CustomModels 1.2.1 collision + geometry safety.
require('VivifyTrailRendererPrefab' in comp,
        'Vivify trail clone avoids CustomModels Trail(Clone) Awake name hook')
require('SaberMovementData::New_ctor()' in comp and 'AddNewData' in comp and
        'TransformPoint(_topPos)' in comp and 'TransformPoint(_bottomPos)' in comp,
        'Vivify trail owns world-space movement samples instead of following CustomModels/stock trail data')
require('SetParent(nullptr, true)' in comp,
        'Vivify SaberTrailRenderer is world-rooted to avoid double saber transforms')
require('GetPropertyBlock(block)' in comp and 'SetPropertyBlock(block)' in comp,
        'trail color update merges existing MaterialPropertyBlock state')
require('VivifyOwnsSaberTrailLifecycle' in hooks and 'VivifyOwnsSaberTrailRendererLifecycle' in hooks,
        'SaberTrail enable/disable hooks are ownership scoped')

# Aether/practice regression: short callback-clock duplicates are tolerated,
# while sustained practice pre-roll stalls freeze the exact catch-up pose.
require('ClockGatedSyncRate' in perf and 'consecutiveStallFrames' in perf and
        'stallThresholdFrames = 4' in perf,
        'prefab sync distinguishes short Quest scheduler duplicates from sustained song-clock stalls')
require('_syncClockStallFrames' in core and '_syncClockHasAdvanced' in core and
        'ClockGatedSyncRate(' in core,
        'runtime carries song-clock stall state across synchronized prefab updates')
require('animators[i]->set_speed(initialSyncSpeed);' in core and
        'main.set_simulationSpeed(initialSyncSpeed);' in core,
        'practice catch-up pose is frozen immediately until the authoritative song clock advances')
require('NotePrefabTimelineStart' not in obj and 'noteTimelineStart' not in obj and
        'InstantiateReplacementPrefab(*info, replacementParent, replacement);' in obj,
        'note replacements never feed beat-domain NoteFloorMovement time into second-domain prefab sync')
require('AnimatorCullingMode::AlwaysAnimate' in core,
        'Vivify synced prefabs keep authored animation running when renderer visibility changes')

# Video proxy remains in this build.
require('VivifyVideoDecoder' in core and 'persistentDecoder' in core,
        'persistent video decoder proxy fix preserved')

# Flux/map-specific compatibility hacks remain removed.
combined = '\n'.join(text(p) for p in [
    'src/VivifyObjectPrefabs.cpp', 'src/VivifyCore.cpp', 'src/VivifyPostProcessing.cpp',
    'src/VivifyComponents.cpp', 'src/VivifyHooks.cpp'])
for forbidden in ['AlwaysVisibleQuad', 'ForceGameObjectRenderersOnTop', 'ForceRendererOnTop', '42 Flux']:
    require(forbidden not in combined, f'map-specific override absent: {forbidden}')

# XR shader variant ownership. Unity selects Multiview/SPI to match the actual
# camera render pass. Mutating those keywords on a shared Material corrupts both
# screen-space effects and geometry shaders, and makes normal gameplay differ
# from Zen when note-replacement material repair touches shared materials.
assets = text('src/VivifyAssets.cpp')
geometry = text('src/VivifyGeometry.cpp')
stereo_start = assets.find('void Runtime::ApplyStereoKeywords')
stereo_end = assets.find('void Runtime::ApplyGameObjectStereoKeywords', stereo_start)
stereo_body = assets[stereo_start:stereo_end]
for forbidden_write in [
    'SetMaterialKeyword(material, u"STEREO_INSTANCING_ON"',
    'SetMaterialKeyword(material, u"STEREO_MULTIVIEW_ON"',
    'SetMaterialKeyword(material, u"UNITY_SINGLE_PASS_STEREO"',
    'NeedsStereoInstancingCompatibility(shaderName)',
    'forcing instanced eye routing',
]:
    require(forbidden_write not in stereo_body,
            f'ApplyStereoKeywords leaves Unity XR variant state untouched: {forbidden_write}')
require('SetMaterialKeyword(material, u"MULTIPASS_ENABLED", GetMultipassRenderingEnabled())' in stereo_body,
        'ApplyStereoKeywords only owns Vivify legacy MULTIPASS_ENABLED compatibility')
require('NeedsStereoInstancingCompatibility' not in assets and
        'NeedsStereoInstancingCompatibility' not in geometry and
        'NeedsStereoInstancingCompatibility' not in text('include/VivifyGeometry.hpp'),
        'fake Wireframe instanced-stereo keyword recipe removed')
require('wireframe' in geometry.lower() and 'triangleexplosion' in geometry.lower(),
        'Wireframe and TriangleExplosion remain recognized as geometry-shader families for diagnostics')
require('Force per-eye blits (experimental)' not in main and 'GetForcePerEyeBlits' not in post,
        'misleading global per-eye blit toggle removed')
require('_StereoActiveEye' in post and '_VivifyPerEyeBlit' in post,
        'authored fullscreen per-eye blit support remains')

# SaberTrail owner follows the physical Saber while its renderer consumes
# world-space movement at world root, matching CustomModels' proven setup.
obj = text('src/VivifyObjectPrefabs.cpp')
require('trailObject->get_transform()->SetParent(replacementParent, false)' in obj and
        'InitFollowed(sourceTrail, replacementParent' in obj,
        'Vivify followed trail owner stays on the physical Saber root')
require('frame - _lastSaberIntegrityFrame >= 4' in obj,
        'late CustomModels rebuilds are suppressed quickly')
require('target.saber == saber || target.controller == smc' in obj,
        'custom saber controllers are deduplicated per physical Saber')
require('collectForeignTrails(visualRoot)' in obj and 'collectForeignTrails(replacementParent)' in obj,
        'CustomModels trails are discovered across both saber hierarchy roots')

# Skybox repair must stay inside a Skybox/* shader family.
require('Skybox/Panoramic' in assets and 'context == "skybox"' in assets,
        'unsupported skybox materials use a skybox-compatible fallback')
props = text('src/VivifyProperties.cpp')
require('_vivifySkyboxOverrideActive' not in props and
        'set_clearFlags(UnityEngine::CameraClearFlags::Skybox)' not in props,
        'SetRenderingSettings.skybox does not implicitly override camera clear mode')
require('ReadCameraPropertyValue' in post and '"_" + std::string(key)' in post,
        'SetCameraProperty accepts documented and legacy underscore field names')
require('ReadCameraBackgroundColor' in post and 'value.Size() == 1' in post,
        'camera background parser accepts flat RGBA and one-color nested form')
require('props->second.clearFlags.has_value()' in post and
        'props->second.backgroundColor.has_value()' in post and
        'mainCamPtr->set_backgroundColor(*props->second.backgroundColor)' in post,
        'authored main-camera clear/background values are reasserted during gameplay')
require('ApplyCameraProperties(mainCamPtr, props->second);' not in
        post[post.find('void Runtime::RefreshCameraComponents'):post.find('void Runtime::RefreshMultipassRendering')],
        'camera refresh reasserts only authored fields instead of resetting unrelated camera state')

# Flux / Multiview transport. Quest's main XR target is a two-slice array; a
# plain camera-boundary Blit can preserve only the active eye. Keep both slices
# with CopyTexture at the CurrentActive/CameraTarget boundaries.
mid_start = post.find('Runtime::BuildMidRenderCommandBuffer(')
mid_end = post.find('std::size_t Runtime::ComputeMidRenderSignature', mid_start)
mid_body = post[mid_start:mid_end]
require('cb->CopyTexture(srcId, ToTargetId(_midMainRT))' in mid_body and
        'cb->CopyTexture(ToTargetId(mainCurrent), dstId)' in mid_body,
        'mid-render Multiview boundaries preserve both XR texture-array slices')
apply_start = post.find('void Runtime::ApplyBlits(')
apply_end = post.find('void Runtime::CacheMainRenderDescriptor', apply_start)
apply_body = post[apply_start:apply_end]
require('UsesTextureArrayStereo() && IsTextureArray(mainCurrent->get_descriptor())' in apply_body and
        'cb->CopyTexture(ToTargetId(mainCurrent), destId);' in apply_body,
        'OnRenderImage presentation preserves both slices when CameraTarget is Multiview')

# Secondary-camera outputs must follow the XR consumer contract rather than the
# incidental source layout. Targetless Quest helper cameras can surface mono
# OnRenderImage/depth textures while authored Flux shaders consume sampler2DArray.
capture_start = post.find('void Runtime::CaptureSecondaryCameraFrame(')
capture_end = post.find('void Runtime::BindSecondaryCameraTextures()', capture_start)
capture_body = post[capture_start:capture_end]
require('bool const stereoArrayCapture = UsesTextureArrayStereo();' in capture_body and
        'ConfigureStereoRenderTextureDescriptor(srcDesc, stereoArrayCapture);' in capture_body,
        'secondary color capture publishes a stereo array whenever XR is Multiview/SPI')
require('bool const stereoDepthCapture = UsesTextureArrayStereo();' in capture_body and
        'ConfigureStereoRenderTextureDescriptor(depthDesc, stereoDepthCapture);' in capture_body,
        'secondary depth capture matches the stereo color layout')
require('Graphics::CopyTexture(source, 0, 0, destination, 0, 0)' in post and
        'Graphics::CopyTexture(source, 0, 0, destination, 1, 0)' in post,
        'mono secondary captures are duplicated into both published array slices')
secondary_start = comp.find('void SecondaryCameraController::OnPreCull()')
secondary_end = comp.find('void SecondaryCameraController::OnPostRender()', secondary_start)
secondary_precull = comp[secondary_start:secondary_end]
require('Runtime::Instance().RestoreSecondaryCullingLayers();' in secondary_precull and
        secondary_precull.find('RestoreSecondaryCullingLayers') < secondary_precull.find('CullingPreCull'),
        'each secondary camera restores stale culling-layer mutations before applying its own')

print('ALL STATIC VIVIFY CHECKS PASSED')
