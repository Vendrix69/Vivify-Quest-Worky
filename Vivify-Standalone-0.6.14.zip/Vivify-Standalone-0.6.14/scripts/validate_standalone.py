#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def text(rel):
    return (ROOT / rel).read_text(errors='replace')

def require(cond, message):
    if not cond:
        print(f'FAIL: {message}', file=sys.stderr)
        raise SystemExit(1)
    print(f'PASS: {message}')

obj = text('src/VivifyObjectPrefabs.cpp')
comp = text('src/VivifyComponents.cpp')
hooks = text('src/VivifyHooks.cpp')
core = text('src/VivifyCore.cpp')
perf = text('include/VivifyQuestPerformance.hpp')
post = text('src/VivifyPostProcessing.cpp')
main = text('src/main.cpp')

# No old one-root saber field/call remains.
require('target.parent' not in obj, 'no stale ActiveSaberVisual::parent call sites')
require('replacementParent' in obj and 'visualRoot' in obj,
        'saber replacement and original/custom visual roots are separated')
require('RefreshSaberRoots' in obj,
        'saber roots are refreshed after external custom-saber hierarchy rebuilds')
require('frame + 8' in obj and 'frame + 300' in obj,
        'Quest saber replacement waits for custom-saber construction and retries')
require('preexistingSaberRenderers' in obj and 'GetComponentsInChildren<UnityEngine::Renderer*>(true)' in obj,
        'non-additive Vivify saber snapshots sibling custom-saber renderers')
require('DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in obj and
        'DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in text('include/VivifyRuntimeInternal.hpp'),
        'snapshot vector has a matching DisableOriginalRenderers overload')
require('hideOriginalTrails' in obj and 'OwnsSaberTrail(trail)' in obj,
        'trail-only replacement hides external trails without claiming their lifecycle')

# CustomModels 1.2.1 collision + geometry safety.
require('VivifyTrailRendererPrefab' in comp,
        'Vivify trail clone avoids CustomModels Trail(Clone) Awake name hook')
require('SaberMovementData::New_ctor()' in comp and 'AddNewData' in comp and
        'TransformPoint(_topPos)' in comp and 'TransformPoint(_bottomPos)' in comp,
        'Vivify trail owns world-space movement samples instead of following CustomModels/stock trail data')
require('SetParent(nullptr, true)' in comp,
        'Vivify SaberTrailRenderer is world-rooted to avoid double saber transforms')
require('GetPropertyBlock(block)' in comp and 'SetPropertyBlock(block)' in comp,
        'trail color update merges existing MaterialPropertyBlock state')
require('VivifyOwnsSaberTrailLifecycle' in hooks and 'VivifyOwnsSaberTrailRendererLifecycle' in hooks,
        'SaberTrail enable/disable hooks are ownership scoped')

# Aether/practice regression: short callback-clock duplicates are tolerated,
# while sustained practice pre-roll stalls freeze the exact catch-up pose.
require('ClockGatedSyncRate' in perf and 'consecutiveStallFrames' in perf and
        'stallThresholdFrames = 4' in perf,
        'prefab sync distinguishes short Quest scheduler duplicates from sustained song-clock stalls')
require('_syncClockStallFrames' in core and '_syncClockHasAdvanced' in core and
        'ClockGatedSyncRate(' in core,
        'runtime carries song-clock stall state across synchronized prefab updates')
require('animators[i]->set_speed(initialSyncSpeed);' in core and
        'SetParticleClockSuppressed(syncedParticle, initialSyncSpeed <= 0.0f);' in core,
        'practice catch-up pose is frozen immediately until the authoritative song clock advances')
require('struct SyncedParticleSystem' in text('include/VivifyTypes.hpp') and
        'authoredSimulationSpeed' in core and 'clockSuppressed' in core and
        'main.set_simulationSpeed(speed);' not in core,
        'particle clock gating preserves Animator-authored simulationSpeed curves')
require('NotePrefabTimelineStart' not in obj and 'noteTimelineStart' not in obj and
        'InstantiateReplacementPrefab(*info, replacementParent, replacement);' in obj,
        'note replacements never feed beat-domain NoteFloorMovement time into second-domain prefab sync')
require('AnimatorCullingMode::AlwaysAnimate' in core,
        'Vivify synced prefabs keep authored animation running when renderer visibility changes')

# Video proxy and automatic black/stalled-decoder recovery remain in this build.
require('VivifyVideoDecoder' in core and 'persistentDecoder' in core,
        'persistent video decoder proxy fix preserved')
asset_source = text('src/VivifyAssets.cpp')
runtime_header = text('include/VivifyRuntimeInternal.hpp')
require('VideoRenderMode::RenderTexture' in core and
        'renderTextureTarget' in core and 'set_targetTexture' in core and
        'EnsureVideoOutputBinding(video)' in core,
        'RenderTexture videos use the persistent decoder and output-rebind path')
require('VivifyVideoWarmup' in asset_source and
        'VideoRenderMode::APIOnly' in asset_source and
        'StartBundleVideoWarmups();' in asset_source and
        'ClaimBundleVideoWarmup' in core,
        'embedded clips begin decoding during menu bundle preload')
require('ResetMode::GameplayPreparation' in core and
        'ResetMode::GameplayPreparation' in text('src/VivifyEvents.cpp') and
        'preserveBundleVideoWarmups' in core and
        'BundleVideoWarmup' in runtime_header,
        'menu-warmed decoders survive the gameplay preparation reset')
require('preparePending' in core and 'kVideoPrepareWatchdogFrames' in core and
        'nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames' in core and
        'nextPrepareRetryFrame = frame + 120' not in core,
        'Android Prepare is allowed to finish instead of being restarted every two seconds')
require('HasDecodedVideoOutput' in core and 'player->get_frame()' in core and
        'player->get_width() > 0' in core and 'player->get_height() > 0' in core and
        'return player->get_width() > 0 && player->get_height() > 0;' in core,
        'Quest video health accepts a valid external texture even when VideoPlayer.frame remains -1')
require('playbackStartKnown' in core and 'playbackStartSongTime' in core and
        'firstActiveObservedSongTime' in core,
        'video time-zero follows the authored VideoPlayer GameObject activation rather than prefab creation')
register_start = core.find('void Runtime::RegisterSyncedObject(')
register_end = core.find('void Runtime::UpdateSyncedObjects()', register_start)
register_body = core[register_start:register_end]
require('UnityEngine::Object::Instantiate(root)' in register_body and
        'kCloneProbeMaxSamples = 128' in register_body and
        'probeAnimators[i]->Rebind()' in register_body and
        'authoredComponentIndex' in register_body and
        'playbackStartSongTime = eventStartSongTime + activationOffset' in register_body,
        'random/practice starts probe authored activation on an isolated bounded clone')
require('animators[i]->Rebind()' not in register_body.replace('probeAnimators[i]->Rebind()', '') and
        'animators[i]->Update(initialElapsed);' in register_body,
        'historical video probing never Rebinds the live prefab Animator hierarchy')
require('prepareNotBeforeFrame' in core and
        'video.prepareNotBeforeFrame = std::numeric_limits<int>::max();' in register_body and
        'activating deferred historical decoder' in core and
        'frame < video.prepareNotBeforeFrame' in core,
        'hidden historical videos defer MediaCodec preparation until their authored object becomes active')
require('forwardJumpTolerance' in core and 'expectedForwardAdvance' in core and
        'UnityEngine::Time::get_unscaledDeltaTime()' in core,
        'timeline-jump detection scales with practice speed and frame time')
require('video.lastAppliedPlaybackSpeed' in core and
        'vp->set_playbackSpeed(playbackSpeed)' in core,
        'playback speed is applied independently to every VideoPlayer')
require('kVideoAggressiveRecoveryMaxRate = 3.0f' in core and
        'playbackSpeed <= kVideoAggressiveRecoveryMaxRate' in core,
        'extreme practice speeds cannot enter aggressive seek/stall recovery loops')
require('Healthy persistent Quest decoders free-run' in core and
        'Repeated set_time() calls' in core,
        'healthy MaterialOverride/RenderTexture decoders free-run after their controlled startup seek')
require('set_externalReferenceTime' not in core and
        'VideoTimeReference::ExternalTime' not in core,
        'failed ExternalTime clock-chasing experiment remains removed')
require('NormalizeVideoTime' in core and 'std::fmod' in core and
        'player->get_isLooping()' in core,
        'looping videos seek against clip-local time')
require('kVideoFirstFrameGraceFrames' in core and
        'kVideoRecoveryBackoffFrames' in core and
        'kVideoStallFrames' in core and
        'decoderStalled ? "stalled"' in core,
        'black and stalled decoders retain bounded local recovery at ordinary speeds')

# Flux/map-specific compatibility experiments remain removed.
combined = '\n'.join(text(p) for p in [
    'src/VivifyObjectPrefabs.cpp', 'src/VivifyCore.cpp', 'src/VivifyPostProcessing.cpp',
    'src/VivifyComponents.cpp', 'src/VivifyHooks.cpp'])
for forbidden in ['AlwaysVisibleQuad', 'LateBloomPrePass', 'ForceGameObjectRenderersOnTop',
                  'ForceRendererOnTop', '42 Flux']:
    require(forbidden not in combined, f'map-specific override absent: {forbidden}')

# XR shader variant ownership. Unity selects Multiview/SPI to match the actual
# camera render pass. Mutating those keywords on a shared Material corrupts both
# screen-space effects and geometry shaders, and makes normal gameplay differ
# from Zen when note-replacement material repair touches shared materials.
assets = text('src/VivifyAssets.cpp')
geometry = text('src/VivifyGeometry.cpp')
stereo_start = assets.find('void Runtime::ApplyStereoKeywords')
stereo_end = assets.find('void Runtime::ApplyGameObjectStereoKeywords', stereo_start)
stereo_body = assets[stereo_start:stereo_end]
require('geometryStereoCompatibility' in stereo_body and
        'Mawntee/Beat Saber Wireframe 3D-Noise' in stereo_body and
        'Vilar/GeometryDissolve' in stereo_body and
        'Vilar/GeometryDissolveOutline' in stereo_body and
        'SetMaterialKeyword(material, u"STEREO_MULTIVIEW_ON", false)' in stereo_body and
        'SetMaterialKeyword(material, u"STEREO_INSTANCING_ON", true)' in stereo_body,
        'known Quest geometry shaders use the narrow tested stereo-instancing recipe')
require('SetMaterialKeyword(material, u"UNITY_SINGLE_PASS_STEREO"' not in stereo_body,
        'ApplyStereoKeywords never mutates UNITY_SINGLE_PASS_STEREO')
require('SetMaterialKeyword(material, u"MULTIPASS_ENABLED", GetMultipassRenderingEnabled())' in stereo_body,
        'ordinary materials leave Unity XR variant state alone and only use Vivify MULTIPASS_ENABLED')
require('NeedsStereoInstancingCompatibility' not in assets and
        'NeedsStereoInstancingCompatibility' not in geometry and
        'NeedsStereoInstancingCompatibility' not in text('include/VivifyGeometry.hpp'),
        'no broad heuristic geometry-stereo rewrite exists')
require('wireframe' in geometry.lower() and 'triangleexplosion' in geometry.lower(),
        'Wireframe and TriangleExplosion remain recognized as geometry-shader families for diagnostics')
require('Force per-eye blits (experimental)' not in main and 'GetForcePerEyeBlits' not in post,
        'misleading global per-eye blit toggle removed')
require('_StereoActiveEye' in post and '_VivifyPerEyeBlit' in post,
        'authored fullscreen per-eye blit support remains')

# SaberTrail owner follows the physical Saber while its renderer consumes
# world-space movement at world root, matching CustomModels' proven setup.
obj = text('src/VivifyObjectPrefabs.cpp')
require('trailObject->get_transform()->SetParent(replacementParent, false)' in obj and
        'InitFollowed(sourceTrail, replacementParent' in obj,
        'Vivify followed trail owner stays on the physical Saber root')
require('frame - _lastSaberIntegrityFrame >= 4' in obj,
        'late CustomModels rebuilds are suppressed quickly')
require('target.saber == saber || target.controller == smc' in obj,
        'custom saber controllers are deduplicated per physical Saber')
require('collectForeignTrails(visualRoot)' in obj and 'collectForeignTrails(replacementParent)' in obj,
        'CustomModels trails are discovered across both saber hierarchy roots')

# Newer material-property events own the properties they write; stale active
# animations may not overwrite the newer value on the next frame.
props = text('src/VivifyProperties.cpp')
require('oldProperty.id == newProperty.id' in props and
        '_materialAnimations.erase(' in props and
        'active.properties.empty()' in props,
        'new SetMaterialProperty events cancel stale writes for the same material property')

# Skybox repair must stay inside a Skybox/* shader family.
require('Skybox/Panoramic' in assets and 'context == "skybox"' in assets,
        'unsupported skybox materials use a skybox-compatible fallback')
require('_vivifySkyboxOverrideActive' not in props and
        'set_clearFlags(UnityEngine::CameraClearFlags::Skybox)' not in props,
        'SetRenderingSettings.skybox does not implicitly override camera clear mode')
require('ReadCameraPropertyValue' in post and '"_" + std::string(key)' in post,
        'SetCameraProperty accepts documented and legacy underscore field names')
require('ReadCameraBackgroundColor' in post and 'value.Size() == 1' in post,
        'camera background parser accepts flat RGBA and one-color nested form')
require('props->second.clearFlags.has_value()' in post and
        'props->second.backgroundColor.has_value()' in post and
        'mainCamPtr->set_backgroundColor(*props->second.backgroundColor)' in post,
        'authored main-camera clear/background values are reasserted during gameplay')
require('ApplyCameraProperties(mainCamPtr, props->second);' not in
        post[post.find('void Runtime::RefreshCameraComponents'):post.find('void Runtime::RefreshMultipassRendering')],
        'camera refresh reasserts only authored fields instead of resetting unrelated camera state')

# Flux / Multiview transport. Quest's main XR target is a two-slice array; a
# plain camera-boundary Blit can preserve only the active eye. Keep both slices
# with CopyTexture at the CurrentActive/CameraTarget boundaries.
mid_start = post.find('Runtime::BuildMidRenderCommandBuffer(')
mid_end = post.find('std::size_t Runtime::ComputeMidRenderSignature', mid_start)
mid_body = post[mid_start:mid_end]
require('cb->CopyTexture(srcId, ToTargetId(_midMainRT))' in mid_body and
        'cb->CopyTexture(ToTargetId(mainCurrent), dstId)' in mid_body,
        'mid-render Multiview boundaries preserve both XR texture-array slices')
apply_start = post.find('void Runtime::ApplyBlits(')
apply_end = post.find('void Runtime::CacheMainRenderDescriptor', apply_start)
apply_body = post[apply_start:apply_end]
require('UsesTextureArrayStereo() && IsTextureArray(mainCurrent->get_descriptor())' in apply_body and
        'cb->CopyTexture(ToTargetId(mainCurrent), destId);' in apply_body,
        'OnRenderImage presentation preserves both slices when CameraTarget is Multiview')

# Secondary-camera outputs must follow the XR consumer contract rather than the
# incidental source layout. Targetless Quest helper cameras can surface mono
# OnRenderImage/depth textures while authored Flux shaders consume sampler2DArray.
capture_start = post.find('void Runtime::CaptureSecondaryCameraFrame(')
capture_end = post.find('void Runtime::BindSecondaryCameraTextures()', capture_start)
capture_body = post[capture_start:capture_end]
require('bool const stereoArrayCapture = UsesTextureArrayStereo();' in capture_body and
        'ConfigureStereoRenderTextureDescriptor(srcDesc, stereoArrayCapture);' in capture_body,
        'secondary color capture publishes a stereo array whenever XR is Multiview/SPI')
require('bool const stereoDepthCapture = UsesTextureArrayStereo();' in capture_body and
        'RenderTextureFormat::RFloat' in capture_body and
        'ConfigureStereoRenderTextureDescriptor(depthDesc, stereoDepthCapture);' in capture_body and
        'depthDesc.set_depthBufferBits(0);' in capture_body and
        'set_filterMode(UnityEngine::FilterMode::Point)' in capture_body,
        'secondary depth capture publishes point-sampled high-precision RFloat with the stereo color layout')
copy_start = post.find('bool CopyCapturedTexture(')
copy_end = post.find('}  // namespace', copy_start)
copy_body = post[copy_start:copy_end]
require('Graphics::CopyTexture(source, 0, 0, destination, 0, 0)' in copy_body and
        'Graphics::CopyTexture(source, 0, 0, destination, 1, 0)' in copy_body and
        'destination, sourceEye, 0' not in copy_body,
        'mono secondary-camera callbacks publish a coherent two-slice XR texture instead of leaving one eye stale')
require('camera->get_stereoActiveEye().value__' in capture_body and
        'CopyCapturedTexture(src, output, physicalEye' in capture_body and
        'Graphics::CopyTexture(stagingDepth, 0, 0' in capture_body and
        'outputDepth, 0, 1' in capture_body,
        'secondary mono color/depth publication fills both XR slices coherently')
require('hasRenderableReplacement' in obj and
        'shaderPtr->get_isSupported()' in obj and
        'material->get_passCount() <= 0' in obj,
        'stock notes stay visible when a custom replacement has no renderable supported material')
secondary_start = comp.find('void SecondaryCameraController::OnPreCull()')
secondary_end = comp.find('void SecondaryCameraController::OnPostRender()', secondary_start)
secondary_precull = comp[secondary_start:secondary_end]
require('Runtime::Instance().RestoreSecondaryCullingLayers();' in secondary_precull and
        secondary_precull.find('RestoreSecondaryCullingLayers') < secondary_precull.find('CullingPreCull'),
        'each secondary camera restores stale culling-layer mutations before applying its own')
culling_start = comp.find('void CullingCameraController::CullingPreCull()')
culling_end = comp.find('void CullingCameraController::OnDisable()', culling_start)
culling_body = comp[culling_start:culling_end]
require('_cachedMask = _camera->get_cullingMask();' in culling_body and
        '_camera->set_cullingMask(_cachedMask.value() & ~(1 << kCullingLayer));' in culling_body,
        'blacklist cameras actually exclude Vivify private-layer renderers instead of leaking original notes')
require('bool const wasActive = go->get_activeSelf();' in post and
        'if (wasActive) go->SetActive(false);' in post and
        'secondaryBloom->____bloomPrePassRenderData = sourceBloom->____bloomPrePassRenderData;' in post and
        'if (wasActive) go->SetActive(true);' in post,
        'secondary BloomPrePass receives dependencies before Awake/reactivation')
for forbidden in ['legacyMonoChain', 'MonoDescriptorFor', 'AfterEverything',
                  'arrayColorCaptureCommandBuffer', 'PostProcessing/Tile"']:
    require(forbidden not in post, f'failed Flux compatibility experiment absent: {forbidden}')

print('ALL STATIC VIVIFY CHECKS PASSED')
