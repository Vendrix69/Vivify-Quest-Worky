#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def text(rel):
    return (ROOT / rel).read_text(errors='replace')

def require(cond, message):
    if not cond:
        print(f'FAIL: {message}', file=sys.stderr)
        raise SystemExit(1)
    print(f'PASS: {message}')

obj = text('src/VivifyObjectPrefabs.cpp')
comp = text('src/VivifyComponents.cpp')
hooks = text('src/VivifyHooks.cpp')
core = text('src/VivifyCore.cpp')
perf = text('include/VivifyQuestPerformance.hpp')
post = text('src/VivifyPostProcessing.cpp')
main = text('src/main.cpp')

# No old one-root saber field/call remains.
require('target.parent' not in obj, 'no stale ActiveSaberVisual::parent call sites')
require('replacementParent' in obj and 'visualRoot' in obj,
        'saber replacement and original/custom visual roots are separated')
require('RefreshSaberRoots' in obj,
        'saber roots are refreshed after external custom-saber hierarchy rebuilds')
require('frame + 8' in obj and 'frame + 300' in obj,
        'Quest saber replacement waits for custom-saber construction and retries')
require('preexistingSaberRenderers' in obj and 'GetComponentsInChildren<UnityEngine::Renderer*>(true)' in obj,
        'non-additive Vivify saber snapshots sibling custom-saber renderers')
require('DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in obj and
        'DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in text('include/VivifyRuntimeInternal.hpp'),
        'snapshot vector has a matching DisableOriginalRenderers overload')
require('hideOriginalTrails' in obj and 'OwnsSaberTrail(trail)' in obj,
        'trail-only replacement hides external trails without claiming their lifecycle')

# CustomModels 1.2.1 collision + geometry safety.
require('VivifyTrailRendererPrefab' in comp,
        'Vivify trail clone avoids CustomModels Trail(Clone) Awake name hook')
require('SaberMovementData::New_ctor()' in comp and 'AddNewData' in comp and
        'TransformPoint(_topPos)' in comp and 'TransformPoint(_bottomPos)' in comp,
        'Vivify trail owns world-space movement samples instead of following CustomModels/stock trail data')
require('SetParent(nullptr, true)' in comp,
        'Vivify SaberTrailRenderer is world-rooted to avoid double saber transforms')
require('GetPropertyBlock(block)' in comp and 'SetPropertyBlock(block)' in comp,
        'trail color update merges existing MaterialPropertyBlock state')
require('VivifyOwnsSaberTrailLifecycle' in hooks and 'VivifyOwnsSaberTrailRendererLifecycle' in hooks,
        'SaberTrail enable/disable hooks are ownership scoped')

# Aether/practice regression: short callback-clock duplicates are tolerated,
# while sustained practice pre-roll stalls freeze the exact catch-up pose.
require('ClockGatedSyncRate' in perf and 'consecutiveStallFrames' in perf and
        'stallThresholdFrames = 4' in perf,
        'prefab sync distinguishes short Quest scheduler duplicates from sustained song-clock stalls')
require('_syncClockStallFrames' in core and '_syncClockHasAdvanced' in core and
        'ClockGatedSyncRate(' in core,
        'runtime carries song-clock stall state across synchronized prefab updates')
require('animators[i]->set_speed(initialSyncSpeed);' in core and
        'SetParticleClockSuppressed(syncedParticle, initialSyncSpeed <= 0.0f);' in core,
        'practice catch-up pose is frozen immediately until the authoritative song clock advances')
require('struct SyncedParticleSystem' in text('include/VivifyTypes.hpp') and
        'authoredSimulationSpeed' in core and 'clockSuppressed' in core and
        'main.set_simulationSpeed(speed);' not in core,
        'particle clock gating preserves Animator-authored simulationSpeed curves')
require('NotePrefabTimelineStart' not in obj and 'noteTimelineStart' not in obj and
        'InstantiateReplacementPrefab(*info, replacementParent, replacement);' in obj,
        'note replacements never feed beat-domain NoteFloorMovement time into second-domain prefab sync')
require('AnimatorCullingMode::AlwaysAnimate' in core,
        'Vivify synced prefabs keep authored animation running when renderer visibility changes')

# Video proxy and automatic black/stalled-decoder recovery remain in this build.
require('VivifyVideoDecoder' in core and 'persistentDecoder' in core,
        'persistent video decoder proxy fix preserved')
asset_source = text('src/VivifyAssets.cpp')
runtime_header = text('include/VivifyRuntimeInternal.hpp')
require('VideoRenderMode::RenderTexture' in core and
        'renderTextureTarget' in core and 'set_targetTexture' in core and
        'EnsureVideoOutputBinding(video)' in core,
        'RenderTexture videos use the persistent decoder and output-rebind path')
require('VivifyVideoWarmup' in asset_source and
        'VideoRenderMode::APIOnly' in asset_source and
        'StartBundleVideoWarmups();' in asset_source and
        'ClaimBundleVideoWarmup' in core,
        'embedded clips begin decoding during menu bundle preload')
require('ResetMode::GameplayPreparation' in core and
        'ResetMode::GameplayPreparation' in text('src/VivifyEvents.cpp') and
        'preserveBundleVideoWarmups' in core and
        'BundleVideoWarmup' in runtime_header,
        'menu-warmed decoders survive the gameplay preparation reset')
require('preparePending' in core and 'kVideoPrepareWatchdogFrames' in core and
        'nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames' in core and
        'nextPrepareRetryFrame = frame + 120' not in core,
        'Android Prepare is allowed to finish instead of being restarted every two seconds')
require('HasDecodedVideoOutput' in core and 'player->get_frame()' in core and
        'player->get_width() > 0' in core and 'player->get_height() > 0' in core and
        'return decodedFrame >= 0' not in core,
        'video health accepts Quest external textures even when frame telemetry is unavailable')
require('NormalizeVideoTime' in core and 'std::fmod' in core and
        'player->get_isLooping()' in core,
        'looping videos seek and drift-check against clip-local time')
require('kVideoFirstFrameGraceFrames' in core and
        'kVideoRecoveryBackoffFrames' in core and
        'kVideoStallFrames' in core and
        'decoderStalled ? "stalled"' in core,
        'black and stalled decoders receive bounded local pause/seek/play recovery')
require('frameIndexAvailable' in core and
        'decodedFrame >= 0 && video.lastDecodedFrame >= 0' in core and
        'std::abs(drift) > 0.12f' not in core,
        'missing Quest frame telemetry cannot be misclassified as a stalled decoder')
require('float const videoSongTime = IsManagedAlive(_audioTimeSyncController)' in core and
        '_audioTimeSyncController->get_songTime()' in core and
        'eventVideoTime = std::max(0.0f, videoSongTime - synced.startTime)' in core and
        'playbackStartSongTime' in core and 'beforePlaybackStart' in core,
        'persistent video timeline starts from authored VideoPlayer GameObject activation')
require('firstActiveObservedFrame' in core and
        'IsAuthoredVideoGameObjectActive' in core and
        'video.playbackTimelineStarted = true' in core and
        'videoSongTime - video.playbackStartSongTime' in core,
        'first authored video activation is debounced and latched exactly once')
require('Once a persistent Quest decoder is healthy' in core and
        'video.rateFallbackActive && std::abs(drift) > 0.75f' in core and
        'set_timeReference(UnityEngine::Video::VideoTimeReference::ExternalTime)' not in core and 'set_externalReferenceTime' not in core,
        'healthy persistent decoders free-run; only unsupported practice rates receive sparse repair')
require('historicalVideoProbeRan' in core and 'firstActiveOffsets' in core and
        'playbackStartSongTime = eventStartSongTime + offset' in core,
        'practice starts recover authored VideoPlayer activation time without a live ExternalTime clock')
require('lastAppliedPlaybackSpeed' in core and 'vp->get_canSetPlaybackSpeed()' in core and
        'video.lastAppliedPlaybackSpeed' in core and
        'vp->set_playbackSpeed(playbackSpeed);' in core,
        'practice-speed capability and native-rate attempts are tracked per VideoPlayer')
require('!video.rateFallbackActive &&' in core and
        'std::abs(drift) > kVideoDriftToleranceSeconds' in core,
        'camera-plane/APIOnly players retain bounded normal drift correction')

props_for_overlap = text('src/VivifyProperties.cpp')
require('oldProperty.id == newProperty.id' in props_for_overlap and
        'animation = _materialAnimations.erase(animation);' in props_for_overlap,
        'new material-property events supersede stale animations of the same property')

# Flux/map-specific compatibility experiments remain removed.
combined = '\n'.join(text(p) for p in [
    'src/VivifyObjectPrefabs.cpp', 'src/VivifyCore.cpp', 'src/VivifyPostProcessing.cpp',
    'src/VivifyComponents.cpp', 'src/VivifyHooks.cpp'])
for forbidden in ['AlwaysVisibleQuad', 'LateBloomPrePass', 'ForceGameObjectRenderersOnTop',
                  'ForceRendererOnTop', '42 Flux']:
    require(forbidden not in combined, f'map-specific override absent: {forbidden}')

require('_camera->set_cullingMask(_cachedMask.value() & ~(1 << kCullingLayer));' in comp,
        'blacklist cameras exclude Vivify private layer so originals cannot leak behind distorted-note composites')
require('bool const wasActive = go->get_activeSelf();' in post and
        'if (wasActive) go->SetActive(false);' in post and
        'secondaryBloom->____bloomPrepassRenderer = sourceBloom->____bloomPrepassRenderer;' in post and
        'if (wasActive) go->SetActive(true);' in post,
        'secondary-camera BloomPrePass receives copied dependencies before its first Awake')

# XR shader variant ownership. Unity remains authoritative for ordinary
# materials. Only the three tested legacy geometry/wireframe families are
# allowed to select their existing stereo-instancing variants because their
# Multiview geometry stage drops the right-eye array layer.
assets = text('src/VivifyAssets.cpp')
geometry = text('src/VivifyGeometry.cpp')
stereo_start = assets.find('void Runtime::ApplyStereoKeywords')
stereo_end = assets.find('void Runtime::ApplyGameObjectStereoKeywords', stereo_start)
stereo_body = assets[stereo_start:stereo_end]
require('Mawntee/Beat Saber Wireframe 3D-Noise' in stereo_body and
        'Vilar/GeometryDissolve' in stereo_body and
        'Vilar/GeometryDissolveOutline' in stereo_body,
        'targeted Quest geometry stereo recipe covers known wireframe families')
require('geometryStereoCompatibility' in stereo_body and
        'SetMaterialKeyword(material, u"STEREO_MULTIVIEW_ON", false)' in stereo_body and
        'SetMaterialKeyword(material, u"STEREO_INSTANCING_ON", true)' in stereo_body,
        'known legacy geometry shaders select the stereo-instancing right-eye variant')
require('SetMaterialKeyword(material, u"MULTIPASS_ENABLED", GetMultipassRenderingEnabled())' in stereo_body,
        'ordinary materials retain Vivify legacy MULTIPASS_ENABLED compatibility only')
require('wireframe' in geometry.lower() and 'triangleexplosion' in geometry.lower(),
        'Wireframe and TriangleExplosion remain recognized as geometry-shader families for diagnostics')
require('Force per-eye blits (experimental)' not in main and 'GetForcePerEyeBlits' not in post,
        'misleading global per-eye blit toggle removed')
require('_StereoActiveEye' in post and '_VivifyPerEyeBlit' in post and
        'NeedsLegacyMonoBlit' not in post and 'legacyMonoChain' not in post and
        'MonoDescriptorFor' not in post,
        'failed per-eye mono staging path is absent; native XR array transport remains authoritative')

# SaberTrail owner follows the physical Saber while its renderer consumes
# world-space movement at world root, matching CustomModels' proven setup.
obj = text('src/VivifyObjectPrefabs.cpp')
require('trailObject->get_transform()->SetParent(replacementParent, false)' in obj and
        'InitFollowed(sourceTrail, replacementParent' in obj,
        'Vivify followed trail owner stays on the physical Saber root')
require('frame - _lastSaberIntegrityFrame >= 4' in obj,
        'late CustomModels rebuilds are suppressed quickly')
require('target.saber == saber || target.controller == smc' in obj,
        'custom saber controllers are deduplicated per physical Saber')
require('collectForeignTrails(visualRoot)' in obj and 'collectForeignTrails(replacementParent)' in obj,
        'CustomModels trails are discovered across both saber hierarchy roots')

# Skybox repair must stay inside a Skybox/* shader family.
require('Skybox/Panoramic' in assets and 'context == "skybox"' in assets,
        'unsupported skybox materials use a skybox-compatible fallback')
props = text('src/VivifyProperties.cpp')
require('_vivifySkyboxOverrideActive' not in props and
        'set_clearFlags(UnityEngine::CameraClearFlags::Skybox)' not in props,
        'SetRenderingSettings.skybox does not implicitly override camera clear mode')
require('ReadCameraPropertyValue' in post and '"_" + std::string(key)' in post,
        'SetCameraProperty accepts documented and legacy underscore field names')
require('ReadCameraBackgroundColor' in post and 'value.Size() == 1' in post,
        'camera background parser accepts flat RGBA and one-color nested form')
require('props->second.clearFlags.has_value()' in post and
        'props->second.backgroundColor.has_value()' in post and
        'mainCamPtr->set_backgroundColor(*props->second.backgroundColor)' in post,
        'authored main-camera clear/background values are reasserted during gameplay')
require('ApplyCameraProperties(mainCamPtr, props->second);' not in
        post[post.find('void Runtime::RefreshCameraComponents'):post.find('void Runtime::RefreshMultipassRendering')],
        'camera refresh reasserts only authored fields instead of resetting unrelated camera state')

# Flux / Multiview transport. Quest's main XR target is a two-slice array; a
# plain camera-boundary Blit can preserve only the active eye. Keep both slices
# with CopyTexture at the CurrentActive/CameraTarget boundaries.
mid_start = post.find('Runtime::BuildMidRenderCommandBuffer(')
mid_end = post.find('std::size_t Runtime::ComputeMidRenderSignature', mid_start)
mid_body = post[mid_start:mid_end]
require('cb->CopyTexture(srcId, ToTargetId(_midMainRT))' in mid_body and
        'cb->CopyTexture(ToTargetId(mainCurrent), dstId)' in mid_body,
        'mid-render Multiview boundaries preserve both XR texture-array slices')
apply_start = post.find('void Runtime::ApplyBlits(')
apply_end = post.find('void Runtime::CacheMainRenderDescriptor', apply_start)
apply_body = post[apply_start:apply_end]
require('UsesTextureArrayStereo() && IsTextureArray(mainCurrent->get_descriptor())' in apply_body and
        'cb->CopyTexture(ToTargetId(mainCurrent), destId);' in apply_body,
        'OnRenderImage presentation preserves both slices when CameraTarget is Multiview')
require('legacyMonoChain' not in apply_body and 'MonoDescriptorFor' not in apply_body,
        'Flux image chains do not split persistent XR feedback state into independent mono histories')

# Secondary-camera outputs must follow the XR consumer contract rather than the
# incidental OnRenderImage source layout. Flux's DistortNotes/Tile/Scram depend
# on a genuine two-eye camera color target plus matching owned depth.
capture_start = post.find('void Runtime::CaptureSecondaryCameraFrame(')
capture_end = post.find('void Runtime::BindSecondaryCameraTextures()', capture_start)
capture_body = post[capture_start:capture_end]
refresh_capture_start = post.find('void Runtime::RefreshSecondaryCameraCaptureBuffers()')
refresh_capture_end = post.find('UnityEngine::RenderTexture* Runtime::SecondaryCameraColorRT', refresh_capture_start)
refresh_capture_body = post[refresh_capture_start:refresh_capture_end]
require('BuiltinRenderTextureType::CurrentActive' in refresh_capture_body and
        'commandBuffer->CopyTexture(currentActive, ToTargetId(output));' in refresh_capture_body and
        '__E_AfterEverything' in refresh_capture_body,
        'secondary camera color is copied from the completed native XR target into an owned stereo array')
require('commandBufferOwnsArrayColor' in capture_body and
        'cam.colorRT = cam.colorRTs[2]' in capture_body,
        'OnRenderImage cannot overwrite native secondary stereo color with a mono helper source')
require('bool const stereoDepthCapture = UsesTextureArrayStereo();' in capture_body and
        'ConfigureStereoRenderTextureDescriptor(depthDesc, stereoDepthCapture);' in capture_body,
        'secondary depth capture matches the stereo color layout')
secondary_image_start = comp.find('void SecondaryCameraController::OnRenderImage(')
secondary_image_end = comp.find('UnityEngine::Camera* SecondaryCameraController::GetCamera()', secondary_image_start)
secondary_image_body = comp[secondary_image_start:secondary_image_end]
require('runtime.CaptureSecondaryCameraFrame(cameraName, camera, src);' in secondary_image_body and
        'runtime.CopyStereoRenderTexture(src, dest)' in secondary_image_body and
        'UnityEngine::Graphics::Blit(src, dest);' in secondary_image_body,
        'secondary OnRenderImage fulfills Unity source-to-destination pass-through contract')
require('CanUseImplicitPerEyeBlit' in post and
        'material->HasProperty(texture.propertyId)' in post and
        'material->HasProperty(cameraDepthTextureId)' in post and
        'material->HasProperty(camera.texturePropertyId.value())' in post and
        'material->HasProperty(camera.depthTexturePropertyId.value())' in post and
        'shaderName == "PostProcessing/Tile"' in post and
        '!_secondaryCameras.empty() && !verifiedSourceOnlyWithSecondaryCamera' in post,
        'implicit per-eye compatibility stays conservative around secondary-camera globals while preserving the verified source-only Tile effect')
secondary_start = comp.find('void SecondaryCameraController::OnPreCull()')
secondary_end = comp.find('void SecondaryCameraController::OnPostRender()', secondary_start)
secondary_precull = comp[secondary_start:secondary_end]
require('Runtime::Instance().RestoreSecondaryCullingLayers();' in secondary_precull and
        secondary_precull.find('RestoreSecondaryCullingLayers') < secondary_precull.find('CullingPreCull'),
        'each secondary camera restores stale culling-layer mutations before applying its own')

print('ALL STATIC VIVIFY CHECKS PASSED')
