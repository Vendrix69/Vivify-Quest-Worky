#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def text(rel):
    return (ROOT / rel).read_text(errors='replace')

def require(cond, message):
    if not cond:
        print(f'FAIL: {message}', file=sys.stderr)
        raise SystemExit(1)
    print(f'PASS: {message}')

obj = text('src/VivifyObjectPrefabs.cpp')
comp = text('src/VivifyComponents.cpp')
hooks = text('src/VivifyHooks.cpp')
core = text('src/VivifyCore.cpp')
perf = text('include/VivifyQuestPerformance.hpp')
post = text('src/VivifyPostProcessing.cpp')
main = text('src/main.cpp')

# No old one-root saber field/call remains.
require('target.parent' not in obj, 'no stale ActiveSaberVisual::parent call sites')
require('replacementParent' in obj and 'visualRoot' in obj,
        'saber replacement and original/custom visual roots are separated')
require('RefreshSaberRoots' in obj,
        'saber roots are refreshed after external custom-saber hierarchy rebuilds')
require('frame + 8' in obj and 'frame + 300' in obj,
        'Quest saber replacement waits for custom-saber construction and retries')
require('preexistingSaberRenderers' in obj and 'GetComponentsInChildren<UnityEngine::Renderer*>(true)' in obj,
        'non-additive Vivify saber snapshots sibling custom-saber renderers')
require('hideOriginalTrails' in obj and 'OwnsSaberTrail(trail)' in obj,
        'trail-only replacement hides external trails without claiming their lifecycle')

# CustomModels 1.2.1 collision + geometry safety.
require('VivifyTrailRendererPrefab' in comp,
        'Vivify trail clone avoids CustomModels Trail(Clone) Awake name hook')
require('sourceTrailParent' in comp and 'followedTransform->get_parent' in comp,
        'Vivify trail renderer keeps Beat Saber source trail coordinate space')
require('GetPropertyBlock(block)' in comp and 'SetPropertyBlock(block)' in comp,
        'trail color update merges existing MaterialPropertyBlock state')
require('VivifyOwnsSaberTrailLifecycle' in hooks and 'VivifyOwnsSaberTrailRendererLifecycle' in hooks,
        'SaberTrail enable/disable hooks are ownership scoped')

# Aether/Zen regression: duplicate audio timestamps are not a pause.
require('(void) previousSongTime;' in perf and 'return timeScale;' in perf,
        'duplicate Quest song-time samples keep prefab Animator/ParticleSystem playback running')
require('currentSongTime <= previousSongTime' not in perf,
        'old duplicate-songTime freeze policy removed')

# Video proxy remains in this build.
require('VivifyVideoDecoder' in core and 'persistentDecoder' in core,
        'persistent video decoder proxy fix preserved')

# Flux/map-specific compatibility hacks remain removed.
combined = '\n'.join(text(p) for p in [
    'src/VivifyObjectPrefabs.cpp', 'src/VivifyCore.cpp', 'src/VivifyPostProcessing.cpp',
    'src/VivifyComponents.cpp', 'src/VivifyHooks.cpp'])
for forbidden in ['AlwaysVisibleQuad', 'ForceGameObjectRenderersOnTop', 'ForceRendererOnTop', '42 Flux']:
    require(forbidden not in combined, f'map-specific override absent: {forbidden}')

# Stereo compatibility control.
require('GetForcePerEyeBlits()' in post and 'forcedCompatibility' in post,
        'experimental global per-eye blit compatibility mode is wired')
require('Force per-eye blits (experimental)' in main,
        'per-eye blit compatibility toggle is exposed in mod settings')
require('_StereoActiveEye' in post and '0.0f' in post and '1.0f' in post,
        'per-eye compatibility blits explicitly drive eye 0 and eye 1')

print('ALL STATIC VIVIFY CHECKS PASSED')
