#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def text(rel):
    return (ROOT / rel).read_text(errors='replace')

def require(cond, message):
    if not cond:
        print(f'FAIL: {message}', file=sys.stderr)
        raise SystemExit(1)
    print(f'PASS: {message}')

obj = text('src/VivifyObjectPrefabs.cpp')
comp = text('src/VivifyComponents.cpp')
hooks = text('src/VivifyHooks.cpp')
core = text('src/VivifyCore.cpp')
perf = text('include/VivifyQuestPerformance.hpp')
post = text('src/VivifyPostProcessing.cpp')
main = text('src/main.cpp')

# No old one-root saber field/call remains.
require('target.parent' not in obj, 'no stale ActiveSaberVisual::parent call sites')
require('replacementParent' in obj and 'visualRoot' in obj,
        'saber replacement and original/custom visual roots are separated')
require('RefreshSaberRoots' in obj,
        'saber roots are refreshed after external custom-saber hierarchy rebuilds')
require('frame + 8' in obj and 'frame + 300' in obj,
        'Quest saber replacement waits for custom-saber construction and retries')
require('preexistingSaberRenderers' in obj and 'GetComponentsInChildren<UnityEngine::Renderer*>(true)' in obj,
        'non-additive Vivify saber snapshots sibling custom-saber renderers')
require('DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in obj and
        'DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in text('include/VivifyRuntimeInternal.hpp'),
        'snapshot vector has a matching DisableOriginalRenderers overload')
require('hideOriginalTrails' in obj and 'OwnsSaberTrail(trail)' in obj,
        'trail-only replacement hides external trails without claiming their lifecycle')

# CustomModels 1.2.1 collision + geometry safety.
require('VivifyTrailRendererPrefab' in comp,
        'Vivify trail clone avoids CustomModels Trail(Clone) Awake name hook')
require('SaberMovementData::New_ctor()' in comp and 'AddNewData' in comp and
        'TransformPoint(_topPos)' in comp and 'TransformPoint(_bottomPos)' in comp,
        'Vivify trail owns world-space movement samples instead of following CustomModels/stock trail data')
require('SetParent(nullptr, true)' in comp,
        'Vivify SaberTrailRenderer is world-rooted to avoid double saber transforms')
require('GetPropertyBlock(block)' in comp and 'SetPropertyBlock(block)' in comp,
        'trail color update merges existing MaterialPropertyBlock state')
require('VivifyOwnsSaberTrailLifecycle' in hooks and 'VivifyOwnsSaberTrailRendererLifecycle' in hooks,
        'SaberTrail enable/disable hooks are ownership scoped')

# Aether/practice regression: short callback-clock duplicates are tolerated,
# while sustained practice pre-roll stalls freeze the exact catch-up pose.
require('ClockGatedSyncRate' in perf and 'consecutiveStallFrames' in perf and
        'stallThresholdFrames = 4' in perf,
        'prefab sync distinguishes short Quest scheduler duplicates from sustained song-clock stalls')
require('_syncClockStallFrames' in core and '_syncClockHasAdvanced' in core and
        'ClockGatedSyncRate(' in core,
        'runtime carries song-clock stall state across synchronized prefab updates')
require('animators[i]->set_speed(initialSyncSpeed);' in core and
        'SetParticleClockSuppressed(syncedParticle, initialSyncSpeed <= 0.0f);' in core,
        'practice catch-up pose is frozen immediately until the authoritative song clock advances')
require('struct SyncedParticleSystem' in text('include/VivifyTypes.hpp') and
        'authoredSimulationSpeed' in core and 'clockSuppressed' in core and
        'main.set_simulationSpeed(speed);' not in core,
        'particle clock gating preserves Animator-authored simulationSpeed curves')
require('NotePrefabTimelineStart' not in obj and 'noteTimelineStart' not in obj and
        'InstantiateReplacementPrefab(*info, replacementParent, replacement);' in obj,
        'note replacements never feed beat-domain NoteFloorMovement time into second-domain prefab sync')
require('AnimatorCullingMode::AlwaysAnimate' in core,
        'Vivify synced prefabs keep authored animation running when renderer visibility changes')

# Video proxy and automatic black/stalled-decoder recovery remain in this build.
require('VivifyVideoDecoder' in core and 'persistentDecoder' in core,
        'persistent video decoder proxy fix preserved')
asset_source = text('src/VivifyAssets.cpp')
runtime_header = text('include/VivifyRuntimeInternal.hpp')
require('VideoRenderMode::RenderTexture' in core and
        'renderTextureTarget' in core and 'set_targetTexture' in core and
        'EnsureVideoOutputBinding(video)' in core,
        'RenderTexture videos use the persistent decoder and output-rebind path')
require('VivifyVideoWarmup' in asset_source and
        'VideoRenderMode::APIOnly' in asset_source and
        'StartBundleVideoWarmups();' in asset_source and
        'ClaimBundleVideoWarmup' in core,
        'embedded clips begin decoding during menu bundle preload')
require('ResetMode::GameplayPreparation' in core and
        'ResetMode::GameplayPreparation' in text('src/VivifyEvents.cpp') and
        'preserveBundleVideoWarmups' in core and
        'BundleVideoWarmup' in runtime_header,
        'menu-warmed decoders survive the gameplay preparation reset')
require('preparePending' in core and 'kVideoPrepareWatchdogFrames' in core and
        'nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames' in core and
        'nextPrepareRetryFrame = frame + 120' not in core,
        'Android Prepare is allowed to finish instead of being restarted every two seconds')
require('HasDecodedVideoOutput' in core and 'player->get_frame()' in core and
        'player->get_width() > 0' in core and 'player->get_height() > 0' in core and
        'return player->get_width() > 0 && player->get_height() > 0;' in core,
        'Quest video health accepts a valid external texture even when VideoPlayer.frame remains -1')
require('playbackStartKnown' in core and 'playbackStartSongTime' in core and
        'firstActiveObservedSongTime' in core,
        'video time-zero follows the authored VideoPlayer GameObject activation rather than prefab creation')
register_start = core.find('void Runtime::RegisterSyncedObject(')
register_end = core.find('void Runtime::UpdateSyncedObjects()', register_start)
register_body = core[register_start:register_end]
require('UnityEngine::Object::Instantiate(root)' in register_body and
        'kHistoricalAnimatorStepSeconds = 0.05f' in core and
        'kHistoricalAnimatorMaxSteps = 4096' in core and
        'probeAnimators[i]->Rebind()' in register_body and
        'probeAnimators[i]->Update(step)' in register_body and
        'authoredComponentIndex' in register_body and
        'playbackStartSongTime = eventStartSongTime + activationOffset' in register_body,
        'random/practice starts reconstruct authored activation chronologically on an isolated clone')
require('kCloneProbeRefineSteps' not in core and 'kCloneProbeMaxSamples' not in core and
        'probeAnimators[i]->Rebind();' in register_body and
        register_body.count('probeAnimators[i]->Rebind();') == 1,
        'historical clone performs one zero-time Rebind and never binary-search jumps through Animator state')
require('AdvanceAnimatorChronologically(animators[i], initialElapsed);' in register_body and
        'animators[i]->Update(initialElapsed);' not in register_body and
        'animators[i]->Rebind()' not in register_body,
        'live prefab Animator walks the historical timeline in small chronological steps without Rebind')
require('kHistoricalPrepareStaggerFrames = 12' in core and
        'kHistoricalPrepareStaggerFrames * (++hiddenHistoricalRank)' in register_body and
        'video.prepareNotBeforeFrame = std::numeric_limits<int>::max();' in register_body and
        'frame < video.prepareNotBeforeFrame' in core,
        'already-started hidden historical videos prepare staggered while genuinely future videos remain cold')
require('Start the decoder according to the song clock even if its target' in core and
        'RequestVideoSeek(video, static_cast<double>(videoTime), true, frame);' in core,
        'historical persistent decoders start through the serialized asynchronous seek lifecycle')
require('enum class VideoSeekPhase' in text('include/VivifyTypes.hpp') and
        'BeginVideoSeek' in core and 'RequestVideoSeek' in core and
        'AdvanceVideoSeekLifecycle' in core and
        'OnVideoSeekCompleted' in core and 'OnVideoFrameReady' in core,
        'synced video has an explicit Prepare/Seek/frame-ready lifecycle')
require('player->set_sendFrameReadyEvents(true);' in core and
        'player->set_sendFrameReadyEvents(video.frameReadyEventsBaseline);' in core and
        'video.frameReadyEventsBaseline = vp->get_sendFrameReadyEvents();' in core,
        'frameReady callbacks are enabled only around seeks and authored callback state is restored')
require('InvokePrepareCompletedCallback_Internal' in hooks and
        'InvokeSeekCompletedCallback_Internal' in hooks and
        'InvokeFrameReadyCallback_Internal' in hooks,
        'Unity VideoPlayer prepare/seek/frame callbacks are bridged into the runtime')
video_set_time_calls = re.findall(r'(?:player|vp)->set_time\s*\(', core)
require(len(video_set_time_calls) == 1 and 'player->set_time(target);' in core and
        'set_time(0.0)' not in asset_source,
        'exactly one synchronized VideoPlayer set_time call site exists and menu warmup does not seek')
require('video.queuedSeek = true;' in core and
        'seekCompletedReceived' in core and 'frameReadyReceived' in core and
        'if (video.queuedSeek)' in core,
        'seek requests are coalesced while one Android seek is outstanding')
require('RecoverHistoricalVideoStartsForReuse' in core and 'historicalRecovered={}' in core and
        'kHistoricalPrepareStaggerFrames * (++hiddenHistoricalRank)' in
            core[core.find('bool RecoverHistoricalVideoStartsForReuse'):register_start],
        'prewarmed decoder reuse uses the same chronological recovery and stagger policy')
require('static_cast<bool>(historicalTargetActive[videoIndex])' in core and
        'static_cast<bool>(targetActive[i])' in core,
        'vector<bool> proxy values are converted to bool before fmt logging/branch-sensitive use')
require('forwardJumpTolerance' in core and 'expectedForwardAdvance' in core and
        'UnityEngine::Time::get_unscaledDeltaTime()' in core,
        'timeline-jump detection scales with practice speed and frame time')
require('video.lastAppliedPlaybackSpeed' in core and
        'vp->set_playbackSpeed(playbackSpeed)' in core,
        'playback speed is applied independently to every VideoPlayer')
require('kVideoAggressiveRecoveryMaxRate = 3.0f' in core and
        'playbackSpeed <= kVideoAggressiveRecoveryMaxRate' in core,
        'extreme practice speeds cannot enter aggressive seek/stall recovery loops')
require('Healthy persistent Quest decoders free-run' in core and
        'Repeated set_time() calls' in core,
        'healthy MaterialOverride/RenderTexture decoders free-run after their controlled startup seek')
require('set_externalReferenceTime' not in core and
        'VideoTimeReference::ExternalTime' not in core,
        'failed ExternalTime clock-chasing experiment remains removed')
require('NormalizeVideoTime' in core and 'std::fmod' in core and
        'player->get_isLooping()' in core,
        'looping videos seek against clip-local time')
require('kVideoFirstFrameGraceFrames' in core and
        'kVideoRecoveryBackoffFrames' in core and
        'kVideoStallFrames' in core and
        'decoderStalled ? "stalled"' in core,
        'black and stalled decoders retain bounded local recovery at ordinary speeds')

# Flux/map-specific compatibility experiments remain removed.
combined = '\n'.join(text(p) for p in [
    'src/VivifyObjectPrefabs.cpp', 'src/VivifyCore.cpp', 'src/VivifyPostProcessing.cpp',
    'src/VivifyComponents.cpp', 'src/VivifyHooks.cpp'])
for forbidden in ['AlwaysVisibleQuad', 'LateBloomPrePass', 'ForceGameObjectRenderersOnTop',
                  'ForceRendererOnTop', '42 Flux']:
    require(forbidden not in combined, f'map-specific override absent: {forbidden}')

# XR shader variant ownership. Unity selects Multiview/SPI to match the actual
# camera render pass. Mutating those keywords on a shared Material corrupts both
# screen-space effects and geometry shaders, and makes normal gameplay differ
# from Zen when note-replacement material repair touches shared materials.
assets = text('src/VivifyAssets.cpp')
geometry = text('src/VivifyGeometry.cpp')
stereo_start = assets.find('void Runtime::ApplyStereoKeywords')
stereo_end = assets.find('void Runtime::ApplyGameObjectStereoKeywords', stereo_start)
stereo_body = assets[stereo_start:stereo_end]
require('geometryStereoCompatibility' in stereo_body and
        'Mawntee/Beat Saber Wireframe 3D-Noise' in stereo_body and
        'shaderName == NormalizeAssetKey("Mawntee/Beat Saber Wireframe 3D-Noise")' in stereo_body and
        'SetMaterialKeyword(material, u"STEREO_MULTIVIEW_ON", false)' in stereo_body and
        'SetMaterialKeyword(material, u"STEREO_INSTANCING_ON", true)' in stereo_body,
        'the Mawntee geometry shader keeps the narrow tested stereo-instancing recipe')
require('shaderName == NormalizeAssetKey("Vilar/GeometryDissolve")' not in stereo_body and
        'shaderName == NormalizeAssetKey("Vilar/GeometryDissolveOutline")' not in stereo_body,
        'Vilar geometry shaders are not keyword-forced into a mismatched XR variant')
repair_start = assets.find('void Runtime::RepairMaterialShader')
repair_end = assets.find('void Runtime::RepairGameObjectMaterials', repair_start)
repair_body = assets[repair_start:repair_end]
require('questVilarGeometry' in repair_body and
        'NormalizeAssetKey("Vilar/GeometryDissolve")' in repair_body and
        'NormalizeAssetKey("Vilar/GeometryDissolveOutline")' in repair_body and
        'if (questVilarGeometry && IsAlive(rawShader)' in repair_body and
        '_repairedMaterials.emplace(material);' in repair_body and
        '"BeatSaber/Note"sv' not in repair_body and
        '"BeatSaber/Unlit Glow"sv' not in repair_body,
        'Quest Vilar materials are preserved instead of being destructively replaced by unrelated Beat Saber shaders')
require('SetMaterialKeyword(material, u"UNITY_SINGLE_PASS_STEREO"' not in stereo_body,
        'ApplyStereoKeywords never mutates UNITY_SINGLE_PASS_STEREO')
require('SetMaterialKeyword(material, u"MULTIPASS_ENABLED", GetMultipassRenderingEnabled())' in stereo_body,
        'ordinary materials leave Unity XR variant state alone and only use Vivify MULTIPASS_ENABLED')
require('NeedsStereoInstancingCompatibility' not in assets and
        'NeedsStereoInstancingCompatibility' not in geometry and
        'NeedsStereoInstancingCompatibility' not in text('include/VivifyGeometry.hpp'),
        'no broad heuristic geometry-stereo rewrite exists')
require('wireframe' in geometry.lower() and 'triangleexplosion' in geometry.lower(),
        'Wireframe and TriangleExplosion remain recognized as geometry-shader families for diagnostics')
require('Force per-eye blits (experimental)' not in main and 'GetForcePerEyeBlits' not in post,
        'misleading global per-eye blit toggle removed')
require('_StereoActiveEye' in post and '_VivifyPerEyeBlit' in post,
        'authored fullscreen per-eye blit support remains')

# SaberTrail owner follows the physical Saber while its renderer consumes
# world-space movement at world root, matching CustomModels' proven setup.
obj = text('src/VivifyObjectPrefabs.cpp')
require('trailObject->get_transform()->SetParent(replacementParent, false)' in obj and
        'InitFollowed(sourceTrail, replacementParent' in obj,
        'Vivify followed trail owner stays on the physical Saber root')
require('frame - _lastSaberIntegrityFrame >= 4' in obj,
        'late CustomModels rebuilds are suppressed quickly')
require('target.saber == saber || target.controller == smc' in obj,
        'custom saber controllers are deduplicated per physical Saber')
require('collectForeignTrails(visualRoot)' in obj and 'collectForeignTrails(replacementParent)' in obj,
        'CustomModels trails are discovered across both saber hierarchy roots')

# Newer material-property events own the properties they write; stale active
# animations may not overwrite the newer value on the next frame.
props = text('src/VivifyProperties.cpp')
require('oldProperty.id == newProperty.id' in props and
        '_materialAnimations.erase(' in props and
        'active.properties.empty()' in props,
        'new SetMaterialProperty events cancel stale writes for the same material property')

# Skybox repair must stay inside a Skybox/* shader family.
require('Skybox/Panoramic' in assets and 'context == "skybox"' in assets,
        'unsupported skybox materials use a skybox-compatible fallback')
require('_vivifySkyboxOverrideActive' not in props and
        'set_clearFlags(UnityEngine::CameraClearFlags::Skybox)' not in props,
        'SetRenderingSettings.skybox does not implicitly override camera clear mode')
require('ReadCameraPropertyValue' in post and '"_" + std::string(key)' in post,
        'SetCameraProperty accepts documented and legacy underscore field names')
require('ReadCameraBackgroundColor' in post and 'value.Size() == 1' in post,
        'camera background parser accepts flat RGBA and one-color nested form')
require('props->second.clearFlags.has_value()' in post and
        'props->second.backgroundColor.has_value()' in post and
        'mainCamPtr->set_backgroundColor(*props->second.backgroundColor)' in post,
        'authored main-camera clear/background values are reasserted during gameplay')
require('ApplyCameraProperties(mainCamPtr, props->second);' not in
        post[post.find('void Runtime::RefreshCameraComponents'):post.find('void Runtime::RefreshMultipassRendering')],
        'camera refresh reasserts only authored fields instead of resetting unrelated camera state')

# Flux / Multiview transport. The failed manual Camera.Render per-eye experiment
# is gone. Match upstream Vivify's secondary-camera contract instead: helper
# cameras stay targetless/enabled so Unity XR owns stereo rendering, OnRenderImage
# captures the result, and secondary depth is published as high-precision RFloat.
mid_start = post.find('Runtime::BuildMidRenderCommandBuffer(')
mid_end = post.find('std::size_t Runtime::ComputeMidRenderSignature', mid_start)
mid_body = post[mid_start:mid_end]
require('legacyMonoChain' not in post and 'MonoDescriptorFor' not in post and
        'arrayColorCaptureCommandBuffer' not in post and
        'CanonicalizeImageEffectDescriptor' not in comp and
        'captureTargetRT' not in post and 'captureTargetRT' not in text('include/VivifyTypes.hpp'),
        'failed Flux mono/canonical-target experiments remain removed')
cache_start = post.find('void Runtime::CacheMainRenderDescriptor')
cache_end = post.find('void Runtime::EnsureDeclaredTextures', cache_start)
cache_body = post[cache_start:cache_end]
ensure_cache_start = post.find('Runtime::EnsureCachedBlitTexture')
ensure_cache_end = post.find('void Runtime::ReleaseRenderTexture', ensure_cache_start)
ensure_cache_body = post[ensure_cache_start:ensure_cache_end]
require('ConfigureStereoRenderTextureDescriptor(desc, UsesTextureArrayStereo());' not in cache_body and
        'ConfigureStereoRenderTextureDescriptor(desc, UsesTextureArrayStereo());' not in ensure_cache_body,
        'main/feedback render targets are no longer globally rewritten by the failed canonical-RT experiment')
require('cb->Blit(srcId, ToTargetId(_midMainRT));' in mid_body and
        'cb->Blit(ToTargetId(mainCurrent), dstId);' in mid_body,
        'BeforeMainEffect camera-event boundaries stay on Unity camera Blits')

require('RenderSecondaryCamerasStereo' not in post and
        'manualStereoCapture' not in comp and
        'manualStereoEye' not in comp and
        'manualCaptureTargets' not in text('include/VivifyTypes.hpp') and
        'manualCaptureEye' not in text('include/VivifyTypes.hpp') and
        'camera->Render();' not in post and
        'GetStereoViewMatrix_Injected' not in post and
        'GetStereoProjectionMatrix_Injected' not in post,
        'manual per-eye Camera.Render transport and injected HMD-matrix experiment are fully removed')
create_start = post.find('void Runtime::HandleCreateCamera(')
create_end = post.find('void Runtime::ReleaseSecondaryCamera', create_start)
create_body = post[create_start:create_end]
require(create_start >= 0 and create_end > create_start and
        'cam.camera->set_targetTexture(nullptr);' in create_body and
        'cam.camera->set_enabled(true);' in create_body,
        'secondary cameras remain targetless and enabled for Unity XR native stereo rendering')

capture_start = post.find('void Runtime::CaptureSecondaryCameraFrame(')
capture_end = post.find('void Runtime::BindSecondaryCameraTextures()', capture_start)
capture_body = post[capture_start:capture_end]
require(capture_start >= 0 and capture_end > capture_start and
        'bool const stereoArrayCapture = UsesTextureArrayStereo();' in capture_body and
        'camera->get_stereoActiveEye().value__' in capture_body,
        'OnRenderImage capture follows Unity XR stereo-active-eye/array state instead of a fabricated eye index')
require('RenderTextureFormat::RFloat' in capture_body and
        'set_filterMode(UnityEngine::FilterMode::Point)' in capture_body and
        'ConfigureStereoRenderTextureDescriptor(depthDesc, stereoDepthCapture);' in capture_body,
        'secondary depth is converted into the high-precision RFloat stereo texture contract')
require('ConfigureStereoRenderTextureDescriptor(srcDesc, stereoArrayCapture);' in capture_body,
        'secondary color publishes the Tex2DArray layout authored Vivify shaders expect under Multiview')

require('hasRenderableReplacement' in obj and
        'hasQuestVilarGeometryReplacement' in obj and
        '!hasQuestVilarGeometryReplacement' in obj,
        'Quest Vilar replacements keep the readable stock note behind the authored geometry material')
secondary_start = comp.find('void SecondaryCameraController::OnPreCull()')
secondary_end = comp.find('void SecondaryCameraController::OnPostRender()', secondary_start)
secondary_precull = comp[secondary_start:secondary_end]
require(secondary_start >= 0 and secondary_end > secondary_start and
        'Runtime::Instance().RestoreSecondaryCullingLayers();' in secondary_precull and
        secondary_precull.find('RestoreSecondaryCullingLayers') < secondary_precull.find('CullingPreCull'),
        'secondary camera still restores/applies culling isolation before Unity XR renders it')
multiview_start = secondary_precull.find('if (textureArrayStereo) {')
multiview_end = secondary_precull.find('} else if (!actualMultipass)', multiview_start)
multiview_body = secondary_precull[multiview_start:multiview_end]
require(multiview_start >= 0 and multiview_end > multiview_start and
        'camera->set_projectionMatrix(other->get_projectionMatrix())' not in multiview_body and
        'camera->set_worldToCameraMatrix(other->get_worldToCameraMatrix())' not in multiview_body,
        'Quest Multiview does not overwrite XR per-eye matrices with mono main-camera matrices')
culling_start = comp.find('void CullingCameraController::CullingPreCull()')
culling_end = comp.find('void CullingCameraController::OnDisable()', culling_start)
culling_body = comp[culling_start:culling_end]
require('_cachedMask = _camera->get_cullingMask();' in culling_body and
        '_camera->set_cullingMask(_cachedMask.value() & ~(1 << kCullingLayer));' in culling_body,
        'blacklist cameras actually exclude Vivify private-layer renderers instead of leaking original notes')
require('bool const wasActive = go->get_activeSelf();' in post and
        'if (wasActive) go->SetActive(false);' in post and
        'secondaryBloom->____bloomPrePassRenderData = sourceBloom->____bloomPrePassRenderData;' in post and
        'if (wasActive) go->SetActive(true);' in post,
        'secondary BloomPrePass receives dependencies before Awake/reactivation')
for forbidden in ['legacyMonoChain', 'MonoDescriptorFor', 'AfterEverything',
                  'arrayColorCaptureCommandBuffer']:
    require(forbidden not in post, f'failed Flux compatibility experiment absent: {forbidden}')

print('ALL STATIC VIVIFY CHECKS PASSED')
