# Vivify Quest 0.6.14 compatibility patch

This standalone source keeps the persistent video-decoder fix and keeps the old
Flux-specific visibility/sorting workarounds removed.

## CustomModels 1.2.1 / saber compatibility

- Vivify's replacement model stays on the physical Saber transform while the
  stock/custom visual root is tracked separately for hide/restore.
- Vivify's custom trail no longer follows another SaberTrail's movement buffer.
  It owns a `SaberMovementData` and samples its authored top/bottom endpoints in
  world space immediately before `SaberTrail::LateUpdate`, matching the proven
  CustomModels approach.
- The cloned `SaberTrailRenderer` is world-rooted so world-space vertices are not
  transformed by the saber hierarchy a second time (the ~10 m offset/exploded
  trail failure).
- Non-additive Vivify trail replacement rechecks foreign/custom trails every four
  frames so late CustomModels rebuilds are hidden quickly without stealing their
  lifecycle.
- Vivify's trail clone avoids CustomModels' global `Trail(Clone)` name hook and
  preserves existing MaterialPropertyBlock values.

## Aether / prefab animation

- Removed the previous note-prefab timing experiment that passed
  `NoteFloorMovement._beatTime` into the generic prefab synchronizer. That field
  is beat-domain data while the synchronizer is song-time/seconds-domain, so it
  could place normal-gameplay custom note Animators at invalid phases and make
  the Zen-vs-normal comparison worse.
- Synced Vivify Animators still use `AlwaysAnimate` so renderer visibility cannot
  pause authored environment animation.
- Duplicate Quest audio-clock samples are still not treated as a pause; actual
  `AudioTimeSyncController.timeScale` drives synchronized playback.

## Mid-render / secondary-camera transport

- Builtin Unity camera targets (`CurrentActive` and `CameraTarget`) are no longer
  passed to `CommandBuffer.CopyTexture` as though they were owned stereo
  `RenderTexture`s. Mid-render effects use command-buffer `Blit` at the camera
  boundary; `CopyTexture` remains only for explicit compatible RT-to-RT copies.
- Final post-processing presentation to a builtin CameraTarget also uses `Blit`.
- Every secondary camera restores outstanding temporary culling-layer mutations
  before applying its own whitelist/blacklist. This prevents a missed
  `OnPostRender` from stranding notes or environment renderers on Vivify's
  private culling layer.
- These are generic render-pipeline fixes; no 42-flux map-name special case was
  reintroduced.

## Geometry stereo

- The misleading global per-eye Blit toggle remains removed. Blit compatibility
  is not used as a geometry-shader fix.
- The exact Aether shader `Mawntee/Beat Saber Wireframe 3D-Noise` gets a targeted
  runtime stereo recipe: Multiview keyword off, stereo-instancing variant on.
  Its source already transfers Unity stereo data through the geometry stage, so
  this selects the variant whose stereo output can carry the render-target array
  layer. Other geometry shaders keep their authored/native XR variant.
- TriangleExplosion-style shaders with an explicit Multiview
  `SV_RenderTargetArrayIndex` patch are left untouched.

## Camera background / black-void compatibility

- Removed the incorrect Quest-only rule that implicitly changed the main camera
  to `Skybox` whenever `SetRenderingSettings.skybox` was authored. Desktop Vivify
  keeps render settings and camera clear flags independent.
- `SetCameraProperty.backgroundColor` is now authoritative on the main camera and
  is reasserted during runtime updates so another Quest/Beat Saber camera component
  cannot reset an authored `SolidColor` background back to black.
- Camera property parsing accepts both normal and legacy underscore field names,
  plus both documented flat RGBA and single nested ColorArray forms.

## Preserved fixes

- Persistent always-active Quest video decoder proxy.
- Flux-specific AlwaysVisibleQuad / forced-sorting / negative-time / startup
  timing hacks remain removed.
