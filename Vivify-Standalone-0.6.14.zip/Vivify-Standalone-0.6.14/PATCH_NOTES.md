# Vivify Standalone 0.6.14 — V1 Video Light 3: seek-storm fix

Baseline: **V1 Video Light 1**. This pass does not change decoder count, proxy lifetime,
output routing, `skipOnDrop`, authored video timing, Teto logic, Flux logic, or Luminescent.

## Research-backed fixes

### 1. Do not accelerate an in-flight Android seek
Unity documents `VideoPlayer.time = target` as an asynchronous seek. Accurate compressed-video
seeking can require decoding from the preceding keyframe to the target. Light1 immediately applied
the historical +2x boost (up to 4x) before Quest had produced any output, making the most expensive
part of a random/practice start even more decoder-hungry.

Light3 keeps the real practice rate while the first historical seek is settling. Vivify may only use
the existing bounded catch-up boost **after** a usable frame exists and that frame is still actually
behind the song target.

### 2. Stop blind 5-second boosting when Quest reports `frame == -1`
Quest can expose a valid external video texture while Unity still reports `VideoPlayer.frame == -1`.
Light1 intentionally accepts that as healthy, but its catch-up completion logic then had no timestamp
and therefore kept the boost alive until the hard timeout.

Light3 falls back to `VideoPlayer.time`, which Unity defines as the presentation time of the currently
available frame. If the displayed frame is already on time, catch-up ends instead of racing ahead.

### 3. Stop re-seeking a slow seek before it finishes
Unity documents that assigning `VideoPlayer.time` again while a seek is already running queues a new
seek. Light1's local recovery/start retry could therefore restart/queue work on Heartbeat before the
first heavy seek had a chance to complete.

Historical startup now gets a 900-frame non-destructive watchdog before a local retry, and the short
30-frame not-playing path is suppressed while that initial seek is still settling.

### 4. Recovery uses the *actual* decoder rate
At 200% practice speed Light1 could request 4x during historical catch-up, but stall recovery checked
the authored 2x speed and incorrectly decided aggressive pause/seek/play recovery was safe. Light3
checks `requestedVideoRate` instead.

## Expected effect
- Teto and 3 Big Shots should behave like Light1 or better.
- Heartbeat should no longer self-sabotage a slow random-timeline seek with repeated seeks / premature
  4x pressure.
- No additional MediaCodec instances are created.
- No logger is required for this experiment.
