# Vivify Quest 0.6.14 compatibility patch

## 2026-09-15 consolidated root-cause pass

This pass deliberately replaces the recent speculative Flux/video experiments
with the smallest architecture changes supported by upstream Vivify and Unity's
VideoPlayer lifecycle. Existing project file and folder names are unchanged.

- **Flux / secondary cameras:** removed the explicit per-eye `Camera.Render()`
  transport. Secondary cameras stay targetless, and non-MultiPass cameras mirror
  the main camera's projection/view state. The published color/depth pair now
  comes from the same `OnRenderImage` capture and follows the actual callback
  descriptor/eye instead of inventing a texture-array layout from XR mode. A
  genuine depth-only source is preserved with a whole-texture depth copy when
  Unity exposes one; color-form depth keeps the RFloat compatibility path. The
  culling controller now moves exactly the GameObjects registered to Vivify's
  tracker, matching desktop's authored culling scope instead of recursively
  broadening the selection to every descendant renderer.
- **Android video:** synchronized `VideoPlayer.time` writes still go through one
  serialized asynchronous seek path, but the proxy no longer forces every
  authored VideoPlayer onto one invented lifetime. Players that desktop Vivify
  would song-synchronize keep the absolute InstantiatePrefab clock; players below
  initially-inactive children keep a local enable/play clock. Menu warmup decodes
  one real first frame and freezes instead of looping to an arbitrary position.
  Playback is requested immediately when a controlled seek begins, while
  `seekCompleted`/`frameReady` serialize follow-up seeks. Output rebinds repair
  Android surfaces without redefining the video clock.
- **Vilar late-note geometry:** the runtime no longer replaces
  `Vilar/GeometryDissolve*` with unrelated Beat Saber shaders. The authored
  material is preserved, while stock note geometry remains visible behind it on
  Quest as a readability guard. A literal Multiview `gl_Layer` /
  `SV_RenderTargetArrayIndex` repair cannot be made from this source archive
  because the map's Android shader bundle/compiled Vilar variant is not present.
- **Validation:** the static validator now rejects the removed manual stereo
  path, enforces the single synchronized `set_time()` call site, checks the
  VideoPlayer callback bridge, verifies RFloat secondary depth, and verifies
  that Vilar shader substitution stays removed.

## CustomModels 1.2.1 / saber compatibility

- Vivify's replacement model stays on the physical Saber transform while the
  stock/custom visual root is tracked separately for hide/restore.
- Vivify's custom trail no longer follows another SaberTrail's movement buffer.
  It owns a `SaberMovementData` and samples its authored top/bottom endpoints in
  world space immediately before `SaberTrail::LateUpdate`, matching the proven
  CustomModels approach.
- The cloned `SaberTrailRenderer` is world-rooted so world-space vertices are not
  transformed by the saber hierarchy a second time (the ~10 m offset/exploded
  trail failure).
- Non-additive Vivify trail replacement rechecks foreign/custom trails every four
  frames so late CustomModels rebuilds are hidden quickly without stealing their
  lifecycle.
- Vivify's trail clone avoids CustomModels' global `Trail(Clone)` name hook and
  preserves existing MaterialPropertyBlock values.

## Aether / prefab animation

- Removed the previous note-prefab timing experiment that passed
  `NoteFloorMovement._beatTime` into the generic prefab synchronizer. That field
  is beat-domain data while the synchronizer is song-time/seconds-domain, so it
  could place normal-gameplay custom note Animators at invalid phases and make
  the Zen-vs-normal comparison worse.
- Synced Vivify Animators still use `AlwaysAnimate` so renderer visibility cannot
  pause authored environment animation.
- Prefab animation now uses a clock gate: one-to-three duplicate callback-song
  timestamps are treated as harmless Quest scheduler quantization, but a
  sustained practice/pre-roll stall freezes Animator/legacy Animation/particles
  at the exact catch-up pose until the authoritative song clock advances again.
  This specifically prevents scene-load time from advancing Aether's Drop
  animation ahead of the music in normal gameplay while Zen loads faster.
- Particle clock gating no longer writes the global 0x/1x song rate into
  `ParticleSystem.MainModule.simulationSpeed`. It captures the current authored
  value only when the song clock stops and restores it when the clock resumes.
  This preserves Aether's Animator curves (including the fast/slow arrow and
  ribbon bursts) while still freezing particles during pre-roll and pause.

## Embedded video playback

- Bundle preload still discovers embedded `VideoClip` dependencies and keeps one
  hidden decoder warm for later adoption by the live prefab.
- Persistent decoder proxies continue to support both `MaterialOverride` and
  authored `RenderTexture` output, including output rebinding when Android
  creates/recreates its external texture.
- **Seeking is serialized.** `BeginVideoSeek` is the only synchronized
  `VideoPlayer::set_time()` call site. It enables frame-ready events, issues one
  seek, and requests playback immediately instead of waiting for decoded-frame
  notification. The seek remains busy until the requested frame is observed,
  preventing a second `set_time()` from being queued into MediaCodec.
- `seekCompleted`, `frameReady`, and `prepareCompleted` are bridged from
  `VideoPlayer` into the runtime. While a seek is in flight, a newer request is
  stored as one coalesced target; no second `set_time()` is issued until the
  current seek has produced its requested frame.
- Healthy persistent Quest decoders free-run at `playbackSpeed`; they are not
  continuously clock-chased with seeks. Real timeline jumps and bounded
  black/stalled-output recovery may request a new serialized seek.
- Fresh menu warmup decoders do not add a seek after `Prepare`; they decode one
  real first frame and pause there instead of looping in the menu. If output is
  still absent after the grace period, recovery is bounded and any repositioning
  still goes through the single serialized seek path.
- When a prepared decoder is already close to the requested normal-start time,
  it resumes without seeking. Material/RenderTexture outputs are explicitly
  detached and rebound on activation so a stale Android output surface can be
  repaired without disturbing decoder time.
- Looping clips continue to use clip-local target time, and first-frame/output
  checks continue to require real decoded output rather than a non-null external
  texture shell.

## Mid-render / secondary-camera transport

- Removed the explicit Quest per-eye helper-camera loop (`Camera.Render()` twice,
  injected stereo matrices, mono eye targets, then array packing). Upstream
  Vivify warns that this path does not reliably write the right eye.
- `CreateCamera` helpers are again **targetless and enabled**. Unity XR performs
  their normal stereo render pass and Vivify captures the result from
  `OnRenderImage` instead of fabricating an XR pass from native code.
- Published color/depth texture layout follows the actual `OnRenderImage`
  source descriptor. The runtime no longer forces a two-slice array solely because
  XR is in Multiview, and it no longer duplicates a mono callback into both eyes.
- Secondary color and depth are committed atomically from the same capture so a
  post-process cannot observe a new color frame paired with stale depth from a
  different eye/frame. Genuine depth-only RenderTextures are preserved with an
  exact whole-texture copy when the backend exposes them; color-form depth uses
  the owned RFloat compatibility path.
- Culling isolation now changes exactly the GameObjects registered to the Vivify
  culling tracker and restores them after the helper camera, matching desktop
  Vivify's scope instead of recursively moving descendant renderer GameObjects.
- Secondary-camera culling isolation remains intact. In every non-MultiPass XR
  mode, including Quest Multiview, the helper mirrors the main camera's generic
  projection, non-jittered projection, and world-to-camera matrices, matching the
  upstream `SecondaryCameraController` contract.
- No map-name special case is used.

## XR shader-variant ownership / Flux / Aether / Wireframe

- Unity/XR remains the owner of `STEREO_MULTIVIEW_ON`,
  `STEREO_INSTANCING_ON`, and `UNITY_SINGLE_PASS_STEREO` for ordinary authored
  materials. The only retained narrow compatibility recipe is the previously
  tested Mawntee wireframe case.
- `Vilar/GeometryDissolve` and `Vilar/GeometryDissolveOutline` are no longer
  replaced with `BeatSaber/Note`, `BeatSaber/Unlit Glow`, Standard, or another
  guessed substitute merely because the runtime is Quest.
- The authored Vilar material is left present so a corrected Android shader
  variant can work without another native-code change. Until that compiled
  shader is available, note replacement deliberately keeps the stock gameplay
  note renderer behind the Vilar replacement so a zero-pixel Multiview geometry
  pass cannot make the note unreadable.
- This is a guard, not a claim that the geometry shader itself is repaired. A
  true Quest Multiview fix belongs in the Vilar geometry stage and needs the map
  Android asset/shader variant.

## Camera background / black-void compatibility

- Removed the incorrect Quest-only rule that implicitly changed the main camera
  to `Skybox` whenever `SetRenderingSettings.skybox` was authored. Desktop Vivify
  keeps render settings and camera clear flags independent.
- `SetCameraProperty.backgroundColor` is now authoritative on the main camera and
  is reasserted during runtime updates so another Quest/Beat Saber camera component
  cannot reset an authored `SolidColor` background back to black.
- Camera property parsing accepts both normal and legacy underscore field names,
  plus both documented flat RGBA and single nested ColorArray forms.

## Preserved fixes

- Persistent always-active Quest video decoder proxy.
- Flux-specific visibility/sorting, negative-time, and startup-timing
  experiments remain removed.
