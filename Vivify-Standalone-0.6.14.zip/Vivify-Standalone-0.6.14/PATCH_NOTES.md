# Vivify Quest 0.6.14 compatibility patch

This standalone source keeps the confirmed Aether particle-clock fix and adds
bounded recovery for Android video decoders that previously needed a manual
pause/resume.

## CustomModels 1.2.1 / saber compatibility

- Vivify's replacement model stays on the physical Saber transform while the
  stock/custom visual root is tracked separately for hide/restore.
- Vivify's custom trail no longer follows another SaberTrail's movement buffer.
  It owns a `SaberMovementData` and samples its authored top/bottom endpoints in
  world space immediately before `SaberTrail::LateUpdate`, matching the proven
  CustomModels approach.
- The cloned `SaberTrailRenderer` is world-rooted so world-space vertices are not
  transformed by the saber hierarchy a second time (the ~10 m offset/exploded
  trail failure).
- Non-additive Vivify trail replacement rechecks foreign/custom trails every four
  frames so late CustomModels rebuilds are hidden quickly without stealing their
  lifecycle.
- Vivify's trail clone avoids CustomModels' global `Trail(Clone)` name hook and
  preserves existing MaterialPropertyBlock values.

## Aether / prefab animation

- Removed the previous note-prefab timing experiment that passed
  `NoteFloorMovement._beatTime` into the generic prefab synchronizer. That field
  is beat-domain data while the synchronizer is song-time/seconds-domain, so it
  could place normal-gameplay custom note Animators at invalid phases and make
  the Zen-vs-normal comparison worse.
- Synced Vivify Animators still use `AlwaysAnimate` so renderer visibility cannot
  pause authored environment animation.
- Prefab animation now uses a clock gate: one-to-three duplicate callback-song
  timestamps are treated as harmless Quest scheduler quantization, but a
  sustained practice/pre-roll stall freezes Animator/legacy Animation/particles
  at the exact catch-up pose until the authoritative song clock advances again.
  This specifically prevents scene-load time from advancing Aether's Drop
  animation ahead of the music in normal gameplay while Zen loads faster.
- Particle clock gating no longer writes the global 0x/1x song rate into
  `ParticleSystem.MainModule.simulationSpeed`. It captures the current authored
  value only when the song clock stops and restores it when the clock resumes.
  This preserves Aether's Animator curves (including the fast/slow arrow and
  ribbon bursts) while still freezing particles during pre-roll and pause.

## Video timing / material event ordering

- Video elapsed time now stays in the same BeatmapCallbacks clock domain as
  the authored InstantiatePrefab/custom-event start time. Mixing the audio
  controller clock with callback-authored start times during startup/catch-up
  could seek clips ahead before their event. No map-specific timing offset is
  applied.
- Menu-warmed decoders now stop as soon as a real frame is available and are
  reset to frame zero. Persistent proxies remain `APIOnly` until the authored
  event actually begins, so a decoder that spent time warming in the menu
  cannot publish a future/stale frame to a MaterialOverride or RenderTexture
  and then visibly jump backward when gameplay seeks it.
- `SetMaterialProperty` now supersedes older in-flight animations for every
  property named by the new event. This fixes same-beat handoffs where the old
  animation's final sample could run later in the frame and overwrite an
  instantaneous value (for example YOU's `ambientflare` `_Opacity=0` at the
  end of its buildup).

## Embedded video playback

- Bundle preload now discovers embedded `VideoClip` dependencies through their
  prefab `VideoPlayer` components and starts one hidden API-only decoder per
  clip while the song is still selected in the menu. The warmed decoder is
  carried across gameplay preparation and adopted by the live prefab, moving
  the observed multi-second Quest MediaCodec startup out of the song.
- Persistent decoder proxies now support authored `RenderTexture` output in
  addition to `MaterialOverride`. The target texture is created and rebound at
  startup/first-frame/recovery boundaries. This is the output mode used by the
  late-or-never black video surface in the supplied recordings; the prior proxy
  eligibility test skipped it completely.
- Looping clips now seek and drift-check against clip-local time. The previous
  ever-growing song-relative target could repeatedly seek past the end after a
  loop and strand only those players until a pause/resume.
- Output readiness now requires a real decoded frame with valid dimensions;
  the non-null external-texture shell exposed before MediaCodec emits frame 0
  is no longer treated as healthy output.
- Slow decoders get a full startup window and bounded retries. The previous
  8-12 frame recovery cadence could restart the seek/play path before large
  clips produced their first frame.
- Prepared players that stop advancing receive the same local pause/seek/play
  kick that a whole-game pause supplied, without interrupting healthy videos.
- MaterialOverride is rebound when the first decoded frame becomes real, and
  ordinary decoder lag no longer causes 0.12-second seek storms.

## Mid-render / secondary-camera transport

- Quest Multiview secondary-camera outputs now follow the XR **consumer**
  contract instead of the incidental `OnRenderImage` source layout. A targetless
  helper camera may expose a mono color/depth source; Vivify now publishes the
  authored output as a two-slice Tex2DArray and duplicates a mono capture into
  both slices. This keeps Flux `_NotesOne`/`_NotesOne_Depth`-style pairs valid for
  sampler2DArray shaders.
- Restored array-preserving `CommandBuffer.CopyTexture` at Multiview
  `CurrentActive -> _midMainRT` and final `mainCurrent -> CameraTarget`
  boundaries. The prior all-`Blit` experiment preserved only the active layer
  and did not improve Flux.
- Every secondary camera restores outstanding temporary culling-layer mutations
  before applying its own whitelist/blacklist. This prevents a missed
  `OnPostRender` from stranding notes or environment renderers on Vivify's
  private culling layer.
- These are generic render-pipeline fixes; no 42-flux map-name special case was
  reintroduced.

## XR shader-variant ownership / Flux / Aether / Wireframe

- Removed all runtime forcing/clearing of Unity-owned `STEREO_MULTIVIEW_ON`,
  `STEREO_INSTANCING_ON`, and `UNITY_SINGLE_PASS_STEREO` material keywords.
- Quest Multiview, desktop SPI, and true MultiPass must use the shader variant
  selected by Unity for the active camera pass. Shared Vivify materials are no
  longer allowed to switch that XR contract when a prefab/note is repaired.
- Removed the failed Wireframe-specific "force instanced stereo" recipe. It was
  selecting an instanced shader variant while Quest was actually rendering a
  Multiview pass and could never synthesize the missing geometry-stage eye/layer
  routing.
- `ApplyStereoKeywords` now owns only Vivify's documented `MULTIPASS_ENABLED`
  compatibility keyword.
- This is a generic root-cause fix for Flux screen/depth texture chains and the
  Aether normal-vs-Zen shared-material divergence. A geometry shader whose
  Android Multiview bytecode itself lacks eye/layer emission still requires a
  real shader-source/compiled-program repair; TriangleExplosion remains the
  reference for that case.

## Camera background / black-void compatibility

- Removed the incorrect Quest-only rule that implicitly changed the main camera
  to `Skybox` whenever `SetRenderingSettings.skybox` was authored. Desktop Vivify
  keeps render settings and camera clear flags independent.
- `SetCameraProperty.backgroundColor` is now authoritative on the main camera and
  is reasserted during runtime updates so another Quest/Beat Saber camera component
  cannot reset an authored `SolidColor` background back to black.
- Camera property parsing accepts both normal and legacy underscore field names,
  plus both documented flat RGBA and single nested ColorArray forms.

## Video continuity / shared-screen arbitration

- Shared MaterialOverride/RenderTexture output no longer automatically means a
  section-local timeline. Players using the same authored VideoClip/URL retain
  continuous hidden playback (Heartbeat behavior).
- True source swaps on one output retain deterministic single-owner arbitration
  and section-local timing (Teto behavior).
- MaterialOverride ownership now requires the authored target Renderer/GameObject
  to be visible, so an enabled-but-hidden VideoPlayer cannot steal the surface
  and leave the visible screen white.

## Preserved fixes

- Persistent always-active Quest video decoder proxy.
- Flux-specific visibility/sorting, negative-time, and startup-timing
  experiments remain removed.

## Video activation and Quest decoder stability

- Persistent video proxies now wait for the authored `VideoPlayer` GameObject/component to be active before starting the visible clip timeline. Prefabs may still be instantiated/prewarmed early; decoder preparation remains hidden and does not advance published content.
- Renderer visibility is deliberately not used as the playback gate, preserving maps that hide/show a screen while expecting one continuous decoder timeline.
- The authored `VideoPlayer` remains enabled with `playOnAwake` suppressed so Animator/GameObject enable state can be observed without allowing a second decoder to compete with the Quest proxy.
- `VideoPlayer.frame == -1` is no longer treated as proof of decoder failure. Quest hardware decoders can expose a valid external texture and dimensions without a reliable frame index; stall detection is used only when a real frame index is available. This prevents periodic pause/seek/play recovery loops from making healthy video visibly twitch.
## Video double-output isolation

- Persistent Quest video proxies now have exclusive ownership of visible video output.
- The original authored `VideoPlayer` remains enabled only as the map's GameObject/component lifecycle probe, but its render mode is forced to `APIOnly` while the proxy is active.
- The proxy uses the cached original `MaterialOverride`/`RenderTexture` mode rather than mirroring the probe's live mode. This prevents a paused authored player and the active proxy from alternately publishing different frames to the same screen, which appears as character clipping/twitching even when synchronization is correct.
- The authored render mode is restored when Vivify releases the synchronized object.



## Hybrid video timeline / exclusive shared-output ownership

- The Teto regression was isolated by diffing the build where its sync was correct against the later Heartbeat build. The regression came from changing *every* persistent player to advance while hidden.
- Lone video outputs keep the Heartbeat behavior: after the first authored activation establishes time zero, temporary hiding detaches presentation but the decoder keeps advancing in the background.
- When multiple authored VideoPlayers reuse the same `RenderTexture` or the same `MaterialOverride` renderer/property, they now use section-local pause/resume timing instead. Hidden/non-owning players do not accumulate song time, restoring the timing behavior from the Teto-sync-good build.
- Shared outputs have exactly one deterministic visible owner. Other active proxies stay `APIOnly`, preventing two MediaCodec outputs from racing the same target and producing alternating/duplicated character frames.
- Shared-output arbitration still keys MaterialOverride players by the authored renderer/property pair, but the persistent Quest proxy no longer copies that property onto itself. The Heartbeat-working path uses Unity's normal `_MainTex` proxy binding; forcing an authored property onto the proxy could leave a healthy decoder attached to a non-visible slot and show a solid white screen.
- Registration leaves persistent proxies API-only until the first complete update pass, preventing a one-frame multi-writer leak before ownership is resolved.
