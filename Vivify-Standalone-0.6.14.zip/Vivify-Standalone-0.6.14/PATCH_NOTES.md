# Clean Baseline Reset

This build intentionally removes the accumulated video experiments from commits 104-117.

## Video
- Video runtime is restored to Commit 103 RecordingSafePersistentSync.
- No high-speed song-clock servo.
- No 3.0x large-drift burst.
- No compensated second seek.
- No multi-decoder special lane.
- No cold-start topology barrier.
- No fresh-player ownership swap.
- No APIOnly relay/recycling architecture.
- No extra video state fields from those experiments remain in VivifyTypes.hpp.

Commit 103 is the last empirically proven video baseline where Heartbeat 200% random-timeline playback synchronized quickly under recording. Its known remaining limitation is slow catch-up for some 3 Big Shots 200% historical starts; that is intentionally left as one isolated future problem.

## Proven fixes retained
- Commit 109 legacy Tex2D per-eye bridge for Luminescent Glitch/Pixelate, which fixed mirrored sabers.
- Commit 108 material animation ownership semantics.
- Commit 112 material/global/render restart-state hygiene, including restoring bundle material state on restart.

## Experiments intentionally removed
- Commit 110/111 declared-screen-texture bridge for 3 Big Shots Hidden/Old.
- Commit 116 Lumi overlap-chain experiment.
- Commit 117 video ownership/restart reuse experiment.

Luminescent's short blackout before Pixelate is intentionally NOT addressed in this clean baseline.
