# Vivify Quest 0.6.14 compatibility patch

This standalone source keeps the confirmed Aether particle-clock fix and adds
bounded recovery for Android video decoders that previously needed a manual
pause/resume.

## CustomModels 1.2.1 / saber compatibility

- Vivify's replacement model stays on the physical Saber transform while the
  stock/custom visual root is tracked separately for hide/restore.
- Vivify's custom trail no longer follows another SaberTrail's movement buffer.
  It owns a `SaberMovementData` and samples its authored top/bottom endpoints in
  world space immediately before `SaberTrail::LateUpdate`, matching the proven
  CustomModels approach.
- The cloned `SaberTrailRenderer` is world-rooted so world-space vertices are not
  transformed by the saber hierarchy a second time (the ~10 m offset/exploded
  trail failure).
- Non-additive Vivify trail replacement rechecks foreign/custom trails every four
  frames so late CustomModels rebuilds are hidden quickly without stealing their
  lifecycle.
- Vivify's trail clone avoids CustomModels' global `Trail(Clone)` name hook and
  preserves existing MaterialPropertyBlock values.

## Aether / prefab animation

- Removed the previous note-prefab timing experiment that passed
  `NoteFloorMovement._beatTime` into the generic prefab synchronizer. That field
  is beat-domain data while the synchronizer is song-time/seconds-domain, so it
  could place normal-gameplay custom note Animators at invalid phases and make
  the Zen-vs-normal comparison worse.
- Synced Vivify Animators still use `AlwaysAnimate` so renderer visibility cannot
  pause authored environment animation.
- Prefab animation now uses a clock gate: one-to-three duplicate callback-song
  timestamps are treated as harmless Quest scheduler quantization, but a
  sustained practice/pre-roll stall freezes Animator/legacy Animation/particles
  at the exact catch-up pose until the authoritative song clock advances again.
  This specifically prevents scene-load time from advancing Aether's Drop
  animation ahead of the music in normal gameplay while Zen loads faster.
- Particle clock gating no longer writes the global 0x/1x song rate into
  `ParticleSystem.MainModule.simulationSpeed`. It captures the current authored
  value only when the song clock stops and restores it when the clock resumes.
  This preserves Aether's Animator curves (including the fast/slow arrow and
  ribbon bursts) while still freezing particles during pre-roll and pause.

## Embedded video playback

- Bundle preload now discovers embedded `VideoClip` dependencies through their
  prefab `VideoPlayer` components and starts one hidden API-only decoder per
  clip while the song is still selected in the menu. The warmed decoder is
  carried across gameplay preparation and adopted by the live prefab, moving
  the observed multi-second Quest MediaCodec startup out of the song.
- Persistent decoder proxies now support authored `RenderTexture` output in
  addition to `MaterialOverride`. The target texture is created and rebound at
  startup/first-frame/recovery boundaries. This is the output mode used by the
  late-or-never black video surface in the supplied recordings; the prior proxy
  eligibility test skipped it completely.
- Looping clips now seek and drift-check against clip-local time. The previous
  ever-growing song-relative target could repeatedly seek past the end after a
  loop and strand only those players until a pause/resume.
- Output readiness now requires a real decoded frame with valid dimensions;
  the non-null external-texture shell exposed before MediaCodec emits frame 0
  is no longer treated as healthy output.
- Slow decoders get a full startup window and bounded retries. The previous
  8-12 frame recovery cadence could restart the seek/play path before large
  clips produced their first frame.
- Prepared players that stop advancing receive the same local pause/seek/play
  kick that a whole-game pause supplied, without interrupting healthy videos.
- MaterialOverride is rebound when the first decoded frame becomes real, and
  ordinary decoder lag no longer causes 0.12-second seek storms.

## Mid-render / secondary-camera transport

- Quest Multiview secondary-camera outputs now follow the XR **consumer**
  contract instead of the incidental `OnRenderImage` source layout. A targetless
  helper camera may expose a mono color/depth source; Vivify now publishes the
  authored output as a two-slice Tex2DArray and duplicates a mono capture into
  both slices. This keeps Flux `_NotesOne`/`_NotesOne_Depth`-style pairs valid for
  sampler2DArray shaders.
- Restored array-preserving `CommandBuffer.CopyTexture` at Multiview
  `CurrentActive -> _midMainRT` and final `mainCurrent -> CameraTarget`
  boundaries. The prior all-`Blit` experiment preserved only the active layer
  and did not improve Flux.
- Every secondary camera restores outstanding temporary culling-layer mutations
  before applying its own whitelist/blacklist. This prevents a missed
  `OnPostRender` from stranding notes or environment renderers on Vivify's
  private culling layer.
- These are generic render-pipeline fixes; no 42-flux map-name special case was
  reintroduced.

## XR shader-variant ownership / Flux / Aether / Wireframe

- Removed all runtime forcing/clearing of Unity-owned `STEREO_MULTIVIEW_ON`,
  `STEREO_INSTANCING_ON`, and `UNITY_SINGLE_PASS_STEREO` material keywords.
- Quest Multiview, desktop SPI, and true MultiPass must use the shader variant
  selected by Unity for the active camera pass. Shared Vivify materials are no
  longer allowed to switch that XR contract when a prefab/note is repaired.
- Removed the failed Wireframe-specific "force instanced stereo" recipe. It was
  selecting an instanced shader variant while Quest was actually rendering a
  Multiview pass and could never synthesize the missing geometry-stage eye/layer
  routing.
- `ApplyStereoKeywords` now owns only Vivify's documented `MULTIPASS_ENABLED`
  compatibility keyword.
- This is a generic root-cause fix for Flux screen/depth texture chains and the
  Aether normal-vs-Zen shared-material divergence. A geometry shader whose
  Android Multiview bytecode itself lacks eye/layer emission still requires a
  real shader-source/compiled-program repair; TriangleExplosion remains the
  reference for that case.

## Camera background / black-void compatibility

- Removed the incorrect Quest-only rule that implicitly changed the main camera
  to `Skybox` whenever `SetRenderingSettings.skybox` was authored. Desktop Vivify
  keeps render settings and camera clear flags independent.
- `SetCameraProperty.backgroundColor` is now authoritative on the main camera and
  is reasserted during runtime updates so another Quest/Beat Saber camera component
  cannot reset an authored `SolidColor` background back to black.
- Camera property parsing accepts both normal and legacy underscore field names,
  plus both documented flat RGBA and single nested ColorArray forms.

## Preserved fixes

- Persistent always-active Quest video decoder proxy.
- Flux-specific visibility/sorting, negative-time, and startup-timing
  experiments remain removed.

## 2026-09-13 unified Quest compatibility pass

- Global distorted-note shell fix: blacklist camera culling now explicitly excludes Vivify's private tracked-object layer. The old path moved tracked note renderers but left that layer enabled on the blacklist camera, so the undistorted original leaked into the main image underneath the distorted/composited copy.
- Legacy fullscreen Blit shaders in Multiview now automatically use per-slice compatibility rendering when they do not advertise native stereo keywords. `_VivifyPerEyeBlit=0` remains an explicit opt-out and native stereo-aware shaders stay on their authored path.
- Secondary-camera `BloomPrePass` is added while the camera GameObject is inactive, its serialized dependencies are copied from the main camera, and only then is the object reactivated. This prevents `Awake()` from initializing against null/default dependencies.
- Persistent Quest VideoPlayers can use Unity `VideoTimeReference.ExternalTime` driven by Beat Saber's absolute song clock. Practice speed changes and seeks therefore follow song time directly instead of relying on repeated decoder-rate/drift corrections.
- Normal-start persistent videos latch their timeline origin from the first stable activation of the authored VideoPlayer GameObject; later authored hide/show animation does not pause or rebase the decoder. Deep historical catch-up retains event-time origin as a safe fallback when the first activation can no longer be observed.
- Quest video output health no longer treats `VideoPlayer.frame == -1` as failure when a valid decoded external texture and dimensions are present; frame indices are used only when available for stall telemetry.
- No Flux map-name checks, forced sorting-order hacks, or other map-specific overrides were added. These fixes are generic Vivify/Quest behavior.
