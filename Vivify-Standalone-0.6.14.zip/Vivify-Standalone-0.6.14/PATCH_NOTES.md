# Vivify Quest 0.6.14 compatibility patch

## 2026-09-15 consolidated root-cause pass

This pass deliberately replaces the recent speculative Flux/video experiments
with the smallest architecture changes supported by upstream Vivify and Unity's
VideoPlayer lifecycle. Existing project file and folder names are unchanged.

- **Flux / secondary cameras:** removed the explicit per-eye `Camera.Render()`
  transport and HMD matrix injection. Secondary cameras are targetless and
  enabled again so Unity XR owns the stereo render pass; their `OnRenderImage`
  output is captured into the authored Vivify texture contract. Secondary depth
  is converted to point-filtered `RFloat`, matching the precision class of the
  upstream Vivify v1.0.3 fix for issue #9 (`aaebdb1`, released in `44aaaaa`).
- **Android video:** all synchronized `VideoPlayer.time` writes now go through a
  single asynchronous seek state machine. One seek is issued, `seekCompleted`
  and `frameReady` are observed, and playback resumes only after the requested
  frame is actually ready. Requests arriving during a seek are coalesced to the
  newest target instead of queueing more MediaCodec seeks. Menu warmup no longer
  performs a redundant t=0 seek.
- **Vilar late-note geometry:** the runtime no longer replaces
  `Vilar/GeometryDissolve*` with unrelated Beat Saber shaders. The authored
  material is preserved, while stock note geometry remains visible behind it on
  Quest as a readability guard. A literal Multiview `gl_Layer` /
  `SV_RenderTargetArrayIndex` repair cannot be made from this source archive
  because the map's Android shader bundle/compiled Vilar variant is not present.
- **Validation:** the static validator now rejects the removed manual stereo
  path, enforces the single synchronized `set_time()` call site, checks the
  VideoPlayer callback bridge, verifies RFloat secondary depth, and verifies
  that Vilar shader substitution stays removed.

## CustomModels 1.2.1 / saber compatibility

- Vivify's replacement model stays on the physical Saber transform while the
  stock/custom visual root is tracked separately for hide/restore.
- Vivify's custom trail no longer follows another SaberTrail's movement buffer.
  It owns a `SaberMovementData` and samples its authored top/bottom endpoints in
  world space immediately before `SaberTrail::LateUpdate`, matching the proven
  CustomModels approach.
- The cloned `SaberTrailRenderer` is world-rooted so world-space vertices are not
  transformed by the saber hierarchy a second time (the ~10 m offset/exploded
  trail failure).
- Non-additive Vivify trail replacement rechecks foreign/custom trails every four
  frames so late CustomModels rebuilds are hidden quickly without stealing their
  lifecycle.
- Vivify's trail clone avoids CustomModels' global `Trail(Clone)` name hook and
  preserves existing MaterialPropertyBlock values.

## Aether / prefab animation

- Removed the previous note-prefab timing experiment that passed
  `NoteFloorMovement._beatTime` into the generic prefab synchronizer. That field
  is beat-domain data while the synchronizer is song-time/seconds-domain, so it
  could place normal-gameplay custom note Animators at invalid phases and make
  the Zen-vs-normal comparison worse.
- Synced Vivify Animators still use `AlwaysAnimate` so renderer visibility cannot
  pause authored environment animation.
- Prefab animation now uses a clock gate: one-to-three duplicate callback-song
  timestamps are treated as harmless Quest scheduler quantization, but a
  sustained practice/pre-roll stall freezes Animator/legacy Animation/particles
  at the exact catch-up pose until the authoritative song clock advances again.
  This specifically prevents scene-load time from advancing Aether's Drop
  animation ahead of the music in normal gameplay while Zen loads faster.
- Particle clock gating no longer writes the global 0x/1x song rate into
  `ParticleSystem.MainModule.simulationSpeed`. It captures the current authored
  value only when the song clock stops and restores it when the clock resumes.
  This preserves Aether's Animator curves (including the fast/slow arrow and
  ribbon bursts) while still freezing particles during pre-roll and pause.

## Embedded video playback

- Bundle preload still discovers embedded `VideoClip` dependencies and keeps one
  hidden decoder warm for later adoption by the live prefab.
- Persistent decoder proxies continue to support both `MaterialOverride` and
  authored `RenderTexture` output, including output rebinding when Android
  creates/recreates its external texture.
- **Seeking is now serialized.** `BeginVideoSeek` is the only synchronized
  `VideoPlayer::set_time()` call site. It pauses playback, enables frame-ready
  events, issues one seek, and waits for both Unity completion signals before
  allowing playback to continue.
- `seekCompleted`, `frameReady`, and `prepareCompleted` are bridged from
  `VideoPlayer` into the runtime. While a seek is in flight, a newer request is
  stored as one coalesced target; no second `set_time()` is issued until the
  current seek has produced its requested frame.
- Healthy persistent Quest decoders free-run at `playbackSpeed`; they are not
  continuously clock-chased with seeks. Real timeline jumps and bounded
  black/stalled-output recovery may request a new serialized seek.
- Fresh menu warmup decoders no longer seek to t=0 after `Prepare`; they simply
  start decoding from their initial position, avoiding an unnecessary Android
  seek operation.
- Looping clips continue to use clip-local target time, and first-frame/output
  checks continue to require real decoded output rather than a non-null external
  texture shell.

## Mid-render / secondary-camera transport

- Removed the explicit Quest per-eye helper-camera loop (`Camera.Render()` twice,
  injected stereo matrices, mono eye targets, then array packing). Upstream
  Vivify warns that this path does not reliably write the right eye.
- `CreateCamera` helpers are again **targetless and enabled**. Unity XR performs
  their normal stereo render pass and Vivify captures the result from
  `OnRenderImage` instead of fabricating an XR pass from native code.
- In texture-array stereo modes the published color/depth resources keep the
  two-slice `Tex2DArray` contract expected by authored Vivify shaders. If Unity
  exposes a mono `OnRenderImage` source, the capture helper duplicates that
  coherent source rather than manually re-rendering the camera per eye.
- Secondary depth is copied into owned, point-filtered `RFloat` textures instead
  of leaving the authored effects dependent on a transient/low-precision depth
  surface. If Unity supplies a depth array, each source slice is converted and
  published separately.
- Secondary-camera culling isolation remains intact, and Quest Multiview does
  not overwrite XR-owned per-eye matrices with the main camera's generic mono
  matrices.
- No map-name special case is used.

## XR shader-variant ownership / Flux / Aether / Wireframe

- Unity/XR remains the owner of `STEREO_MULTIVIEW_ON`,
  `STEREO_INSTANCING_ON`, and `UNITY_SINGLE_PASS_STEREO` for ordinary authored
  materials. The only retained narrow compatibility recipe is the previously
  tested Mawntee wireframe case.
- `Vilar/GeometryDissolve` and `Vilar/GeometryDissolveOutline` are no longer
  replaced with `BeatSaber/Note`, `BeatSaber/Unlit Glow`, Standard, or another
  guessed substitute merely because the runtime is Quest.
- The authored Vilar material is left present so a corrected Android shader
  variant can work without another native-code change. Until that compiled
  shader is available, note replacement deliberately keeps the stock gameplay
  note renderer behind the Vilar replacement so a zero-pixel Multiview geometry
  pass cannot make the note unreadable.
- This is a guard, not a claim that the geometry shader itself is repaired. A
  true Quest Multiview fix belongs in the Vilar geometry stage and needs the map
  Android asset/shader variant.

## Camera background / black-void compatibility

- Removed the incorrect Quest-only rule that implicitly changed the main camera
  to `Skybox` whenever `SetRenderingSettings.skybox` was authored. Desktop Vivify
  keeps render settings and camera clear flags independent.
- `SetCameraProperty.backgroundColor` is now authoritative on the main camera and
  is reasserted during runtime updates so another Quest/Beat Saber camera component
  cannot reset an authored `SolidColor` background back to black.
- Camera property parsing accepts both normal and legacy underscore field names,
  plus both documented flat RGBA and single nested ColorArray forms.

## Preserved fixes

- Persistent always-active Quest video decoder proxy.
- Flux-specific visibility/sorting, negative-time, and startup-timing
  experiments remain removed.
