# Vivify Quest 0.6.14 compatibility patch

This standalone source keeps the persistent video-decoder fix and keeps the old
Flux-specific visibility/sorting workarounds removed.

## CustomModels 1.2.1 / saber compatibility

- Vivify's replacement model stays on the physical Saber transform while the
  stock/custom visual root is tracked separately for hide/restore.
- Vivify's custom trail no longer follows another SaberTrail's movement buffer.
  It owns a `SaberMovementData` and samples its authored top/bottom endpoints in
  world space immediately before `SaberTrail::LateUpdate`, matching the proven
  CustomModels approach.
- The cloned `SaberTrailRenderer` is world-rooted so world-space vertices are not
  transformed by the saber hierarchy a second time (the ~10 m offset/exploded
  trail failure).
- Non-additive Vivify trail replacement rechecks foreign/custom trails every four
  frames so late CustomModels rebuilds are hidden quickly without stealing their
  lifecycle.
- Vivify's trail clone avoids CustomModels' global `Trail(Clone)` name hook and
  preserves existing MaterialPropertyBlock values.

## Aether / prefab animation

- Replacement-note prefabs now register their animation timeline from
  `NoteMovement._floorMovement._beatTime`, matching desktop Vivify when an active
  note prefab is assigned/swapped mid-flight.
- Synced Vivify Animators use `AlwaysAnimate` so renderer visibility/occlusion in
  normal gameplay cannot pause an authored environment animation while Zen mode
  happens to work.
- Duplicate Quest audio-clock samples are not treated as a pause; actual
  `AudioTimeSyncController.timeScale` drives synced playback.

## Geometry stereo

- The misleading global per-eye Blit toggle remains removed. Blit compatibility
  is not used as a geometry-shader fix.
- The exact Aether shader `Mawntee/Beat Saber Wireframe 3D-Noise` gets a targeted
  runtime stereo recipe: Multiview keyword off, stereo-instancing variant on.
  Its source already transfers Unity stereo data through the geometry stage, so
  this selects the variant whose stereo output can carry the render-target array
  layer. Other geometry shaders keep their authored/native XR variant.
- TriangleExplosion-style shaders with an explicit Multiview
  `SV_RenderTargetArrayIndex` patch are left untouched.

## Black-background / skybox compatibility

- When Vivify authors a skybox material, the main camera is switched to
  `CameraClearFlags.Skybox` unless the map explicitly authored another clear flag.
- The previous skybox-compatible shader fallback remains in place.

## Preserved fixes

- Persistent always-active Quest video decoder proxy.
- Flux-specific AlwaysVisibleQuad / forced-sorting / negative-time / startup
  timing hacks remain removed.
