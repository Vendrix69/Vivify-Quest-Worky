# Vivify Quest 0.6.14 compatibility patch

This standalone source keeps the persistent video decoder fix and removes the
old map-specific Flux visibility/sorting workarounds.

## CustomModels 1.2.1 / saber compatibility

- Separates the stable Saber replacement parent from the visual root used to
  discover stock and external custom-saber renderers, matching desktop Vivify's
  hierarchy semantics.
- Refreshes those roots when another saber mod reparents/rebuilds the hierarchy.
- Defers the first Quest saber replacement and retries during the short startup
  window instead of racing CustomModels while it creates its saber hierarchy.
- Hides only renderers for non-additive replacement; external trail components
  remain owned by their original mod and Vivify's lifecycle hooks only intercept
  Vivify-created trails.
- Avoids CustomModels 1.2.1's global `Trail(Clone)` Awake special case when
  cloning Vivify's trail renderer.
- Keeps Vivify's cloned SaberTrailRenderer under the same source trail transform
  space as Beat Saber, preventing the coordinate-space trail explosion.
- Merges MaterialPropertyBlock values instead of replacing values installed by
  another mod.

## Aether / prefab animation timing

Quest can return the same AudioTimeSyncController song time across multiple
render frames under heavy gameplay. That is not a pause. Synced prefab Animator,
legacy Animation and ParticleSystem playback now follows the actual timeScale and
only stops for a real pause/unavailable audio controller. This is generic and has
no Aether/map-name condition.

## Stereo compatibility

The mod settings page contains `Force per-eye blits (experimental)`. It can force
legacy fullscreen material blits to render once into eye 0 and once into eye 1
while setting `_StereoActiveEye`.

This cannot manufacture missing compiled shader bytecode. Geometry shaders like
the supplied TriangleExplosion example still need a Quest stereo-capable shader
variant that emits both eyes and writes the correct `SV_RenderTargetArrayIndex`.
