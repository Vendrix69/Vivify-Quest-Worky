# Commit 110 - Heartbeat first-frame patience + declared-texture 2D bridge

- Heartbeat/200% random-timeline: detects when a synchronized prefab has multiple genuinely independent persistent decoder leaders. At >=175% historical starts those decoders are allowed to finish their original MediaCodec seek instead of being pause/seek/play restarted every output-recovery backoff while no first frame exists yet.
- Multi-decoder high-speed starts also skip Commit 109's one measured second compensated seek. Once the first frame appears, the existing 3.0x large-drift burst and bidirectional servo remain responsible for convergence. Single-decoder maps such as the current 3 Big Shots path keep Commit 109 startup/recovery behavior unchanged.
- 3 Big Shots frozen-screen glitch: CreateScreenTexture captures remain stereo arrays internally on Quest so both eyes are preserved, but any legacy material that references a declared screen texture now receives a true per-eye 2D copy of that global while its pass executes. This matches desktop Vivify, where declared screen textures are per-eye RenderTexture instances, and fixes sampler2D shaders such as Hidden/Old sampling XR arrays as black.
- The existing Luminescent real-2D `_MainTex` bridge remains unchanged, so the fixed saber mirroring is preserved. The separate blackout before the final pixelization is **not** claimed fixed here; Commit 110 deliberately leaves that unresolved transition alone rather than adding another speculative shader/timing workaround.
- The YOU/Luminescent material-animation boundary ownership fix from Commit 108 is preserved. No map names, beat numbers, or external-time VideoPlayer mode are used at runtime.

# Commit 109 compile fix - real legacy-eye bridge + authoritative 200% video clock

- Keeps Commit 108 material-animation ownership: YOU's completed rainbow/star animation stays dead while Luminescent's still-running brightness fade can resume underneath one-frame flashes.
- Compile fix: bs-cordl 4008 exposes only the 2-argument `CommandBuffer::CopyTexture` wrapper. Commit 109 now selects the XR source eye through `RenderTargetIdentifier::m_DepthSlice` before calling that supported wrapper; behavior is otherwise unchanged.
- Replaces Commit 107's incomplete legacy per-eye Blit. Selecting an array depth slice still handed `_MainTex` a texture-array object, which is invalid for Luminescent's Android `sampler2D` Glitch/Pixelate shaders. Commit 109 copies each XR array slice into a real 2D temporary RT, runs the legacy shader on that Tex2D, then writes the result back into the matching eye slice. This directly targets both the pre-Pixelate black pulse and mirrored sabers.
- 175%+ video now follows the same authoritative song-clock-derived rate already used by synced prefab animation instead of blindly trusting `AudioTimeSyncController.timeScale`. This targets Heartbeat/3 Big Shots being randomly early or late even when starting at beat 0 at 200%.
- A 175%+ random-timeline start gets at most one measured forward-biased compensated seek if Android reveals that the first seek landed more than 0.75 s behind on a previous GOP keyframe. After that, a low-cost bidirectional rate servo on the existing six-frame poll corrects both early and late drift.
- 100-150% video behavior is intentionally unchanged. No extra per-frame decoder polling was added, and the high-speed servo remains capped at 3.0x physical decoder rate.
- No map-name or beat-number special cases were added.

# Commit 108 - material animation boundary ownership (YOU + Luminescent)

- Keeps Commit 107's Luminescent legacy per-eye Blit compatibility path and Commit 106 video behavior unchanged.
- Restores the earlier YOU star ownership fix without reintroducing Luminescent's long blackout.
- A newer material-property event now retires only older animations whose authored endpoint is at or before the new event time. This covers YOU's `ambientflare` handoff at beat 111.25, where the completed `_Opacity -> 1` animation must not overwrite the same-beat `_Opacity = 0` event.
- Older animations that are still genuinely running past the new event remain alive and resume after the one-frame override. This preserves Luminescent's beat-452 -> 467 `_Bright` fade underneath the authored beat-453/454/455 flashes.
- The same boundary-ownership rule is used by both `SetMaterialProperty` and post-processing material-property animation. No map-name or beat-number runtime special cases were added.

# Commit 107 - Luminescent legacy fullscreen per-eye blit

- Based directly on Commit 106. Video synchronization, decoder sharing, warmup,
  output binding, and the hot-path cleanup are unchanged.
- Inspection of Luminescent's Android bundle shows the ending Glitch and Pixelate
  shaders still declare `_MainTex` as Tex2D / `sampler2D`, while Quest Multiview
  feeds the post-processing chain from a two-slice texture array.
- The shader families `nasafrasa/PostProcessing/FMS_Cat/Glitch` and
  `nasafrasa/PostProcessing/Pixelate` now use Vivify's existing per-eye depth-slice
  compatibility blit in texture-array stereo. The recipe is cached once when the
  Blit event is created; there is no per-frame shader-name lookup.
- This targets the short black pulse immediately before the ending pixelization
  and the mirrored/corrupted saber sampling during Pixelate. It does not change
  event timings or SetMaterialProperty lifetime behavior.
- No map-name, beat-number, or Luminescent-specific event special case is used.
  Commit 101's earlier long-blackout material overlap fix remains intact.

# Commit 106 - video hot-path cleanup

- Based directly on Commit 105. Synchronization policy and the >=175% measured
  large-drift rescue are unchanged; this commit is deliberately a structural/CPU
  cleanup rather than another catch-up tuning experiment.
- Prepared state is now cached after Android reports Prepare success. Vivify never
  calls Stop() or replaces the source of these synchronized decoders, so repeatedly
  crossing IL2CPP for get_isPrepared() every render frame was redundant.
- Play/Pause ownership is mirrored locally and reconciled only when the existing
  shared video clock poll samples the decoder. Startup/recovery still polls while
  real output is being established.
- Persistent drift/heartbeat logic reuses one sampled decoder time instead of
  asking VideoPlayer.time multiple times in the same poll. Playback-rate writes
  are centralized through one helper, preserving the previous meaningful-change
  guard and retry behavior.
- MaterialOverride shared followers no longer fetch the leader texture every render
  frame. They sample on first bind, visibility transition, or the six-frame clock
  cadence. RenderTexture followers still copy every presented frame as required.
- In the main synchronization region, direct native-state call sites drop from
  1 prepared / 9 playing / 5 time reads to 0 / 2 / 2 respectively; the remaining
  reads are the poll/recovery points rather than unconditional branch-local reads.
- No Luminescent/post-processing changes. Commit 104 remains reverted.

# Commit 105 - targeted 200% large-drift startup burst

- Based directly on Commit 103. Commit 104 adaptive-rate changes are not present.
- Keeps Commit 103 light persistent catch-up for normal starts and <=150% practice.
- At >=175% practice only, a measured lag worse than 1.0s enables a short
  large-drift tier capped at 3.0x absolute VideoPlayer speed.
- The tier exits once lag is within 0.55s, then Commit 103's light catch-up
  finishes convergence. This specifically addresses 3 Big Shots random-timeline
  starts at 200%, where +0.35x could require around ten seconds to erase a
  multi-second preceding-keyframe landing.
- No additional seeks, no per-frame decoder polling, no timeout, and no changes
  to decoder sharing/prewarm/output binding.
- Luminescent behavior is intentionally unchanged from Commit 103 in this build;
  the remaining pre-pixelization blackout and mirrored saber capture are being
  investigated separately.

# Commit 103 test build

- Recording/video sync: removes the fixed historical catch-up timeout. Heartbeat and 3 Big Shots can stay in lightweight convergence for as long as the decoder is actually behind instead of giving up after a few seconds under recorder load.
- Catch-up cost is reduced: <=1.25x practice uses only +0.50x temporary headroom, >1.25x uses +0.35x, and physical VideoPlayer speed is capped at 2.25x. The old +2x turbo is gone.
- Catch-up health is sampled on the existing six-frame video cadence instead of every render frame once output exists. First-frame/startup recovery still samples every frame until a real texture is available.
- Persistent decoders now self-heal later recorder-induced drift: if a healthy decoder falls more than 350 ms behind, it re-arms rate-only catch-up without a seek. Three consecutive in-tolerance samples are required before returning to the authored rate.
- Luminescent Commit 101 material-property fix, decoder sharing, prewarm, output binding, and aggressive-recovery limits are retained unchanged.

# Commit 102 test build

- Video/Heartbeat: restores historical/custom-timeline convergence above 1.25x practice speed. Commit 100/101 ran the decoder at exactly the song rate above that threshold, so an Android seek that landed on an earlier keyframe could remain permanently desynced.
- High-speed catch-up is deliberately bounded instead of restoring the old +2x turbo: the decoder receives at most +0.75x temporary headroom and is capped at 2.5x physical playback speed. The existing five-second catch-up window and single-seek/decode-forward behavior are unchanged.
- Luminescent: Commit 101 SetMaterialProperty overlap fix is retained unchanged.
- No lifecycle, decoder-sharing, warmup, output-binding, or periodic reseek behavior is changed.

# Commit 100 test build

- Video: high practice speeds no longer receive the historical +2x decoder turbo. Above 1.25x, the physical VideoPlayer runs at exactly the requested practice rate, preventing Heartbeat from being driven at 3.5-4x while the song is only 1.5-2x.
- Luminescent/skybox: if bundle-wide shader repair previously replaced an unsupported custom sky material with a generic object shader, using that material as RenderSettings.skybox now re-contextualizes it into a supported Skybox/* shader family instead of accepting the earlier generic fallback.
- Preserves Light5 decoder sharing, visual-only audio-track disable, selected-level asset-cache handoff, first-launch memory reduction, and the previous camera lifecycle patch.

## 2026-09-17 Light5 combined test

- Includes the Light5 video/launch optimizations and the isolated Luminescent camera lifecycle parity fix.
- Video: explicit audio-track decode disable plus strict same-timeline RenderTexture decoder fan-out.
- Launch: reuse the already-loaded menu AssetBundle cache across GameplayPreparation instead of loading every asset twice.
- Luminescent: preserve main-camera original state across temporary Camera.main gaps and reapply authored state once when the same camera reappears.
- Retains Light4 decoder consolidation and Light1 warmup behavior; no additional resident warmers or v2-style lifecycle rewrite.

# Vivify Quest 0.6.14 compatibility patch

This standalone source keeps the confirmed Aether particle-clock fix and adds
bounded recovery for Android video decoders that previously needed a manual
pause/resume.

## CustomModels 1.2.1 / saber compatibility

- Vivify's replacement model stays on the physical Saber transform while the
  stock/custom visual root is tracked separately for hide/restore.
- Vivify's custom trail no longer follows another SaberTrail's movement buffer.
  It owns a `SaberMovementData` and samples its authored top/bottom endpoints in
  world space immediately before `SaberTrail::LateUpdate`, matching the proven
  CustomModels approach.
- The cloned `SaberTrailRenderer` is world-rooted so world-space vertices are not
  transformed by the saber hierarchy a second time (the ~10 m offset/exploded
  trail failure).
- Non-additive Vivify trail replacement rechecks foreign/custom trails every four
  frames so late CustomModels rebuilds are hidden quickly without stealing their
  lifecycle.
- Vivify's trail clone avoids CustomModels' global `Trail(Clone)` name hook and
  preserves existing MaterialPropertyBlock values.

## Aether / prefab animation

- Removed the previous note-prefab timing experiment that passed
  `NoteFloorMovement._beatTime` into the generic prefab synchronizer. That field
  is beat-domain data while the synchronizer is song-time/seconds-domain, so it
  could place normal-gameplay custom note Animators at invalid phases and make
  the Zen-vs-normal comparison worse.
- Synced Vivify Animators still use `AlwaysAnimate` so renderer visibility cannot
  pause authored environment animation.
- Prefab animation now uses a clock gate: one-to-three duplicate callback-song
  timestamps are treated as harmless Quest scheduler quantization, but a
  sustained practice/pre-roll stall freezes Animator/legacy Animation/particles
  at the exact catch-up pose until the authoritative song clock advances again.
  This specifically prevents scene-load time from advancing Aether's Drop
  animation ahead of the music in normal gameplay while Zen loads faster.
- Particle clock gating no longer writes the global 0x/1x song rate into
  `ParticleSystem.MainModule.simulationSpeed`. It captures the current authored
  value only when the song clock stops and restores it when the clock resumes.
  This preserves Aether's Animator curves (including the fast/slow arrow and
  ribbon bursts) while still freezing particles during pre-roll and pause.

## Embedded video playback

- Bundle preload now discovers embedded `VideoClip` dependencies through their
  prefab `VideoPlayer` components and starts one hidden API-only decoder per
  clip while the song is still selected in the menu. The warmed decoder is
  carried across gameplay preparation and adopted by the live prefab, moving
  the observed multi-second Quest MediaCodec startup out of the song.
- Persistent decoder proxies now support authored `RenderTexture` output in
  addition to `MaterialOverride`. The target texture is created and rebound at
  startup/first-frame/recovery boundaries. This is the output mode used by the
  late-or-never black video surface in the supplied recordings; the prior proxy
  eligibility test skipped it completely.
- Looping clips now seek and drift-check against clip-local time. The previous
  ever-growing song-relative target could repeatedly seek past the end after a
  loop and strand only those players until a pause/resume.
- Output readiness now requires a real decoded frame with valid dimensions;
  the non-null external-texture shell exposed before MediaCodec emits frame 0
  is no longer treated as healthy output.
- Slow decoders get a full startup window and bounded retries. The previous
  8-12 frame recovery cadence could restart the seek/play path before large
  clips produced their first frame.
- Prepared players that stop advancing receive the same local pause/seek/play
  kick that a whole-game pause supplied, without interrupting healthy videos.
- MaterialOverride is rebound when the first decoded frame becomes real, and
  ordinary decoder lag no longer causes 0.12-second seek storms.

## Mid-render / secondary-camera transport

- Quest Multiview secondary-camera outputs now follow the XR **consumer**
  contract instead of the incidental `OnRenderImage` source layout. A targetless
  helper camera may expose a mono color/depth source; Vivify now publishes the
  authored output as a two-slice Tex2DArray and duplicates a mono capture into
  both slices. This keeps Flux `_NotesOne`/`_NotesOne_Depth`-style pairs valid for
  sampler2DArray shaders.
- Restored array-preserving `CommandBuffer.CopyTexture` at Multiview
  `CurrentActive -> _midMainRT` and final `mainCurrent -> CameraTarget`
  boundaries. The prior all-`Blit` experiment preserved only the active layer
  and did not improve Flux.
- Every secondary camera restores outstanding temporary culling-layer mutations
  before applying its own whitelist/blacklist. This prevents a missed
  `OnPostRender` from stranding notes or environment renderers on Vivify's
  private culling layer.
- These are generic render-pipeline fixes; no 42-flux map-name special case was
  reintroduced.

## XR shader-variant ownership / Flux / Aether / Wireframe

- Removed all runtime forcing/clearing of Unity-owned `STEREO_MULTIVIEW_ON`,
  `STEREO_INSTANCING_ON`, and `UNITY_SINGLE_PASS_STEREO` material keywords.
- Quest Multiview, desktop SPI, and true MultiPass must use the shader variant
  selected by Unity for the active camera pass. Shared Vivify materials are no
  longer allowed to switch that XR contract when a prefab/note is repaired.
- Removed the failed Wireframe-specific "force instanced stereo" recipe. It was
  selecting an instanced shader variant while Quest was actually rendering a
  Multiview pass and could never synthesize the missing geometry-stage eye/layer
  routing.
- `ApplyStereoKeywords` now owns only Vivify's documented `MULTIPASS_ENABLED`
  compatibility keyword.
- This is a generic root-cause fix for Flux screen/depth texture chains and the
  Aether normal-vs-Zen shared-material divergence. A geometry shader whose
  Android Multiview bytecode itself lacks eye/layer emission still requires a
  real shader-source/compiled-program repair; TriangleExplosion remains the
  reference for that case.

## Camera background / black-void compatibility

- Removed the incorrect Quest-only rule that implicitly changed the main camera
  to `Skybox` whenever `SetRenderingSettings.skybox` was authored. Desktop Vivify
  keeps render settings and camera clear flags independent.
- `SetCameraProperty.backgroundColor` is now authoritative on the main camera and
  is reasserted during runtime updates so another Quest/Beat Saber camera component
  cannot reset an authored `SolidColor` background back to black.
- Camera property parsing accepts both normal and legacy underscore field names,
  plus both documented flat RGBA and single nested ColorArray forms.

## Preserved fixes

- Persistent always-active Quest video decoder proxy.
- Flux-specific visibility/sorting, negative-time, and startup-timing
  experiments remain removed.

## 2026-09-17 animation/lifecycle stability pass (0.6.14 preserved)

- Retains the working random-timeline Animator fix: historical catch-up advances monotonically instead of repeatedly Rebind/jumping backward and forward.
- Restores desktop Vivify's song-clock-derived Animator/legacy Animation speed (`song delta / Time.deltaTime`) behind the Quest stall gate, fixing the raw-timeScale divergence at high practice speeds.
- First custom-event preparation now catches up through the actual current song time rather than the callback event timestamp.
- Contains exceptions at CustomJSONData/SongCore/exported mod callback boundaries and fails closed if CustomJSONData or Tracks did not initialize successfully.
- Deferred scene-transition resets are escalated to pointer-free cleanup before they can touch wrappers from a scene Unity has already begun destroying.
- Pins installed/build-time Paper 4.8.0 and WebUtils 0.6.9 to the versions resolved by this source lockfile.
- No new decoder clock/reseek experiment is included; the failed ExternalTime/reseek approaches remain removed.

## 2026-09-17 video + Luminescent test patch

- Video practice-rate writes now wait until `VideoPlayer.isPrepared`, avoiding native rate mutation during Android MediaCodec construction.
- Historical/random video starts keep their single seek, then temporarily decode up to +2x faster (bounded to 4x and five wall-clock seconds) until `VideoPlayer.frame / frameRate` catches the requested song time. No periodic reseek loop or ExternalTime clock chasing was added.
- Quest main-camera `clearFlags` / `backgroundColor` are no longer reasserted every runtime frame. Stored Vivify camera state is applied when the authored property changes or when the gameplay camera changes, matching desktop controller semantics more closely and targeting Luminescent's blackout/fade regression.
- Flux, Teto, and the recording-only >170-180% decoder-throughput issue are intentionally untouched.

## 2026-09-17 V1 behavior-preserving video load pass

- Keeps the V1 gameplay video state machine, persistent decoder lifetime,
  historical catch-up behavior, `skipOnDrop`, startup/recovery timing, and
  authored video timing unchanged.
- Menu video warmers now pause as soon as they have produced their first real
  decoded frame. The prepared `VideoPlayer`/MediaCodec instance remains alive
  and is still adopted by gameplay exactly as before, but it no longer loops
  uselessly in the menu or alongside gameplay while waiting to be claimed.
- Healthy MaterialOverride/RenderTexture visibility checks no longer reassign
  the same native output target every render frame. The intentional Android
  target rebinds at startup, first decoded frame, reactivation, and recovery are
  preserved, and a lost/mismatched target is still repaired immediately.
- Reuses one sampled `VideoPlayer.isPlaying` value inside each health-poll pass
  instead of crossing the IL2CPP/native boundary several times for the same
  decoder state.
- Debug performance heartbeat now reports synchronized/playing video counts and
  retained/playing menu warmups so Quest logs can expose accidental decoder
  concurrency without changing normal behavior.

## 2026-09-17 Light4 same-stream decoder consolidation experiment

- Built directly from the proven Light1 behavior baseline; Light2 multi-warm and
  Light3 seek-state experiments are not carried forward.
- Multiple persistent Quest VideoPlayers are collapsed onto one physical decoder
  only after their authored timing is proven equivalent: same source clip/URL,
  same loop state, same authored playback rate, same render mode, and the same
  recovered absolute video start time.
- MaterialOverride followers receive the leader VideoPlayer's external texture
  through a preserved MaterialPropertyBlock, so separate screens can display the
  same decoded frame without separate MediaCodec instances or an intermediate
  RenderTexture/Graphics.Blit copy.
- RenderTexture players are consolidated only when they already target the exact
  same RenderTexture. Different RenderTexture targets remain independent in this
  pass to avoid adding GPU copies or changing authored render semantics.
- Historical/random starts consolidate equivalent players before calling
  VideoPlayer.Prepare, preventing redundant MediaCodec reservation in the exact
  heavy-start path Heartbeat stresses. Normal starts consolidate as soon as the
  authored VideoPlayer activation origins have latched.
- Shared followers never issue Play/Pause/Seek/playbackSpeed operations against
  the common decoder. One leader owns the decoder clock; followers only consume
  its texture/output.
- No extra warmers, hidden-proxy pausing, skipOnDrop changes, ExternalTime clock,
  strict seekCompleted gating, resolution/FPS reduction, or map-name special
  cases were added.

## 2026-09-18 Commit 101 — lighter video hot path + Luminescent fade parity

- Keeps Light5 decoder sharing, menu warmup parking, selected-bundle cache handoff,
  disabled embedded video audio decode, startup/recovery behavior, seek logic, and
  Commit 100's high-practice-speed cap unchanged. No new seek/reseek/state-machine
  behavior is introduced.
- Reduces steady-state VideoPlayer bridge work without changing sync decisions:
  render mode, material property id, loop state, and positive prepared clip length
  are cached; each physical leader samples `isPrepared` once per runtime frame and
  reuses the result through normalization/health checks; already-sampled
  `isPlaying` state is reused in recovery branches.
- Shared followers reuse the leader texture snapshot already sampled for that
  render frame instead of issuing a second `VideoPlayer.get_texture()` bridge call.
  Followers that alias the leader's exact RenderTexture cache that relationship and
  avoid re-querying the target RenderTexture every frame.
- Restores desktop Vivify SetMaterialProperty overlap semantics. Older animated
  material-property coroutines are no longer permanently deleted when a newer
  event touches the same property. Static/completed writes own exactly their
  current render frame, then older animations resume. A monotonic event sequence
  preserves correct ordering when multiple historical events are reconstructed
  in one frame.
- This directly fixes Luminescent's ending sequence: the 15-beat `sky6.mat`
  `_Bright` fade beginning at beat 452 now continues underneath the intentional
  beat 453/454/455 black/white/black flashes instead of being cancelled at beat
  453 and leaving the sky black until beat 467.
- ApplyPostProcessing material-property animation uses the same overlap semantics,
  matching desktop Vivify's shared SetMaterialProperty implementation.
- Removes Commit 100's unproven contextual skybox re-repair experiment; the
  uploaded Luminescent map demonstrated that the long blackout is property
  animation lifetime, not a skybox-family fallback failure.
