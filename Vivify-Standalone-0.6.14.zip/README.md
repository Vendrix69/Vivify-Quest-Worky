## Commit 114 test focus

Primary regression test: Heartbeat, 200% practice speed, random timeline, recording ON.

Expected behavior: Heartbeat should now enter the Commit-103-style multi-physical-decoder lane even if some screens are shared followers. 3 Big Shots should remain on its current single-physical-decoder path.

### Commit 115 video cold-start stabilization
Normal-start embedded video now resolves/consolidates duplicate timelines before decoder control, defers duplicate-source cold `Prepare()` calls until their timelines are known, and protects never-yet-decoded MediaCodec instances from short destructive recovery loops. This specifically targets first-run stalls/crashes that improve after restarting the same map.

### Commit 116: deterministic Quest video ownership and legacy overlap chaining
Menu video warmup now primes Android's clip/codec caches and then retires the warmup decoder. Gameplay always creates a fresh VideoPlayer with its final output surface configured before preparation, and owned codecs are stopped before destruction. Consecutive legacy sampler2D main-camera effects (not declared-screen-texture effects) stay in 2D per-eye ping-pong until a single XR writeback, avoiding the Luminescent Glitch/Pixelate overlap handoff.
