## Commit 114 test focus

Primary regression test: Heartbeat, 200% practice speed, random timeline, recording ON.

Expected behavior: Heartbeat should now enter the Commit-103-style multi-physical-decoder lane even if some screens are shared followers. 3 Big Shots should remain on its current single-physical-decoder path.

### Commit 115 video cold-start stabilization
Normal-start embedded video now resolves/consolidates duplicate timelines before decoder control, defers duplicate-source cold `Prepare()` calls until their timelines are known, and protects never-yet-decoded MediaCodec instances from short destructive recovery loops. This specifically targets first-run stalls/crashes that improve after restarting the same map.
