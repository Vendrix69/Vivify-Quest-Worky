# Vivify Quest 0.6.14 — Lumi + 3BS targeted render fix

This tree is based on the working `Lumi-3BS-SemanticFix` baseline.

It keeps the working 3 Big Shots frozen-frame repair and the current video/sync/lifecycle code, then adds only two narrowly verified rendering changes:

1. Luminescent's equal-priority legacy Glitch/Pixelate overlap is rendered in the same `Pixelate -> Glitch` order as the supplied no-blackout Vivify 0.5.5 reference path.
2. 3 Big Shots' verified legacy fullscreen text shaders (`Test/Crouch` and `Test/Screen On Screen`) use the existing per-eye Tex2D bridge with the obsolete mono eye-X compensation neutralized, while all native Multiview/split-eye effects stay native.

See `PATCH_NOTES.md` for the exact reasoning and preserved paths.
