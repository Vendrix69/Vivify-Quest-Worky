# Vivify Quest 0.6.14 — Q2Turbo / Pre-Lumi / Final 3BS Freeze

Diagnostic baseline combining the known-good Q2Turbo video behavior with the last postprocessing implementation from before Luminescent-specific compatibility changes, plus only the confirmed-working 3 Big Shots `Hidden/Old` freeze fix.

Test priorities:
1. Luminescent FPS during Pixelate/Glitch.
2. 3 Big Shots freeze-frame sections.
3. Q2/high-speed video sync behavior.

If Lumi performance is fixed here, the regression is isolated to the Commit107/109 Lumi per-eye compatibility path rather than the video or 3BS freeze logic.
