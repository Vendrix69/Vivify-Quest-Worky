# Vivify Quest 0.6.14 — Right Video + Final 3BS Freeze

This build uses the user's uploaded Q2 Turbo 3x baseline as the source of truth for video and Luminescent.

The only runtime change is the later confirmed-working 3 Big Shots `Hidden/Old` freeze-frame binding fix. Lumi stays on the uploaded baseline's non-chain Commit-109 Pixelate path.
