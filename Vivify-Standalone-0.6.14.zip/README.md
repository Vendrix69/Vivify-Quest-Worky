# Exact-map remaining render fix

This source tree is based on the working SemanticFix baseline. It adds only two scoped fixes derived from the user-supplied Luminescent and 3 Big Shots/Kitchen Gun maps: true mono-per-eye rendering for the two verified left-shifted overlay shaders, and a held-source tail for the final Luminescent Pixelate transition. See `PATCH_NOTES.md` for details.

> **Test baseline:** Q2-safe 3x video sync is frozen; this build only changes decoder teardown order, restores Lumi Pixelate after the failed overlap-chain experiment, and repairs 3 Big Shots Hidden/Old frozen-frame inputs.

# Vivify Quest 0.6.14 — Clean Baseline

This source tree is a reset to a small, testable foundation after several video experiments interacted badly.

The video implementation is Commit 103. Only already-proven non-video fixes are layered on top: Luminescent's per-eye sampler2D compatibility fix and restart/material-state hygiene.

The purpose of this build is stability and reproducibility. Do not treat it as a new attempt to solve every remaining visual/video issue at once.

Known remaining items to test/fix separately:
- 3 Big Shots: 200% random-timeline catch-up speed.
- Heartbeat: verify Commit 103 behavior still reproduces with the retained reset fixes.
- Luminescent: short blackout during the Glitch/Pixelate handoff remains.

## Current clean-baseline patch

This branch keeps Commit-103 video synchronization frozen. The only new runtime changes are ordered VideoPlayer teardown for crash safety and a per-eye 2D overlap chain for Luminescent legacy Glitch/Pixelate compositing. See `PATCH_NOTES.md`.


## Fast safe video catch-up
High-speed historical video catch-up keeps the Commit-103 state machine and raises only the >125% rate headroom from +0.35x to +0.50x (absolute cap 2.50x). No extra seeks, retries, decoder restarts, or per-frame polling were added.


## Q2 turbo catch-up experiment
High-speed historical video catch-up now uses up to +1.00x rate headroom with an absolute 3.00x decoder cap. The existing Quest VideoPlayer path already enables skipOnDrop, so intermediate presentation frames may be discarded while catching up. No additional seeks, retries, polling, restart logic, or decoder ownership changes were added. Low-speed catch-up remains unchanged.

### Current targeted fixes
3 Big Shots frozen-screen captures use persistent per-eye 2D snapshots for legacy `Hidden/Old`, and consecutive legacy fullscreen passes are separated by a GPU command-buffer boundary to make the Luminescent Glitch/Pixelate handoff deterministic on Quest Multiview. Video sync remains unchanged.
