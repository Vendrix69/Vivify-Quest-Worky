# Vivify Quest 0.6.14 — Pre-Lumi + Commit107 mirror + exact 3BS freeze

Test target:
1. Lumi should keep the recovered FPS while the mirror/orientation regression is corrected by the cheap Commit107 per-slice path.
2. Lumi blackout is expected to remain for now.
3. 3BS freeze should show matching, correctly ordered left/right freeze content using the corrected command-buffer temporary lifetime.
