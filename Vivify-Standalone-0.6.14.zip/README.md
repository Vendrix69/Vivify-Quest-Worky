# Vivify Quest 0.6.14 — SemanticFix + legacy fullscreen eye context

This source tree is based on the confirmed-working `Lumi-3BS-SemanticFix` baseline.

Preserved known-good behavior:
- 3 Big Shots `Hidden/Old` freeze fix (confirmed on-device).
- Commit-109 per-eye Tex2D source bridge / mirroring fix.
- Current video decoder ownership, recording-safe sync and 3x catch-up behavior.
- Animation/lifecycle/crash fixes already present in the baseline.

New targeted change:
- Desktop-style fullscreen shaders whose `_MainTex` is a normal Tex2D now run one physical eye at a time in the immediate `OnRenderImage` chain, with Unity's actual `unity_StereoEyeIndex` set to the matching eye.
- Unity XR stereo keywords are restored immediately after the legacy draw.
- `Hidden/Old` is excluded from this new path so the working 3BS freeze is not changed.
- Luminescent's authored Glitch + Pixelate overlap is restored; the old `glitchIsSuperseded` workaround is removed.

See `PATCH_NOTES.md` and `FULLSCREEN_EYE_CONTEXT.patch`.
