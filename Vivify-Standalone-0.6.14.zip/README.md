## Commit 114 test focus

Primary regression test: Heartbeat, 200% practice speed, random timeline, recording ON.

Expected behavior: Heartbeat should now enter the Commit-103-style multi-physical-decoder lane even if some screens are shared followers. 3 Big Shots should remain on its current single-physical-decoder path.
