# Lumi blackout + 3BS whiteout semantic fix

Baseline: `Vivify-Standalone-0.6.14(20260918-193720)`.

This build intentionally keeps the current video/sync/decoder/lifecycle code byte-for-byte unchanged.

## Luminescent

- Restores Commit-109's proven per-eye Tex2D bridge and normal main/scratch ping-pong path.
- Removes the failed fresh-XR-target and all-2D-chain experiments.
- When the exact legacy `FMS_Cat/Glitch` and `Pixelate` shaders overlap with the same priority/source/targets on XR, Pixelate supersedes Glitch for that overlap only. This prevents Pixelate from consuming the broken XR output of the legacy Glitch while leaving Pixelate itself on the known-good Commit-109 path.
- No beat/time hardcoding; matching is by shader family and authored routing.

## 3 Big Shots

- Keeps the authored `_Old1.._Old4` captures in the normal persistent stereo declared texture.
- `Hidden/Old` is rendered through the same Commit-109 per-eye `_MainTex` bridge.
- At render time, each `_Old*` stereo capture is copied to a genuine per-eye Tex2D using Commit-109's proven array-slice copy convention.
- A private `oldmat` clone is created for each eye and the Tex2D captures are bound directly to the material-local `_Old*` properties. This matters because the Android bundle serializes those material slots as null; shader globals cannot override a material-local texture property, which is why prior global-binding attempts remained white.
- Material-free `_Old*` one-shot captures receive one extra render-frame of lifetime so a callback arriving after the camera pass cannot leave the capture uninitialized.

## Explicitly untouched

- Video decoder ownership, historical catch-up, Q2 high-speed sync and recording-safe persistence.
- Animator/particle synchronization.
- Saber mirroring fix / Commit-109 per-eye bridge fundamentals.
- Geometry, water, camera, bloom and unrelated post-processing.
