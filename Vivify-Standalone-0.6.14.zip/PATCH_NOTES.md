# 2026-09-19 Luminescent 0.5.5 compositor restore

- Reference binary identified as Vivify 0.5.5 (`Vivify-Quest-Multiview-Blit-Fix-0.5.5`).
- Its working Pixelate path uses the simple main/scratch ping-pong compositor; there is no overlap-specific fresh-XR-target branch.
- Removes the 0.6.14 `useFreshLegacyMainTargets` special case for overlapping legacy main-camera passes. Glitch -> Pixelate now advances through `main <-> scratch` exactly like the old no-blackout compositor.
- Keeps the modern per-eye legacy compatibility bridge: each XR eye is extracted to a real Tex2D and the legacy shader result is written back to the matching XR slice. This is the mirroring fix and is intentionally retained.
- Keeps the latest sourceDepthSlice extraction experiment and 3 Big Shots `_Old*` work unchanged.
- Video sync / 3x catch-up / decoder lifecycle / animation logic are untouched.

# Explicit XR array-element CopyTexture fix

- Replaces every legacy command-buffer array-slice -> Tex2D transfer that previously encoded the eye in `RenderTargetIdentifier.m_DepthSlice` and then used the two-argument `CopyTexture` call.
- The legacy `_MainTex` bridges for Luminescent Glitch/Pixelate now use the explicit `CopyTexture(src, srcElement, srcMip, dst, dstElement, dstMip)` form with `srcElement = eye`.
- The `_Old1.._Old4` persistent Tex2D refreshes used by 3 Big Shots `Hidden/Old` use the same explicit source-element form.
- Temporary Tex2D copies of any other declared texture sampled by a legacy fullscreen material use the explicit source-element form as well.
- No video synchronization, decoder teardown, material animation, camera-property, or unrelated XR path changed.

# Same-frame Old capture + isolated legacy eye bridges

- 3 Big Shots `_Old*` per-eye snapshots are now copied **inside the same GPU command buffer immediately after the authored capture**. This fixes two holes in the previous attempt: `Hidden/Old` could consume the snapshot in the same frame before the CPU-side post-`ExecuteCommandBuffer` refresh, and mid-render capture command buffers never ran that CPU refresh at all.
- Legacy sampler2D post-processing now uses **independent Tex2D bridge RTs per eye and per material pass**. Glitch and Pixelate no longer reuse the same `_VivifyLegacyEyeSource` temporary ID during their overlap, avoiding mobile tiled-renderer alias/lifetime hazards while preserving the Commit-109 stereo fix.
- Video synchronization, Q2 3x catch-up, decoder teardown, material animation ownership, and unrelated rendering paths are unchanged.

# Q2 Turbo 3x — crash-order + 3BS freeze-frame + Pixelate restore

- Keeps the validated 3.0x high-speed catch-up controller unchanged.
- Restart/practice-speed teardown now stops and retires Vivify-owned VideoPlayer decoders before scene renderer/RenderTexture targets are destroyed.
- Removes the failed consecutive-legacy Lumi 2D-chain experiment so Pixelate returns to the proven Commit-109 per-eye path. The existing Lumi mirror fix remains; the old short overlap blackout is not claimed fixed in this build.
- 3 Big Shots `Hidden/Old` now explicitly receives `_Old*` CreateScreenTexture captures as real per-eye Tex2D globals. This does not depend on `Material.HasProperty`, because the legacy shader can consume those globals without exposing them in the material Properties block.
- No new seeks, retries, watchdogs, decoder topology rules, or sync branches.

# Clean Baseline — Crash Safety + Luminescent Handoff

This build stays on the validated Commit-103 video baseline. It does not change seek, catch-up, playback-rate, decoder-sharing, or warmup ownership behavior.

## Crash safety
- Vivify-owned gameplay VideoPlayers call `Stop()` immediately before their decoder GameObject is destroyed.
- Duplicate decoders retired during same-timeline sharing also stop before destruction.
- Menu warmup decoders stop before discarded warmup objects are destroyed.
- This targets the rare first-load / practice-speed-change MediaCodec teardown race without touching the ~3 second synchronization behavior.

## Luminescent blackout before Pixelate
- The existing Commit-109 per-eye Tex2D bridge remains unchanged for a single legacy fullscreen effect.
- When two or more legacy main-camera passes overlap (the authored Glitch -> Pixelate handoff at the end of Luminescent), Quest now keeps the entire chain in per-eye 2D ping-pong render targets.
- The final image is copied back to the XR texture-array eye only once after the chain.
- This avoids an XR-array write/read round trip between Glitch and Pixelate while preserving the already-fixed stereo orientation.

## Intentionally unchanged
- Commit-103 video synchronization and historical catch-up.
- 3 Big Shots declared `_Old*` screen-texture handling.
- YOU/reset-state hygiene.
- Teto/Aether/Flux-related rendering paths.


## Fast safe video catch-up
High-speed historical video catch-up keeps the Commit-103 state machine and raises only the >125% rate headroom from +0.35x to +0.50x (absolute cap 2.50x). No extra seeks, retries, decoder restarts, or per-frame polling were added.


## Q2 turbo catch-up experiment
High-speed historical video catch-up now uses up to +1.00x rate headroom with an absolute 3.00x decoder cap. The existing Quest VideoPlayer path already enables skipOnDrop, so intermediate presentation frames may be discarded while catching up. No additional seeks, retries, polling, restart logic, or decoder ownership changes were added. Low-speed catch-up remains unchanged.

## 3BS frozen-frame + Lumi overlap root fix
- 3 Big Shots `_Old*` captures now keep persistent per-eye Tex2D snapshots after the authored capture executes; `Hidden/Old` samples those directly instead of a transient XR-array slice copy.
- Consecutive legacy main-camera passes commit the first GPU command buffer before the next per-eye extraction. This preserves the proven per-eye Pixelate path while removing the Glitch -> Pixelate read-after-write hazard.
- Video synchronization/controller code is unchanged from the Q2 Turbo 3x baseline.

## 2026-09-19 XR source-slice Blit compatibility test

- Replaces every legacy XR-array -> Tex2D `CopyTexture` extraction used by
  Glitch, Pixelate, `Hidden/Old`, and `_Old1.._Old4` snapshots with Unity's
  `Blit_Identifier(... sourceDepthSlice, destDepthSlice)` path.
- Eye 0 explicitly samples XR layer 0 and eye 1 explicitly samples XR layer 1,
  matching the verified Quest Multiview convention from the supplied
  TriangleExplosion shader (`SV_RenderTargetArrayIndex = eye`).
- Legacy map shaders still receive ordinary Tex2D inputs; native stereo output
  and unrelated Vivify rendering remain unchanged.
- Full stereo-array -> stereo-array transfers still use CopyTexture; only the
  problematic array-slice -> Tex2D compatibility bridge changed.

# 2026-09-19 Combined Lumi blackout + 3BS whiteout fix

This is the combined rendering fix built from the latest 0.6.14 Q2 Turbo / stereo-fixed baseline.
Video synchronization, 3x decoder catch-up, decoder ownership/teardown, prefab animation, and unrelated rendering are unchanged.

## Luminescent
- The authored final sequence is a 5-beat `pp_glitch` pass (beat 467 -> 472) overlapped by `pp_pixelate` from beat 471.625 -> 472.125.
- Consecutive legacy Glitch/Pixelate main-camera passes now extract both XR eyes first, then execute the entire chain in ordinary per-eye Tex2D ping-pong targets.
- No intermediate Glitch result is written to the XR array and immediately re-read by Pixelate.
- Only the final per-eye result is written back to XR slice 0/1, retaining the Commit-109 mirroring fix.
- Main/scratch parity is preserved exactly: an even-length chain returns to the current target; an odd-length chain rotates once.

## 3 Big Shots
- `_Old1.._Old4` material-less captures now copy directly from the current XR source eye into persistent per-eye Tex2Ds, matching desktop Vivify's per-eye `RenderTextureHolder` semantics instead of array-copy-then-readback.
- `Hidden/Old` now renders with one temporary material clone per eye and binds the corresponding `_Old*` Tex2Ds as local material textures. This prevents a local default/white texture slot from overriding shader globals.
- `_Old*` one-shot capture events alone get a one-frame grace window so a callback that lands after the camera pass cannot miss the capture entirely. Ordinary one-frame Blits keep their previous lifetime.
- The XR-array declared texture is still populated for compatibility; the freeze shader no longer depends on reading it back to obtain its old frame.

## Desktop semantic alignment
- Material-less `CAMERA_TARGET -> CAMERA_TARGET` Blits are treated as no-ops, matching upstream Vivify.
- Equal-priority event insertion/render ordering remains unchanged and matches upstream Vivify.
## Compile fix

The Quest bs-cordl headers used by the GitHub build do not expose the two-argument `CommandBuffer::SetGlobalTexture(int, RenderTargetIdentifier)` overload. The three legacy post-processing bindings now use the existing two-argument `StringW(name)` overload instead. This addresses the `VivifyPostProcessing.cpp` build failure without changing the rendering logic.

