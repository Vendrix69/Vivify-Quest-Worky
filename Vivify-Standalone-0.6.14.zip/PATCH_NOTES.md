# Vivify 0.6.14 - Legacy fullscreen XR eye-context fix

Base: `Vivify-Standalone-0.6.14-Lumi-3BS-SemanticFix`

Purpose:
- Preserve the confirmed-working 3 Big Shots `Hidden/Old` freeze path exactly.
- Fix legacy fullscreen Tex2D effects whose shaders depend on Unity's built-in `unity_StereoEyeIndex`.
- Target the shared cause of 3BS fullscreen overlays appearing left-shifted and Luminescent's Glitch/Pixelate blackout.

Changes:
- Detect desktop-style fullscreen shaders by `_MainTex` texture dimension == `Tex2D` instead of a tiny shader-name allow-list.
- For `AfterMainEffect`/`OnRenderImage` legacy Tex2D blits on Quest Multiview:
  - flush already-recorded normal XR work first;
  - temporarily select the mono shader variant by disabling Unity stereo keywords;
  - extract XR slice 0/1 to a real Tex2D using the Commit-109 copy convention;
  - set the real Unity global `unity_StereoEyeIndex` to 0/1;
  - render into only the matching destination array slice;
  - restore all global/material XR keyword state immediately afterwards.
- Remove the Luminescent-specific `glitchIsSuperseded` workaround so the authored Glitch + Pixelate stack renders normally with the corrected eye context.
- `Hidden/Old` is explicitly excluded from the new immediate bridge and continues using the confirmed-working material-local `_Old1.._Old4` clone binding.
- Mid-render command buffers are unchanged by the new immediate eye-context mechanism.
- Video/decoder/practice-speed synchronization code is unchanged.

Validation:
- `python3 scripts/validate_standalone.py` passes.
- `python3 -m py_compile scripts/*.py` passes.
- Exact Beat Saber 1.40.8 `bs-cordl` API availability checked for:
  - `UnityEngine::Shader::SetGlobalInt`
  - `UnityEngine::Shader::DisableKeyword`
  - `UnityEngine::Shader::EnableKeyword`
  - `UnityEngine::Rendering::CommandBuffer::Clear`

No local Android/NDK link build was performed.
