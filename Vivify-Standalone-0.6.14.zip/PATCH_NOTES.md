# Q2Turbo pre-Lumi renderer + Commit107 mirror fix + exact 3BS freeze

Baseline: `Vivify-Standalone-0.6.14-Q2Turbo-PRELUMI-Exact3BSFreeze.zip`.

This build is intentionally narrow.

## Luminescent
- Keeps the pre-Commit109 renderer: no XR-slice -> Tex2D source bridge and no full-resolution per-eye copy temporaries for Glitch/Pixelate.
- Restores only Commit107's cheap legacy per-slice draw for the two known shaders:
  - `nasafrasa/PostProcessing/FMS_Cat/Glitch`
  - `nasafrasa/PostProcessing/Pixelate`
- Each effect is drawn to destination slice 0/1 with `_StereoActiveEye` 0/1.
- This targets the mirror/orientation regression without reintroducing Commit109's expensive copy bridge.
- The existing Lumi blackout is not addressed in this diagnostic build.

## 3 Big Shots
- Uses the corrected `Hidden/Old` freeze path from `PRELUMI-Exact3BSFreeze`.
- The main source-eye bridge is a CommandBuffer temporary (`_VivifyOldFrameEyeSource`) so eye 0/1 consume ordered command-buffer contents instead of sharing one externally allocated temporary.
- `_Old1.._Old4` remain material-local per-eye Tex2D bindings on cloned `oldmat` materials.
- Zero-duration `_Old*` captures retain the one-frame grace.

## Preserved
- Q2 Turbo/video/core/crash behavior is unchanged.
- No Commit109 Lumi Tex2D bridge.
- No Lumi overlap-chain, Glitch suppression, held-source, fullscreen-centering, or single-pass-mode experiments.
