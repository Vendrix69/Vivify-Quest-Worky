# Commit 114 — Physical Decoder Classification Fix

- Keeps Commit 112 restart-state hygiene and all Commit 111/113 post-processing behavior.
- Fixes the Heartbeat-vs-3BS high-speed controller split.
- The split now counts physical persistent decoder leaders after consolidation.
- Shared followers no longer force a multi-leader Heartbeat prefab into the 3BS/single-decoder high-speed lane.
- One physical leader keeps the newer 109 controller used successfully by 3 Big Shots.
- More than one physical leader uses the Commit-103-style Heartbeat controller lane.
- No Lumi/post-processing changes.

## Commit 115 - Cold-start topology barrier

- Fixed a first-run video startup race exposed by Commit 114: normal-start VideoPlayers now latch authored activation times for the whole prefab, consolidate equivalent timelines immediately on that same frame, and only then select the physical-decoder controller lane.
- Same-source duplicate players whose activation times are not known yet no longer all call `VideoPlayer.Prepare()` at level startup. One provisional source leader is allowed to warm while duplicate-source standbys wait until timeline discovery either consolidates them or proves they need an independent decoder.
- Menu-warmed decoders now preserve the fact that they already produced a real frame instead of unnecessarily re-priming the codec before the authored timeline starts.
- Cold persistent decoders that have never produced a real frame use a longer recovery barrier. Vivify will not repeatedly pause/seek/play a MediaCodec that is still allocating its first surface/frame; after a decoder has produced output once, the normal shorter recovery cadence returns.
- No post-processing, Lumi, `You`, 3BS old-frame/glitch, or reset-state logic was changed in this commit.

## Commit 116 - Fresh gameplay decoders + Lumi legacy-chain handoff

- Menu VideoPlayers are now cache primers only. After one real decoded frame they are explicitly `Stop()`ped and destroyed; gameplay never adopts an already-prepared `APIOnly` player or changes its MediaCodec output surface in-place.
- Gameplay persistent VideoPlayers are always created fresh with their final `MaterialOverride`/`RenderTexture` output configured before `Prepare()`.
- Vivify-owned persistent/duplicate VideoPlayers are explicitly `Stop()`ped before their decoder GameObjects are destroyed, preventing codec/surface teardown from racing the next run.
- Consecutive legacy sampler2D main-camera effects now remain in a per-eye Tex2D ping-pong chain and write back to XR once at the end. This targets Luminescent's exact Glitch+Pixelate overlap blackout while preserving the existing eye-orientation bridge.
- 3 Big Shots' declared `_Old*` screen-texture compatibility path is left unchanged; the new chain deliberately excludes effects that reference declared screen textures.
- Teto/Aether/You/reset-state behavior and the steady-state video drift controllers are unchanged.
