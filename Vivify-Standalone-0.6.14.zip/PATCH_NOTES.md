# 2026-09-19 final Lumi + 3BS fullscreen patch

Baseline: `Vivify-Standalone-0.6.14-Lumi-3BS-SemanticFix`.

This deliberately keeps the now-working 3 Big Shots `Hidden/Old` freeze path unchanged.
Video sync, decoder ownership, 3x Q2 catch-up, animation/particle sync, saber stereo fixes, geometry and unrelated post-processing are unchanged.

## Luminescent blackout

The actual map overlap is:

- beat 467: `nasafrasa/PostProcessing/FMS_Cat/Glitch`, duration 5 beats
- beat 471.625: `nasafrasa/PostProcessing/Pixelate`, duration 0.5 beats

Both use the same priority/source/target.

The supplied Vivify 0.5.5 reference binary has no blackout. Its compositor keeps chronological equal-priority storage and renders the list in reverse, which makes this overlap execute `Pixelate -> Glitch`.

The current 0.6.14 insertion policy reverses equal-priority storage, so the same overlap executes `Glitch -> Pixelate`.

This patch removes the failed "Pixelate supersedes Glitch" workaround and restores `Pixelate -> Glitch` only when the active effects are exactly the verified legacy Glitch/Pixelate shader families with identical priority/source/targets. All other effect ordering remains unchanged. There is no beat/time hardcode.

## 3 Big Shots fullscreen text centering

The Android GLES programs were decoded from the real 3 Big Shots bundle.

Two affected fullscreen shaders were verified:

- `Test/Crouch`
- `Test/Screen On Screen`

Their Multiview variants use the eye id for a legacy horizontal compensation:

- Crouch: `eye * _Offset` (`_Offset = -0.35` in the map)
- Screen On Screen: a hard-coded approximately `-0.3 * eye` X shift

That compensation is appropriate to the old combined-eye/double-wide style path, but on Quest Multiview each eye is already isolated in a texture-array slice, so the right-eye overlay is displaced left.

Only those two verified shader families are routed through the existing Commit-109 per-eye Tex2D bridge. The bridge still extracts the correct source eye, but the mono shader's `unity_StereoEyeIndex` is held at zero so the obsolete horizontal compensation is not applied.

Native Multiview shaders are otherwise untouched. In particular, 3 Big Shots' intentional different-content-per-eye section stays on `gl_ViewID` and is not flattened.

## Preserved 3 Big Shots freeze fix

`Hidden/Old` remains exactly on the SemanticFix path:

- persistent stereo `_Old1.._Old4` captures
- per-eye Tex2D extraction
- cloned `oldmat` materials
- material-local `_Old1.._Old4` bindings
- one extra render-frame grace for material-free `_Old*` capture events

Do not remove or generalize this path.
