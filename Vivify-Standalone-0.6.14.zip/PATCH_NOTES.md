# Commit 114 — Physical Decoder Classification Fix

- Keeps Commit 112 restart-state hygiene and all Commit 111/113 post-processing behavior.
- Fixes the Heartbeat-vs-3BS high-speed controller split.
- The split now counts physical persistent decoder leaders after consolidation.
- Shared followers no longer force a multi-leader Heartbeat prefab into the 3BS/single-decoder high-speed lane.
- One physical leader keeps the newer 109 controller used successfully by 3 Big Shots.
- More than one physical leader uses the Commit-103-style Heartbeat controller lane.
- No Lumi/post-processing changes.
