# Right Video + Final 3BS Freeze Baseline

Base: `Vivify-Standalone-0.6.14-Q2Turbo3x-CrashOrder-3BSFreeze-Pixelate(1).zip`

Kept exactly from the uploaded baseline:
- Q2 3.0x high-speed video catch-up and Commit-103 state-based convergence.
- Crash-order decoder teardown.
- Luminescent Commit-109 per-eye Tex2D bridge for Glitch/Pixelate.
- No consecutive legacy 2D-chain experiment.
- No Glitch-suppresses-Pixelate workaround.
- No held Pixelate tail or later Lumi ordering experiments.

Changed only for 3 Big Shots `Hidden/Old`:
- `_Old1.._Old4` are bound as material-local per-eye Tex2D inputs on per-eye material clones.
- Material-free `_Old*` capture events get one extra render-frame of grace.
- One-shot cleanup is monotonic (`frame < currentFrame`).

No video logic changes were made relative to the uploaded baseline.
