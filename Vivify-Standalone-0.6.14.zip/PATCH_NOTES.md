# Commit 114 — Physical Decoder Classification Fix

- Keeps Commit 112 restart-state hygiene and all Commit 111/113 post-processing behavior.
- Fixes the Heartbeat-vs-3BS high-speed controller split.
- The split now counts physical persistent decoder leaders after consolidation.
- Shared followers no longer force a multi-leader Heartbeat prefab into the 3BS/single-decoder high-speed lane.
- One physical leader keeps the newer 109 controller used successfully by 3 Big Shots.
- More than one physical leader uses the Commit-103-style Heartbeat controller lane.
- No Lumi/post-processing changes.

## Commit 115 - Cold-start topology barrier

- Fixed a first-run video startup race exposed by Commit 114: normal-start VideoPlayers now latch authored activation times for the whole prefab, consolidate equivalent timelines immediately on that same frame, and only then select the physical-decoder controller lane.
- Same-source duplicate players whose activation times are not known yet no longer all call `VideoPlayer.Prepare()` at level startup. One provisional source leader is allowed to warm while duplicate-source standbys wait until timeline discovery either consolidates them or proves they need an independent decoder.
- Menu-warmed decoders now preserve the fact that they already produced a real frame instead of unnecessarily re-priming the codec before the authored timeline starts.
- Cold persistent decoders that have never produced a real frame use a longer recovery barrier. Vivify will not repeatedly pause/seek/play a MediaCodec that is still allocating its first surface/frame; after a decoder has produced output once, the normal shorter recovery cadence returns.
- No post-processing, Lumi, `You`, 3BS old-frame/glitch, or reset-state logic was changed in this commit.
