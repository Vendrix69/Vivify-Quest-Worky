# Q2 Turbo 3x — crash-order + 3BS freeze-frame + Pixelate restore

- Keeps the validated 3.0x high-speed catch-up controller unchanged.
- Restart/practice-speed teardown now stops and retires Vivify-owned VideoPlayer decoders before scene renderer/RenderTexture targets are destroyed.
- Removes the failed consecutive-legacy Lumi 2D-chain experiment so Pixelate returns to the proven Commit-109 per-eye path. The existing Lumi mirror fix remains; the old short overlap blackout is not claimed fixed in this build.
- 3 Big Shots `Hidden/Old` now explicitly receives `_Old*` CreateScreenTexture captures as real per-eye Tex2D globals. This does not depend on `Material.HasProperty`, because the legacy shader can consume those globals without exposing them in the material Properties block.
- No new seeks, retries, watchdogs, decoder topology rules, or sync branches.

# Clean Baseline — Crash Safety + Luminescent Handoff

This build stays on the validated Commit-103 video baseline. It does not change seek, catch-up, playback-rate, decoder-sharing, or warmup ownership behavior.

## Crash safety
- Vivify-owned gameplay VideoPlayers call `Stop()` immediately before their decoder GameObject is destroyed.
- Duplicate decoders retired during same-timeline sharing also stop before destruction.
- Menu warmup decoders stop before discarded warmup objects are destroyed.
- This targets the rare first-load / practice-speed-change MediaCodec teardown race without touching the ~3 second synchronization behavior.

## Luminescent blackout before Pixelate
- The existing Commit-109 per-eye Tex2D bridge remains unchanged for a single legacy fullscreen effect.
- When two or more legacy main-camera passes overlap (the authored Glitch -> Pixelate handoff at the end of Luminescent), Quest now keeps the entire chain in per-eye 2D ping-pong render targets.
- The final image is copied back to the XR texture-array eye only once after the chain.
- This avoids an XR-array write/read round trip between Glitch and Pixelate while preserving the already-fixed stereo orientation.

## Intentionally unchanged
- Commit-103 video synchronization and historical catch-up.
- 3 Big Shots declared `_Old*` screen-texture handling.
- YOU/reset-state hygiene.
- Teto/Aether/Flux-related rendering paths.


## Fast safe video catch-up
High-speed historical video catch-up keeps the Commit-103 state machine and raises only the >125% rate headroom from +0.35x to +0.50x (absolute cap 2.50x). No extra seeks, retries, decoder restarts, or per-frame polling were added.


## Q2 turbo catch-up experiment
High-speed historical video catch-up now uses up to +1.00x rate headroom with an absolute 3.00x decoder cap. The existing Quest VideoPlayer path already enables skipOnDrop, so intermediate presentation frames may be discarded while catching up. No additional seeks, retries, polling, restart logic, or decoder ownership changes were added. Low-speed catch-up remains unchanged.
