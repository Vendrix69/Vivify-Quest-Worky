# 2026-09-19 Exact-map Lumi + 3BS remaining render fix

Base: **Vivify-Standalone-0.6.14-Lumi-3BS-SemanticFix** (the known-good baseline where 3BS freeze works, the intentional split-eye section works, and Luminescent Pixelate itself is non-laggy).

## 3 Big Shots / Kitchen Gun fullscreen centering

The supplied Android bundle was unpacked and its real GLES programs decoded. Two shaders contain desktop-multipass eye compensation that becomes visible on Quest Multiview:

- `Test/Crouch`: fragment math applies `_Offset * eye`; the map authors `_Offset = -0.35`.
- `Test/Screen On Screen`: fragment math contains a hard-coded horizontal `0.3 * eye` shift.

The intentional split effect is a separate eye-comparison shader and is **not** routed through this fix.

For only those two verified overlay shaders, Vivify now:

1. copies XR eye N to a real Tex2D,
2. sets the command buffer to `SinglePassStereoMode::None`,
3. runs the material into a real Tex2D output using its mono variant,
4. restores the active XR single-pass mode,
5. copies the finished output into XR slice N.

This is intentionally narrower than the failed global/mono-eye experiment: no global XR keyword mutation and no change to native split-eye shaders. The working `Hidden/Old` `_Old1..4` freeze binding code is byte-for-byte unchanged.

## Luminescent final blackout

The supplied map confirms the final sequence:

- Glitch begins at 467 and lasts 5 beats.
- Pixelate begins later at 471.625 and lasts 0.5 beat.
- At 472, while Pixelate still has a tail, the outgoing `sky6.mat` receives `_Bright = 0`.

The normal/repeated Pixelate hits earlier in the map start on the same beat as their Glitch and remain completely unchanged.

Only when Pixelate begins *inside an older, longer matching Glitch*, Vivify captures the stereo source at Pixelate start. Pixelate remains live while the Glitch is active; after that older Glitch reaches its endpoint, Pixelate uses the held pre-transition source for its remaining tail instead of sampling the newly blacked outgoing scene.

The existing SemanticFix rule where Pixelate supersedes the overlapping legacy Glitch is retained. No Glitch+Pixelate chaining, no fresh-target experiment, and no change to the normal Pixelate bridge.

## Preserved

- 3BS freezing / `Hidden/Old` material-local `_Old*` binding
- 3BS intentional split-eye section
- Commit-109 mirror fix
- SemanticFix non-laggy Pixelate path
- video sync / 3x catch-up / decoder lifecycle
- animation/property endpoint fixes
- secondary camera and other post-processing behavior

# Lumi blackout + 3BS whiteout semantic fix

Baseline: `Vivify-Standalone-0.6.14(20260918-193720)`.

This build intentionally keeps the current video/sync/decoder/lifecycle code byte-for-byte unchanged.

## Luminescent

- Restores Commit-109's proven per-eye Tex2D bridge and normal main/scratch ping-pong path.
- Removes the failed fresh-XR-target and all-2D-chain experiments.
- When the exact legacy `FMS_Cat/Glitch` and `Pixelate` shaders overlap with the same priority/source/targets on XR, Pixelate supersedes Glitch for that overlap only. This prevents Pixelate from consuming the broken XR output of the legacy Glitch while leaving Pixelate itself on the known-good Commit-109 path.
- No beat/time hardcoding; matching is by shader family and authored routing.

## 3 Big Shots

- Keeps the authored `_Old1.._Old4` captures in the normal persistent stereo declared texture.
- `Hidden/Old` is rendered through the same Commit-109 per-eye `_MainTex` bridge.
- At render time, each `_Old*` stereo capture is copied to a genuine per-eye Tex2D using Commit-109's proven array-slice copy convention.
- A private `oldmat` clone is created for each eye and the Tex2D captures are bound directly to the material-local `_Old*` properties. This matters because the Android bundle serializes those material slots as null; shader globals cannot override a material-local texture property, which is why prior global-binding attempts remained white.
- Material-free `_Old*` one-shot captures receive one extra render-frame of lifetime so a callback arriving after the camera pass cannot leave the capture uninitialized.

## Explicitly untouched

- Video decoder ownership, historical catch-up, Q2 high-speed sync and recording-safe persistence.
- Animator/particle synchronization.
- Saber mirroring fix / Commit-109 per-eye bridge fundamentals.
- Geometry, water, camera, bloom and unrelated post-processing.

## 2026-09-19 CI compile fix

- Removed the invalid public-style include `UnityEngine/Rendering/SinglePassStereoMode.hpp`.
- `VivifyRuntimeInternal.hpp` already includes generated `CommandBuffer.hpp`, whose bs-cordl implementation includes `zzzz__SinglePassStereoMode_def.hpp`, so the enum is already defined through the normal generated include chain.
- No rendering, stereo, Lumi, 3BS, video, or freeze behavior changed in this compile fix.
