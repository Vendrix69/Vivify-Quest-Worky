# Q2Turbo video + pre-Lumi renderer + final 3BS freeze

Base behavior kept from `Vivify-Standalone-0.6.14-Q2Turbo3x-CrashOrder-3BSFreeze-Pixelate`:
- Q2 high-speed video catch-up / 3.0x burst behavior
- decoder crash/order lifecycle handling
- all non-postprocessing runtime files from that build

Lumi rollback:
- `VivifyPostProcessing.cpp` was restored to Commit106 (`VideoHotPathCleanup`) before the Lumi-specific renderer work started.
- Commit107 forced legacy per-eye routing for Luminescent Glitch/Pixelate is absent.
- Commit109 XR-array-slice -> Tex2D bridge for Luminescent Glitch/Pixelate is absent.
- later overlap-chain / Glitch suppression / held-source / fullscreen-centering experiments are absent.

3 Big Shots only:
- `Hidden/Old` has a dedicated material-local per-eye freeze path.
- `_Old1.._Old4` are copied per eye to real Tex2D temporaries and bound on cloned materials.
- zero-duration `_Old*` capture events get one render-frame grace.
- this path is hard-gated by shader name before declared-texture inspection, so Lumi cannot pay its cost.

Expected regression tradeoff:
- This intentionally returns Lumi rendering behavior to pre-Commit107. Any visual issue that 107/109 fixed (for example mirrored legacy fullscreen content) may return. The purpose of this build is to test whether those Lumi compatibility paths caused the severe FPS regression.
