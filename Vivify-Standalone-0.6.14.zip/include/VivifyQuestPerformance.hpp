#pragma once

#include <cmath>
#include <cstddef>
#include <cstdint>

namespace Vivify {

// Pure, host-testable policy for retaining Unity command buffers. The runtime
// commits a key only after buffers were installed successfully. A generation,
// owner or render-graph change therefore forces one rebuild, while identical
// Quest frames reuse the already attached buffers.
class RenderCommandCacheGate {
public:
  bool Matches(std::uint64_t generation, std::uintptr_t owner,
               std::size_t signature) const noexcept {
    return _valid && _generation == generation && _owner == owner &&
           _signature == signature;
  }

  void Commit(std::uint64_t generation, std::uintptr_t owner,
              std::size_t signature) noexcept {
    _generation = generation;
    _owner = owner;
    _signature = signature;
    _valid = true;
  }

  void Invalidate() noexcept {
    _generation = 0;
    _owner = 0;
    _signature = 0;
    _valid = false;
  }

  bool Valid() const noexcept { return _valid; }

private:
  std::uint64_t _generation = 0;
  std::uintptr_t _owner = 0;
  std::size_t _signature = 0;
  bool _valid = false;
};

// All renderer roots are commonly discovered in the same frame. Giving each
// root a deterministic refresh offset prevents the old once-per-second burst
// where every GetComponentsInChildren scan landed on one Quest frame.
constexpr int StaggeredRefreshDelay(std::uintptr_t token,
                                    int minimumFrames = 45,
                                    int spreadFrames = 31) noexcept {
  if (minimumFrames < 1) minimumFrames = 1;
  if (spreadFrames < 1) return minimumFrames;
  std::uintptr_t mixed = token;
  mixed ^= mixed >> 17;
  mixed *= static_cast<std::uintptr_t>(0xed5ad4bbU);
  mixed ^= mixed >> 11;
  return minimumFrames + static_cast<int>(mixed % static_cast<std::uintptr_t>(spreadFrames));
}

inline bool MeaningfulRateChange(float previous, float current,
                                 float epsilon = 0.0005f) noexcept {
  return !std::isfinite(previous) || !std::isfinite(current) ||
         std::fabs(previous - current) > epsilon;
}

// AudioTimeSyncController::timeScale is the authored playback rate, but prefab
// animation must also respect the authoritative BeatmapCallbacks song clock.
// Quest can repeat a songTime for one or two rendered frames under load, so a
// single duplicate must NOT pulse every Animator between 0x and 1x. Practice
// pre-roll, however, can hold the callback clock completely still for many
// frames while timeScale remains 1.0. Let short scheduler duplicates pass, but
// freeze after a sustained stall and resume immediately when the song advances.
inline float ClockGatedSyncRate(bool pausedOrUnavailable, float previousSongTime,
                                float currentSongTime, float timeScale,
                                int& consecutiveStallFrames,
                                bool& clockHasAdvanced,
                                int stallThresholdFrames = 4,
                                float advanceEpsilon = 0.0001f) noexcept {
  if (pausedOrUnavailable || !std::isfinite(currentSongTime) ||
      !std::isfinite(timeScale) || timeScale <= 0.0f) {
    consecutiveStallFrames = 0;
    return 0.0f;
  }

  if (previousSongTime < 0.0f || !std::isfinite(previousSongTime)) {
    consecutiveStallFrames = 0;
    // On a fresh/practice start we have sampled the desired absolute pose, but
    // have not yet observed the song clock actually move. Keep that pose fixed
    // so scene-load time cannot advance the prefab ahead of the music.
    return clockHasAdvanced ? timeScale : 0.0f;
  }

  float const delta = currentSongTime - previousSongTime;
  if (delta > advanceEpsilon) {
    consecutiveStallFrames = 0;
    clockHasAdvanced = true;
    return timeScale;
  }
  if (delta < -advanceEpsilon) {
    // A seek/restart establishes a new timeline. Wait until that new clock is
    // observed advancing before free-running authored prefab animation again.
    consecutiveStallFrames = 0;
    clockHasAdvanced = false;
    return 0.0f;
  }

  consecutiveStallFrames++;
  int const threshold = stallThresholdFrames < 1 ? 1 : stallThresholdFrames;
  if (!clockHasAdvanced || consecutiveStallFrames >= threshold) return 0.0f;
  return timeScale;
}

// Kept as a small stateless helper for compatibility with older host tests and
// callers. Runtime prefab synchronization uses ClockGatedSyncRate above.
inline float StableSyncRate(bool pausedOrUnavailable, float previousSongTime,
                            float currentSongTime, float timeScale) noexcept {
  if (pausedOrUnavailable || !std::isfinite(currentSongTime) ||
      !std::isfinite(timeScale) || timeScale <= 0.0f) {
    return 0.0f;
  }
  if (previousSongTime >= 0.0f && currentSongTime <= previousSongTime) return 0.0f;
  return timeScale;
}

// Desktop Vivify derives prefab component speed from the authoritative song
// clock delta divided by Unity's frame delta. The Quest port used raw
// AudioTimeSyncController::timeScale instead, which diverges when the audio
// clock and Unity frame clock are not scaled identically (most visibly at high
// practice speeds). Preserve Quest's short-stall gate, then recover the desktop
// rate from the two clocks. Short duplicate songTime frames keep the last good
// rate instead of pulsing Animator speed to zero.
inline float SongDeltaSyncRate(float gatedRate, float previousSongTime,
                               float currentSongTime, float frameDeltaTime,
                               float previousAppliedRate) noexcept {
  if (!std::isfinite(gatedRate) || gatedRate <= 0.0f) return 0.0f;

  if (std::isfinite(previousSongTime) && previousSongTime >= 0.0f &&
      std::isfinite(currentSongTime)) {
    float const songDelta = currentSongTime - previousSongTime;
    if (songDelta > 0.0001f && std::isfinite(frameDeltaTime) &&
        frameDeltaTime > 0.00001f) {
      float const derived = songDelta / frameDeltaTime;
      // Ignore pathological one-frame jumps (seek/restart/scene hitch). The
      // absolute timeline catch-up path handles those; component free-running
      // should never receive an enormous transient speed.
      float const saneMaximum = std::fmax(4.0f, gatedRate * 2.5f);
      if (std::isfinite(derived) && derived > 0.0f && derived <= saneMaximum) {
        return derived;
      }
    } else if (std::fabs(songDelta) <= 0.0001f &&
               std::isfinite(previousAppliedRate) && previousAppliedRate > 0.0f) {
      return previousAppliedRate;
    }
  }
  return gatedRate;
}

// InstantiatePrefab event times are absolute song times. Unity Animator.Update
// expects time elapsed inside the newly created prefab, not the event's
// position in the song. Keeping this policy pure makes the normal-play and
// practice/catch-up behavior independently testable on the host.
inline float PrefabInitialElapsed(float currentSongTime,
                                  float eventStartSongTime) noexcept {
  if (!std::isfinite(currentSongTime) ||
      !std::isfinite(eventStartSongTime)) {
    return 0.0f;
  }
  return std::fmax(0.0f, currentSongTime - eventStartSongTime);
}

}  // namespace Vivify
