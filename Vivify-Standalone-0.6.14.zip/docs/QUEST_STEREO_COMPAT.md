# Quest geometry stereo compatibility

Vivify does **not** use a global per-eye Blit toggle as a geometry-shader fix.
Fullscreen Blit effects and mesh/geometry shaders are different rendering paths.

For geometry shaders, the right eye depends on the shader's compiled stereo
variant and on the geometry stage preserving the eye / render-target-array layer.
The supplied `TriangleExplosion` reference demonstrates the fully authored
Multiview solution: stereo data is carried through the vertex and geometry
structures and the geometry stage emits eye 0 and eye 1 with the correct
`SV_RenderTargetArrayIndex`.

At runtime Vivify therefore uses targeted shader recipes rather than globally
forcing every material. The known Aether shader
`Mawntee/Beat Saber Wireframe 3D-Noise` selects its stereo-instancing variant on
Quest, because its geometry source already transfers Unity stereo data but its
Multiview variant does not explicitly emit the array layer. Other recognized
geometry shaders keep their authored/native XR keywords untouched so patched
TriangleExplosion-style shaders are not broken by Vivify.

Vivify cannot synthesize a missing Android geometry-shader variant from arbitrary
compiled AssetBundle bytecode. If a shader has no stereo-capable Quest variant at
all, it still needs a source/bundle shader patch.
