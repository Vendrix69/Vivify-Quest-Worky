#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def text(rel):
    return (ROOT / rel).read_text(errors='replace')

def require(cond, message):
    if not cond:
        print(f'FAIL: {message}', file=sys.stderr)
        raise SystemExit(1)
    print(f'PASS: {message}')

obj = text('src/VivifyObjectPrefabs.cpp')
comp = text('src/VivifyComponents.cpp')
hooks = text('src/VivifyHooks.cpp')
core = text('src/VivifyCore.cpp')
perf = text('include/VivifyQuestPerformance.hpp')
post = text('src/VivifyPostProcessing.cpp')
main = text('src/main.cpp')

# No old one-root saber field/call remains.
require('target.parent' not in obj, 'no stale ActiveSaberVisual::parent call sites')
require('replacementParent' in obj and 'visualRoot' in obj,
        'saber replacement and original/custom visual roots are separated')
require('RefreshSaberRoots' in obj,
        'saber roots are refreshed after external custom-saber hierarchy rebuilds')
require('frame + 8' in obj and 'frame + 300' in obj,
        'Quest saber replacement waits for custom-saber construction and retries')
require('preexistingSaberRenderers' in obj and 'GetComponentsInChildren<UnityEngine::Renderer*>(true)' in obj,
        'non-additive Vivify saber snapshots sibling custom-saber renderers')
require('DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in obj and
        'DisableOriginalRenderers(std::vector<UnityEngine::Renderer*> const& renderers' in text('include/VivifyRuntimeInternal.hpp'),
        'snapshot vector has a matching DisableOriginalRenderers overload')
require('hideOriginalTrails' in obj and 'OwnsSaberTrail(trail)' in obj,
        'trail-only replacement hides external trails without claiming their lifecycle')

# CustomModels 1.2.1 collision + geometry safety.
require('VivifyTrailRendererPrefab' in comp,
        'Vivify trail clone avoids CustomModels Trail(Clone) Awake name hook')
require('SaberMovementData::New_ctor()' in comp and 'AddNewData' in comp and
        'TransformPoint(_topPos)' in comp and 'TransformPoint(_bottomPos)' in comp,
        'Vivify trail owns world-space movement samples instead of following CustomModels/stock trail data')
require('SetParent(nullptr, true)' in comp,
        'Vivify SaberTrailRenderer is world-rooted to avoid double saber transforms')
require('GetPropertyBlock(block)' in comp and 'SetPropertyBlock(block)' in comp,
        'trail color update merges existing MaterialPropertyBlock state')
require('VivifyOwnsSaberTrailLifecycle' in hooks and 'VivifyOwnsSaberTrailRendererLifecycle' in hooks,
        'SaberTrail enable/disable hooks are ownership scoped')

# Aether/practice regression: short callback-clock duplicates are tolerated,
# while sustained practice pre-roll stalls freeze the exact catch-up pose.
require('ClockGatedSyncRate' in perf and 'consecutiveStallFrames' in perf and
        'stallThresholdFrames = 4' in perf,
        'prefab sync distinguishes short Quest scheduler duplicates from sustained song-clock stalls')
require('_syncClockStallFrames' in core and '_syncClockHasAdvanced' in core and
        'ClockGatedSyncRate(' in core,
        'runtime carries song-clock stall state across synchronized prefab updates')
require('SongDeltaSyncRate' in perf and 'songDelta / frameDeltaTime' in perf and
        'UnityEngine::Time::get_deltaTime()' in core and 'SongDeltaSyncRate(' in core,
        'prefab Animator/legacy Animation rate follows desktop song-delta/frame-delta semantics')
require('animators[i]->set_speed(initialSyncSpeed);' in core and
        'SetParticleClockSuppressed(syncedParticle, initialSyncSpeed <= 0.0f);' in core,
        'practice catch-up pose is frozen immediately until the authoritative song clock advances')
require('struct SyncedParticleSystem' in text('include/VivifyTypes.hpp') and
        'authoredSimulationSpeed' in core and 'clockSuppressed' in core and
        'main.set_simulationSpeed(speed);' not in core,
        'particle clock gating preserves Animator-authored simulationSpeed curves')
require('NotePrefabTimelineStart' not in obj and 'noteTimelineStart' not in obj and
        'InstantiateReplacementPrefab(*info, replacementParent, replacement);' in obj,
        'note replacements never feed beat-domain NoteFloorMovement time into second-domain prefab sync')
require('AnimatorCullingMode::AlwaysAnimate' in core,
        'Vivify synced prefabs keep authored animation running when renderer visibility changes')

# Video proxy and automatic black/stalled-decoder recovery remain in this build.
require('VivifyVideoDecoder' in core and 'persistentDecoder' in core,
        'persistent video decoder proxy fix preserved')
asset_source = text('src/VivifyAssets.cpp')
runtime_header = text('include/VivifyRuntimeInternal.hpp')
types = text('include/VivifyTypes.hpp')
require('VideoRenderMode::RenderTexture' in core and
        'renderTextureTarget' in core and 'set_targetTexture' in core and
        'EnsureVideoOutputBinding(video)' in core,
        'RenderTexture videos use the persistent decoder and output-rebind path')
require('VivifyVideoWarmup' in asset_source and
        'VideoRenderMode::APIOnly' in asset_source and
        'StartBundleVideoWarmups();' in asset_source and
        'ClaimBundleVideoWarmup' in core,
        'embedded clips begin decoding during menu bundle preload')
require('ParkWarmedVideoPlayer' in asset_source and
        'if (ready) ParkWarmedVideoPlayer(warmup.player);' in asset_source and
        'ParkWarmedVideoPlayer(player);' in asset_source,
        'menu warmers stop decoding after their first real frame while remaining adoptable')
require('ResetMode::GameplayPreparation' in core and
        'ResetMode::GameplayPreparation' in text('src/VivifyEvents.cpp') and
        'preserveBundleVideoWarmups' in core and
        'BundleVideoWarmup' in runtime_header,
        'menu-warmed decoders survive the gameplay preparation reset')
require('preparePending' in core and 'kVideoPrepareWatchdogFrames' in core and
        'nextPrepareRetryFrame = frame + kVideoPrepareWatchdogFrames' in core and
        'nextPrepareRetryFrame = frame + 120' not in core,
        'Android Prepare is allowed to finish instead of being restarted every two seconds')
require('HasDecodedVideoOutput' in core and 'player->get_frame()' in core and
        'player->get_width() > 0' in core and 'player->get_height() > 0' in core and
        'return player->get_width() > 0 && player->get_height() > 0;' in core,
        'Quest video health accepts a valid external texture even when VideoPlayer.frame remains -1')
require('playbackStartKnown' in core and 'playbackStartSongTime' in core and
        'firstActiveObservedSongTime' in core,
        'video time-zero follows the authored VideoPlayer GameObject activation rather than prefab creation')
require('kHistoricalVideoProbeMaxSamples = 512' in core and
        'kHistoricalVideoProbeRefineSteps' not in core and
        'previousSample = sampleTime' in core and
        'animators[i]->Update(delta)' in core and
        'playbackStartSongTime = eventStartSongTime + activationOffset' in core,
        'random/practice Animator catch-up is bounded and monotonic with one absolute video start origin')
require('forwardJumpTolerance' in core and 'expectedForwardAdvance' in core and
        'UnityEngine::Time::get_unscaledDeltaTime()' in core,
        'timeline-jump detection scales with practice speed and frame time')
require('video.lastAppliedPlaybackSpeed' in core and
        'vp->set_playbackSpeed(requestedVideoRate)' in core and
        core.find('vp->set_playbackSpeed(requestedVideoRate)') > core.find('if (!decoderPrepared)'),
        'playback speed is applied independently only after VideoPlayer preparation')
require('historicalCatchupActive' in core and
        'HistoricalVideoRate(playbackSpeed)' in core and
        'DecodedVideoTime(vp, decodedFrame)' in core and
        'without another seek' in core,
        'historical Android video seeks use bounded decode-forward catch-up rather than reseek chasing')
require('kHistoricalVideoFullBoostMaxPracticeRate = 1.25f' in core and
        'kHistoricalVideoCatchupExtraRate = 0.50f' in core and
        'kHistoricalVideoHighSpeedCatchupExtraRate = 1.00f' in core and
        'kHistoricalVideoCatchupMaxRate = 3.00f' in core and
        'kHistoricalVideoCatchupExtraRate = 0.50f' in core and
        'set_skipOnDrop(true)' in core and
        'HistoricalVideoRate(playbackSpeed)' in core,
        'high-speed historical starts use skip-on-drop 3x catch-up without changing low-speed headroom')
require('kHistoricalVideoCatchupStablePolls = 3' in core and
        'kHistoricalVideoCatchupRearmDriftSeconds = 0.35f' in core and
        'historicalCatchupStablePolls' in core and
        'persistent video fell behind; rearming light catch-up' in core,
        'persistent video convergence is state-based and can re-arm after recorder-induced drift')
require('if (video.hasProducedTexture && !pollVideoClock) continue;' in core,
        'healthy and catch-up video clocks share the low-cost cadence instead of polling every render frame')
require('kHistoricalVideoCatchupMaxWallSeconds' not in core,
        'historical video catch-up no longer gives up on a fixed wall-clock timeout')
require('kVideoAggressiveRecoveryMaxRate = 3.0f' in core and
        'playbackSpeed <= kVideoAggressiveRecoveryMaxRate' in core,
        'extreme practice speeds cannot enter aggressive seek/stall recovery loops')
require('Healthy persistent Quest decoders free-run' in core and
        'Repeated set_time() calls' in core,
        'healthy MaterialOverride/RenderTexture decoders free-run after their controlled startup seek')
require('boundTarget != target' in core and
        'boundTarget != video.materialTarget' in core,
        'healthy video output visibility checks avoid redundant same-target native rebinds')
require('ConsolidateEquivalentVideoDecoders' in core and
        'sharedDecoderFollower' in core and
        'SameAuthoredVideoSource' in core and
        'playbackStartSongTime - right.playbackStartSongTime' in core and
        'MakeSharedVideoFollower' in core and
        'block->SetTexture(propertyId, currentTexture);' in core and
        'Never Play/Pause/Seek/rate-change a shared player from a follower' in core,
        'equivalent same-timeline video screens share one physical Quest decoder')
require('if (video.sharedDecoderFollower || !IsManagedAlive(video.player)) continue;' in core and
        'video.player->Prepare();' in core and
        core.find('ConsolidateEquivalentVideoDecoders(synced);') < core.find('video.player->Prepare();'),
        'historical duplicate decoders are consolidated before MediaCodec Prepare')
require('set_externalReferenceTime' not in core and
        'VideoTimeReference::ExternalTime' not in core,
        'failed ExternalTime clock-chasing experiment remains removed')
require('NormalizeVideoTime' in core and 'std::fmod' in core and
        'video.looping' in core and 'video.cachedLength' in core,
        'looping videos seek against clip-local time using cached prepared metadata')
require('renderModeValue' in types and 'targetMaterialPropertyId' in types and
        'video.renderModeValue' in core and 'video.targetMaterialPropertyId' in core,
        'video output mode/property metadata is cached instead of rediscovered through IL2CPP every frame')
require('bool const decoderPrepared = vp->get_isPrepared();' in core and
        'HasDecodedVideoOutput(vp, decoderPrepared, decodedFrame)' in core and
        'CachePreparedVideoLength(video, decoderPrepared)' in core,
        'each physical decoder reuses one prepared-state sample and cached clip length in hot paths')
require('sharedRenderTargetAlias' in types and
        'follower.sharedRenderTargetAlias =' in core and
        'BindSharedVideoFollowerOutput(video, currentTexture)' in core and
        'if (video.sharedRenderTargetAlias) return true;' in core,
        'shared followers reuse the sampled leader texture and cached exact RenderTexture alias')
require('kVideoFirstFrameGraceFrames' in core and
        'kVideoRecoveryBackoffFrames' in core and
        'kVideoStallFrames' in core and
        'decoderStalled ? "stalled"' in core,
        'black and stalled decoders retain bounded local recovery at ordinary speeds')

# Startup/callback/lifecycle hardening.
manifest = text('mod.json')
qpm = text('qpm.json')
events = text('src/VivifyEvents.cpp')
require('cjdResult != CLoadResultEnum::MatchType_Loaded' in core and
        'tracksResult != CLoadResultEnum::MatchType_Loaded' in core and
        'hook installation skipped because runtime dependencies were not ready' in hooks,
        'Vivify fails closed when required late-mod dependencies did not initialize')
require('custom-event callback failed safely' in core and
        'level-selection callback failed safely' in core and
        'late_load failed safely' in main,
        'native mod callback boundaries contain recoverable C++ exceptions')
require('prepareThrough = std::max(prepareThrough, currentSongTime)' in events and
        'beatmap preparation failed safely' in events,
        'first-event preparation targets the selected song time and fails closed')
require('deferredMode' in core and 'ResetMode::LateSceneTransition' in core and
        'pointer-' in core,
        'deferred scene-transition cleanup escalates to pointer-free retirement')
require('"version": "4.8.0"' in manifest and 'paperlog/releases/download/v4.8.0' in manifest and
        '"version": "0.6.9"' in manifest and 'WebUtils/releases/download/v0.6.9' in manifest and
        '"versionRange": "=4.8.0"' in qpm and '"versionRange": "=0.6.9"' in qpm,
        'runtime dependency package versions match the build lock for Paper/WebUtils')

# Flux/map-specific compatibility experiments remain removed.
combined = '\n'.join(text(p) for p in [
    'src/VivifyObjectPrefabs.cpp', 'src/VivifyCore.cpp', 'src/VivifyPostProcessing.cpp',
    'src/VivifyComponents.cpp', 'src/VivifyHooks.cpp'])
for forbidden in ['AlwaysVisibleQuad', 'LateBloomPrePass', 'ForceGameObjectRenderersOnTop',
                  'ForceRendererOnTop', '42 Flux']:
    require(forbidden not in combined, f'map-specific override absent: {forbidden}')

# XR shader variant ownership. Unity selects Multiview/SPI to match the actual
# camera render pass. Mutating those keywords on a shared Material corrupts both
# screen-space effects and geometry shaders, and makes normal gameplay differ
# from Zen when note-replacement material repair touches shared materials.
assets = text('src/VivifyAssets.cpp')
geometry = text('src/VivifyGeometry.cpp')
stereo_start = assets.find('void Runtime::ApplyStereoKeywords')
stereo_end = assets.find('void Runtime::ApplyGameObjectStereoKeywords', stereo_start)
stereo_body = assets[stereo_start:stereo_end]
for forbidden_write in [
    'SetMaterialKeyword(material, u"STEREO_INSTANCING_ON"',
    'SetMaterialKeyword(material, u"STEREO_MULTIVIEW_ON"',
    'SetMaterialKeyword(material, u"UNITY_SINGLE_PASS_STEREO"',
    'NeedsStereoInstancingCompatibility(shaderName)',
    'forcing instanced eye routing',
]:
    require(forbidden_write not in stereo_body,
            f'ApplyStereoKeywords leaves Unity XR variant state untouched: {forbidden_write}')
require('SetMaterialKeyword(material, u"MULTIPASS_ENABLED", GetMultipassRenderingEnabled())' in stereo_body,
        'ApplyStereoKeywords only owns Vivify legacy MULTIPASS_ENABLED compatibility')
require('NeedsStereoInstancingCompatibility' not in assets and
        'NeedsStereoInstancingCompatibility' not in geometry and
        'NeedsStereoInstancingCompatibility' not in text('include/VivifyGeometry.hpp'),
        'fake Wireframe instanced-stereo keyword recipe removed')
require('wireframe' in geometry.lower() and 'triangleexplosion' in geometry.lower(),
        'Wireframe and TriangleExplosion remain recognized as geometry-shader families for diagnostics')
require('Force per-eye blits (experimental)' not in main and 'GetForcePerEyeBlits' not in post,
        'misleading global per-eye blit toggle removed')
require('_StereoActiveEye' in post and '_VivifyPerEyeBlit' in post,
        'authored fullscreen per-eye blit support remains')
require('NeedsCommit107LegacyPerEyeBlit' in post and
        'nasafrasa/postprocessing/fms_cat/glitch' in post and
        'nasafrasa/postprocessing/pixelate' in post and
        'data.legacyPerEyeBlit' in post,
        'Lumi uses only Commit107 cheap depth-slice mirror/orientation compatibility')
require('_VivifyLegacyEyeSource' not in post and
        'GetTemporaryRT(legacyEyeSourceId' not in post,
        'Lumi Commit109 XR-slice to Tex2D copy bridge remains absent')
require('QueueStereoLegacyMaterialChain' not in post and
        '_VivifyLegacyChainA' not in post and '_VivifyLegacyChainB' not in post,
        'failed Lumi overlap-chain experiment remains absent')
require('hidden/old' in post and
        'IsLegacyOldFrameShader' in post and
        'IsOldFrameDeclaredTexture' in post and
        'CollectOldFrameTextureInputs' in post and
        'QueueOldFrameMaterialBlit' in post and
        'BuildOldFrameEyeMaterial' in post and
        'clone->SetTexture(input.propertyId' in post and
        'sourceEyeId.m_DepthSlice = eye' in post and
        'oldFrameCapture ? 1 : 0' in post and
        'e.data.frame.value() < frame' in post,
        '3 Big Shots Hidden/Old alone receives the proven material-local per-eye freeze bridge and one-frame capture grace')
# Guard the main performance requirement: non-Hidden/Old effects return before
# any declared-screen-texture scan, so Lumi cannot pay the 3BS compatibility cost.
collect_start = post.find('std::vector<OldFrameTextureInput> CollectOldFrameTextureInputs')
collect_end = post.find('UnityEngine::Material* BuildOldFrameEyeMaterial', collect_start)
collect_body = post[collect_start:collect_end]
require('if (!IsLegacyOldFrameShader(material)) return result;' in collect_body,
        '3BS declared-texture inspection is hard-gated before iterating the table')

# Decoder teardown safety must not alter the validated Commit-103 sync loop.
# Stop only when a Vivify-owned decoder/warmup is actually being destroyed.
require('StopVideoPlayerBeforeDestroy(video.player);' in core and
        'StopVideoPlayerBeforeDestroy(follower.player);' in core and
        'StopWarmupVideoBeforeDestroy(warmup.player);' in assets and
        'player->Stop();' in core and 'player->Stop();' in assets,
        'Vivify-owned VideoPlayers stop MediaCodec before GameObject destruction')
video_reset = core.find('for (auto& synced : _syncedObjects) ReleaseSyncedVideos(synced, false);')
scene_teardown = core.find('for (auto& [id, prefab] : _livePrefabs)', video_reset)
require(video_reset >= 0 and scene_teardown > video_reset,
        'persistent decoders are retired before restart/speed-change scene targets are destroyed')

# SaberTrail owner follows the physical Saber while its renderer consumes
# world-space movement at world root, matching CustomModels' proven setup.
obj = text('src/VivifyObjectPrefabs.cpp')
require('trailObject->get_transform()->SetParent(replacementParent, false)' in obj and
        'InitFollowed(sourceTrail, replacementParent' in obj,
        'Vivify followed trail owner stays on the physical Saber root')
require('frame - _lastSaberIntegrityFrame >= 4' in obj,
        'late CustomModels rebuilds are suppressed quickly')
require('target.saber == saber || target.controller == smc' in obj,
        'custom saber controllers are deduplicated per physical Saber')
require('collectForeignTrails(visualRoot)' in obj and 'collectForeignTrails(replacementParent)' in obj,
        'CustomModels trails are discovered across both saber hierarchy roots')

# Material-property ownership has two required boundary cases. A newer event
# must retire an older animation that has already reached its endpoint (YOU
# ambientflare at beat 111.25), while a genuinely still-running older animation
# remains resumable after a one-frame override (Luminescent 452 -> 467 fade).
props = text('src/VivifyProperties.cpp')
require('RetireCompletedMaterialPropertyAnimations' in props and
        'animation->endTime > eventTime + kEventBoundaryEpsilon' in props and
        'oldProperty.id == newProperty.id' in props and
        '_materialPropertyFrameOverrides' in props and
        'overrideValue.frame == frame' in props and
        'overrideValue.sequence > read->sequence' in props,
        'material animation ownership preserves YOU endpoint handoff and Luminescent overlap')
require('RetireCompletedMaterialPropertyAnimations(material, properties, startTime);' not in post,
        'pre-Lumi ApplyPostProcessing path does not import the later material-boundary override')
require('MaterialPropertyFrameOverride' in types and
        '_materialPropertySequence' in runtime_header and
        '_materialPropertyFrameOverrides.clear();' in core and
        '_materialPropertySequence = 0;' in core,
        'one-frame material overrides are represented explicitly and cleared safely across pause/reset')

# Restart / scene-transition state hygiene. Bundle-owned material assets are
# shared across prefab instances and survive an in-song restart, so every
# authored SetMaterialProperty/Blit property must snapshot the pre-event value
# and restore it before the next run.
require('SavedMaterialState' in types and '_savedMaterialStates' in runtime_header and
        'SaveOriginalMaterialProperties(material, properties);' in props and
        'SaveOriginalMaterialProperties(material, properties);' not in post and
        'RestoreMaterialProperties();' in core,
        'restart material-state restoration remains for SetMaterialProperty while pre-Lumi Blit properties avoid the later hook')
require('material->GetTexture(propertyId)' in props and
        'material->GetColor(propertyId)' in props and
        'material->GetFloat(propertyId)' in props and
        'material->GetInt(propertyId)' in props and
        'material->GetVector(propertyId)' in props and
        'material->IsKeywordEnabled' in props,
        'material restart snapshots cover texture/color/float/int/vector/keyword state')
require('RestoreRenderSettings(true);' in core and
        'transitionSafeOnly' in props and
        'RenderSettingKind::Material || s.kind == RenderSettingKind::Light' in props and
        'UnityEngine::Shader::SetGlobalColor(propertyId' in core and
        'UnityEngine::Shader::SetGlobalFloat(propertyId' in core and
        'UnityEngine::Shader::SetGlobalVector(propertyId' in core,
        'late scene transitions restore safe shader/render/quality globals without touching stale object pointers')

# Skybox repair must stay inside a Skybox/* shader family.
require('Skybox/Panoramic' in assets and 'context == "skybox"' in assets,
        'unsupported skybox materials use a skybox-compatible fallback')
require('_vivifySkyboxOverrideActive' not in props and
        'set_clearFlags(UnityEngine::CameraClearFlags::Skybox)' not in props,
        'SetRenderingSettings.skybox does not implicitly override camera clear mode')
require('ReadCameraPropertyValue' in post and '"_" + std::string(key)' in post,
        'SetCameraProperty accepts documented and legacy underscore field names')
require('ReadCameraBackgroundColor' in post and 'value.Size() == 1' in post,
        'camera background parser accepts flat RGBA and one-color nested form')
refresh_body = post[post.find('void Runtime::RefreshCameraComponents'):post.find('void Runtime::RefreshMultipassRendering')]
require(('if (cameraChanged || _mainCameraPropsDirty)' in refresh_body or
         'if (cameraChanged || cameraReappeared || _mainCameraPropsDirty)' in refresh_body) and
        'ApplyCameraProperties(mainCamPtr, props->second);' in refresh_body and
        'mainCamPtr->set_backgroundColor(*props->second.backgroundColor)' not in refresh_body,
        'main-camera scalar properties apply on authored/camera lifecycle changes instead of being forced every frame')

# Flux / Multiview transport. Quest's main XR target is a two-slice array; a
# plain camera-boundary Blit can preserve only the active eye. Keep both slices
# with CopyTexture at the CurrentActive/CameraTarget boundaries.
mid_start = post.find('Runtime::BuildMidRenderCommandBuffer(')
mid_end = post.find('std::size_t Runtime::ComputeMidRenderSignature', mid_start)
mid_body = post[mid_start:mid_end]
require('cb->CopyTexture(srcId, ToTargetId(_midMainRT))' in mid_body and
        'cb->CopyTexture(ToTargetId(mainCurrent), dstId)' in mid_body,
        'mid-render Multiview boundaries preserve both XR texture-array slices')
apply_start = post.find('void Runtime::ApplyBlits(')
apply_end = post.find('void Runtime::CacheMainRenderDescriptor', apply_start)
apply_body = post[apply_start:apply_end]
require('UsesTextureArrayStereo() && IsTextureArray(mainCurrent->get_descriptor())' in apply_body and
        'cb->CopyTexture(ToTargetId(mainCurrent), destId);' in apply_body,
        'OnRenderImage presentation preserves both slices when CameraTarget is Multiview')

# Secondary-camera outputs must follow the XR consumer contract rather than the
# incidental source layout. Targetless Quest helper cameras can surface mono
# OnRenderImage/depth textures while authored Flux shaders consume sampler2DArray.
capture_start = post.find('void Runtime::CaptureSecondaryCameraFrame(')
capture_end = post.find('void Runtime::BindSecondaryCameraTextures()', capture_start)
capture_body = post[capture_start:capture_end]
require('bool const stereoArrayCapture = UsesTextureArrayStereo();' in capture_body and
        'ConfigureStereoRenderTextureDescriptor(srcDesc, stereoArrayCapture);' in capture_body,
        'secondary color capture publishes a stereo array whenever XR is Multiview/SPI')
require('bool const stereoDepthCapture = UsesTextureArrayStereo();' in capture_body and
        'ConfigureStereoRenderTextureDescriptor(depthDesc, stereoDepthCapture);' in capture_body,
        'secondary depth capture matches the stereo color layout')
require('sourceEye == 0 || sourceEye == 1' in post and
        'Graphics::CopyTexture(source, 0, 0, destination, sourceEye, 0)' in post and
        'Graphics::CopyTexture(source, 0, 0, destination, 0, 0)' in post and
        'Graphics::CopyTexture(source, 0, 0, destination, 1, 0)' in post,
        'mono per-eye secondary callbacks populate the matching XR slice with a safe mono fallback')
require('camera->get_stereoActiveEye().value__' in capture_body and
        'CopyCapturedTexture(src, output, physicalEye' in capture_body and
        'CopyCapturedTexture(sourceDepthRT, outputDepth, physicalEye' in capture_body,
        'secondary color and depth use the same physical-eye routing')
secondary_start = comp.find('void SecondaryCameraController::OnPreCull()')
secondary_end = comp.find('void SecondaryCameraController::OnPostRender()', secondary_start)
secondary_precull = comp[secondary_start:secondary_end]
require('Runtime::Instance().RestoreSecondaryCullingLayers();' in secondary_precull and
        secondary_precull.find('RestoreSecondaryCullingLayers') < secondary_precull.find('CullingPreCull'),
        'each secondary camera restores stale culling-layer mutations before applying its own')
culling_start = comp.find('void CullingCameraController::CullingPreCull()')
culling_end = comp.find('void CullingCameraController::OnDisable()', culling_start)
culling_body = comp[culling_start:culling_end]
require('_cachedMask = _camera->get_cullingMask();' in culling_body and
        '_camera->set_cullingMask(_cachedMask.value() & ~(1 << kCullingLayer));' in culling_body,
        'blacklist cameras actually exclude Vivify private-layer renderers instead of leaking original notes')
require('bool const wasActive = go->get_activeSelf();' in post and
        'if (wasActive) go->SetActive(false);' in post and
        'secondaryBloom->____bloomPrePassRenderData = sourceBloom->____bloomPrePassRenderData;' in post and
        'if (wasActive) go->SetActive(true);' in post,
        'secondary BloomPrePass receives dependencies before Awake/reactivation')
for forbidden in ['legacyMonoChain', 'MonoDescriptorFor', 'AfterEverything',
                  'arrayColorCaptureCommandBuffer', 'PostProcessing/Tile"']:
    require(forbidden not in post, f'failed Flux compatibility experiment absent: {forbidden}')

print('ALL STATIC VIVIFY CHECKS PASSED')
