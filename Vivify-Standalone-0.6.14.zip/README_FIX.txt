Test this single build on both maps.

Luminescent:
- Pixelate must remain present.
- Glitch + Pixelate overlap should no longer black out.
- No mirrored-eye regression.

3 Big Shots:
- _Old freeze frames must remain working.
- Crouch / screen-covering text should be centered instead of displaced left.
- the intentional split-eye section must remain split (different content per eye).

This source starts from the proven SemanticFix baseline. It does NOT include the failed broad mono-eye/keyword experiment.
