Test both maps with this single source tree.

Luminescent expected result:
- Pixelate is present again (Commit-109 path).
- no black Glitch -> Pixelate overlap.
- no mirrored-eye regression.

3 Big Shots expected result:
- _Old freeze frames are actual captured scene images instead of flat white.
- Hidden/Old receives per-eye Tex2D captures through material-local _Old1.._Old4 bindings.

This source is based on Vivify-Standalone-0.6.14(20260918-193720), not the failed combined 2D-chain build.
